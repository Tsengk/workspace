// Copyright (c) 2021, Stogl Robotics Consulting UG (haftungsbeschränkt)
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/*
 * Authors: Subhas Das, Denis Stogl
 */

#include "force_torque_sensor_broadcaster/force_torque_sensor_broadcaster.hpp"

#include <limits>
#include <memory>
#include <string>

#include "rclcpp/logging.hpp"

namespace force_torque_sensor_broadcaster
{
ForceTorqueSensorBroadcaster::ForceTorqueSensorBroadcaster()
: controller_interface::ChainableControllerInterface()
{
}

controller_interface::CallbackReturn ForceTorqueSensorBroadcaster::on_init()
{
  try
  {
    param_listener_ = std::make_shared<ParamListener>(get_node());
    params_ = param_listener_->get_params();
  }
  catch (const std::exception & e)
  {
    fprintf(stderr, "Exception thrown during init stage with message: %s \n", e.what());
    return controller_interface::CallbackReturn::ERROR;
  }

  return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn ForceTorqueSensorBroadcaster::on_configure(
  const rclcpp_lifecycle::State & /*previous_state*/)
{
  params_ = param_listener_->get_params();

  const bool no_interface_names_defined =
    params_.interface_names.force.x.empty() && params_.interface_names.force.y.empty() &&
    params_.interface_names.force.z.empty() && params_.interface_names.torque.x.empty() &&
    params_.interface_names.torque.y.empty() && params_.interface_names.torque.z.empty();

  if (params_.sensor_name.empty() && no_interface_names_defined)
  {
    RCLCPP_ERROR(
      get_node()->get_logger(),
      "'sensor_name' or at least one "
      "'interface_names.[force|torque].[x|y|z]' parameter has to be specified.");
    return controller_interface::CallbackReturn::ERROR;
  }

  if (!params_.sensor_name.empty() && !no_interface_names_defined)
  {
    RCLCPP_ERROR(
      get_node()->get_logger(),
      "both 'sensor_name' and "
      "'interface_names.[force|torque].[x|y|z]' parameters can not be specified together.");
    return controller_interface::CallbackReturn::ERROR;
  }

  if (!params_.sensor_name.empty())
  {
    force_torque_sensor_ =
      std::make_unique<semantic_components::ForceTorqueSensor>(params_.sensor_name);
  }
  else
  {
    auto const & force_names = params_.interface_names.force;
    auto const & torque_names = params_.interface_names.torque;
    force_torque_sensor_ = std::make_unique<semantic_components::ForceTorqueSensor>(
      force_names.x, force_names.y, force_names.z, torque_names.x, torque_names.y, torque_names.z);
  }

  try
  {
    filter_chain_ =
      std::make_unique<filters::FilterChain<WrenchMsgType>>("geometry_msgs::msg::WrenchStamped");
  }
  catch (const std::exception & e)
  {
    fprintf(stderr, "Exception thrown during filter chain creation with message : %s \n", e.what());
    return CallbackReturn::ERROR;
  }

  // As the sensor_filter_chain parameter is of type 'none', we cannot directly check if it is
  // present. Even if the sensor_filter_chain parameter is not specified, the filter chain will be
  // correctly configured with an empty list of filters.
  bool filter_chain_configured = filter_chain_->configure(
    "sensor_filter_chain", get_node()->get_node_logging_interface(),
    get_node()->get_node_parameters_interface());

  if (!filter_chain_configured)
  {
    RCLCPP_ERROR(get_node()->get_logger(), "Failed to configure sensor filter chain.");
    return CallbackReturn::ERROR;
  }

  // Even on successful configure, if empty, the chain won't be used
  has_filter_chain_ = filter_chain_->get_length() > 0;

  RCLCPP_INFO_EXPRESSION(
    get_node()->get_logger(), has_filter_chain_, "Filter active with %zu filters!",
    filter_chain_->get_length());

  try
  {
    // register ft sensor data publisher
    sensor_raw_state_publisher_ = get_node()->create_publisher<geometry_msgs::msg::WrenchStamped>(
      "~/wrench", rclcpp::SystemDefaultsQoS());
    realtime_raw_publisher_ = std::make_unique<StateRTPublisher>(sensor_raw_state_publisher_);

    sensor_filtered_state_publisher_ =
      get_node()->create_publisher<geometry_msgs::msg::WrenchStamped>(
        "~/wrench_filtered", rclcpp::SystemDefaultsQoS());
    realtime_filtered_publisher_ =
      std::make_unique<StateRTPublisher>(sensor_filtered_state_publisher_);
  }
  catch (const std::exception & e)
  {
    fprintf(
      stderr, "Exception thrown during publisher creation at configure stage with message : %s \n",
      e.what());
    return controller_interface::CallbackReturn::ERROR;
  }

  wrench_raw_.header.frame_id = params_.frame_id;
  wrench_filtered_.header.frame_id = params_.frame_id;

  RCLCPP_INFO(get_node()->get_logger(), "configure successful");
  return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::InterfaceConfiguration
ForceTorqueSensorBroadcaster::command_interface_configuration() const
{
  controller_interface::InterfaceConfiguration command_interfaces_config;
  command_interfaces_config.type = controller_interface::interface_configuration_type::NONE;
  return command_interfaces_config;
}

controller_interface::InterfaceConfiguration
ForceTorqueSensorBroadcaster::state_interface_configuration() const
{
  controller_interface::InterfaceConfiguration state_interfaces_config;
  state_interfaces_config.type = controller_interface::interface_configuration_type::INDIVIDUAL;
  state_interfaces_config.names = force_torque_sensor_->get_state_interface_names();
  return state_interfaces_config;
}

controller_interface::CallbackReturn ForceTorqueSensorBroadcaster::on_activate(
  const rclcpp_lifecycle::State & /*previous_state*/)
{
  force_torque_sensor_->assign_loaned_state_interfaces(state_interfaces_);
  return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn ForceTorqueSensorBroadcaster::on_deactivate(
  const rclcpp_lifecycle::State & /*previous_state*/)
{
  force_torque_sensor_->release_interfaces();
  return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::return_type ForceTorqueSensorBroadcaster::update_and_write_commands(
  const rclcpp::Time & time, const rclcpp::Duration & /*period*/)
{
  param_listener_->try_get_params(params_);

  wrench_raw_.header.stamp = time;
  force_torque_sensor_->get_values_as_message(wrench_raw_.wrench);
  this->apply_sensor_offset(params_, wrench_raw_);
  this->apply_sensor_multiplier(params_, wrench_raw_);

  if (realtime_raw_publisher_)
  {
    realtime_raw_publisher_->try_publish(wrench_raw_);
  }

  if (has_filter_chain_)
  {
    // Filter sensor data, if no filter chain config was specified, wrench_filtered_ = wrench_raw_
    auto filtered = filter_chain_->update(wrench_raw_, wrench_filtered_);
    if (filtered && realtime_filtered_publisher_)
    {
      wrench_filtered_.header.stamp = time;
      realtime_filtered_publisher_->try_publish(wrench_filtered_);
    }
  }

  return controller_interface::return_type::OK;
}

controller_interface::return_type ForceTorqueSensorBroadcaster::update_reference_from_subscribers(
  const rclcpp::Time & /*time*/, const rclcpp::Duration & /*period*/)
{
  return controller_interface::return_type::OK;
}

std::vector<hardware_interface::StateInterface::SharedPtr>
ForceTorqueSensorBroadcaster::on_export_state_interfaces_list()
{
  std::vector<hardware_interface::StateInterface::SharedPtr> exported_state_interfaces;

  std::vector<std::string> force_names(
    {params_.interface_names.force.x, params_.interface_names.force.y,
     params_.interface_names.force.z});
  std::vector<std::string> torque_names(
    {params_.interface_names.torque.x, params_.interface_names.torque.y,
     params_.interface_names.torque.z});
  std::string export_prefix = get_node()->get_name();
  if (!params_.sensor_name.empty())
  {
    const auto semantic_comp_itf_names = force_torque_sensor_->get_state_interface_names();
    std::copy(
      semantic_comp_itf_names.begin(), semantic_comp_itf_names.begin() + 3, force_names.begin());
    std::copy(
      semantic_comp_itf_names.begin() + 3, semantic_comp_itf_names.end(), torque_names.begin());

    // Update the prefix and get the proper force and torque names
    export_prefix = export_prefix + "/" + params_.sensor_name;
    // strip "/" and get the second part of the information
    // e.g. /ft_sensor/force.x -> force.x
    std::for_each(
      force_names.begin(), force_names.end(),
      [](std::string & name) { name = name.substr(name.find_last_of("/") + 1); });
    std::for_each(
      torque_names.begin(), torque_names.end(),
      [](std::string & name) { name = name.substr(name.find_last_of("/") + 1); });
  }
  if (!force_names[0].empty())
  {
    auto si = std::make_shared<hardware_interface::StateInterface>(export_prefix, force_names[0]);
    si->set_value(wrench_raw_.wrench.force.x);
    exported_state_interfaces.push_back(si);
  }
  if (!force_names[1].empty())
  {
    auto si = std::make_shared<hardware_interface::StateInterface>(export_prefix, force_names[1]);
    si->set_value(wrench_raw_.wrench.force.y);
    exported_state_interfaces.push_back(si);
  }
  if (!force_names[2].empty())
  {
    auto si = std::make_shared<hardware_interface::StateInterface>(export_prefix, force_names[2]);
    si->set_value(wrench_raw_.wrench.force.z);
    exported_state_interfaces.push_back(si);
  }
  if (!torque_names[0].empty())
  {
    auto si = std::make_shared<hardware_interface::StateInterface>(export_prefix, torque_names[0]);
    si->set_value(wrench_raw_.wrench.torque.x);
    exported_state_interfaces.push_back(si);
  }
  if (!torque_names[1].empty())
  {
    auto si = std::make_shared<hardware_interface::StateInterface>(export_prefix, torque_names[1]);
    si->set_value(wrench_raw_.wrench.torque.y);
    exported_state_interfaces.push_back(si);
  }
  if (!torque_names[2].empty())
  {
    auto si = std::make_shared<hardware_interface::StateInterface>(export_prefix, torque_names[2]);
    si->set_value(wrench_raw_.wrench.torque.z);
    exported_state_interfaces.push_back(si);
  }
  return exported_state_interfaces;
}

void ForceTorqueSensorBroadcaster::apply_sensor_offset(
  const Params & params, geometry_msgs::msg::WrenchStamped & msg)
{
  msg.wrench.force.x += params.offset.force.x;
  msg.wrench.force.y += params.offset.force.y;
  msg.wrench.force.z += params.offset.force.z;
  msg.wrench.torque.x += params.offset.torque.x;
  msg.wrench.torque.y += params.offset.torque.y;
  msg.wrench.torque.z += params.offset.torque.z;
}

void ForceTorqueSensorBroadcaster::apply_sensor_multiplier(
  const Params & params, geometry_msgs::msg::WrenchStamped & msg)
{
  msg.wrench.force.x *= params.multiplier.force.x;
  msg.wrench.force.y *= params.multiplier.force.y;
  msg.wrench.force.z *= params.multiplier.force.z;
  msg.wrench.torque.x *= params.multiplier.torque.x;
  msg.wrench.torque.y *= params.multiplier.torque.y;
  msg.wrench.torque.z *= params.multiplier.torque.z;
}
}  // namespace force_torque_sensor_broadcaster

#include "pluginlib/class_list_macros.hpp"

PLUGINLIB_EXPORT_CLASS(
  force_torque_sensor_broadcaster::ForceTorqueSensorBroadcaster,
  controller_interface::ChainableControllerInterface)
