// Copyright 2022 Pixel Robotics.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/*
 * Author: Tony Najjar
 */

#include <gmock/gmock.h>

#include <cmath>
#include <memory>
#include <string>
#include <thread>
#include <tuple>
#include <utility>
#include <vector>

#include "hardware_interface/loaned_command_interface.hpp"
#include "hardware_interface/loaned_state_interface.hpp"
#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "lifecycle_msgs/msg/state.hpp"
#include "rclcpp/executor.hpp"
#include "rclcpp/executors.hpp"
#include "tricycle_controller/tricycle_controller.hpp"

using CallbackReturn = controller_interface::CallbackReturn;
using hardware_interface::HW_IF_POSITION;
using hardware_interface::HW_IF_VELOCITY;
using hardware_interface::LoanedCommandInterface;
using hardware_interface::LoanedStateInterface;
using lifecycle_msgs::msg::State;
using testing::SizeIs;
using testing::UnorderedElementsAre;

namespace
{
const char traction_joint_name[] = "traction_joint";
const char steering_joint_name[] = "steering_joint";
}  // namespace

class TestableTricycleController : public tricycle_controller::TricycleController
{
public:
  using TricycleController::odometry_;
  using TricycleController::TricycleController;
  std::shared_ptr<geometry_msgs::msg::TwistStamped> getLastReceivedTwist()
  {
    std::shared_ptr<geometry_msgs::msg::TwistStamped> ret;
    received_velocity_msg_ptr_.get(
      [&ret](const std::shared_ptr<geometry_msgs::msg::TwistStamped> & msg) { ret = msg; });
    return ret;
  }

  /**
   * @brief wait_for_twist block until a new twist is received.
   * Requires that the executor is not spinned elsewhere between the
   *  message publication and the call to this function
   */
  void wait_for_twist(
    rclcpp::Executor & executor,
    const std::chrono::milliseconds & timeout = std::chrono::milliseconds(500))
  {
    auto until = get_node()->get_clock()->now() + timeout;
    while (get_node()->get_clock()->now() < until)
    {
      executor.spin_some();
      std::this_thread::sleep_for(std::chrono::microseconds(10));
    }
  }
};

class TestTricycleController : public ::testing::Test
{
protected:
  static void SetUpTestCase() { rclcpp::init(0, nullptr); }

  void SetUp() override
  {
    controller_ = std::make_unique<TestableTricycleController>();
    pub_node = std::make_shared<rclcpp::Node>("velocity_publisher");
    velocity_publisher = pub_node->create_publisher<geometry_msgs::msg::TwistStamped>(
      controller_name + "/cmd_vel", rclcpp::SystemDefaultsQoS());

    steering_joint_pos_state_ =
      std::make_shared<hardware_interface::StateInterface>(steering_joint_name, HW_IF_POSITION);
    std::ignore = steering_joint_pos_state_->set_value(position_);

    traction_joint_vel_state_ =
      std::make_shared<hardware_interface::StateInterface>(traction_joint_name, HW_IF_VELOCITY);
    std::ignore = traction_joint_vel_state_->set_value(velocity_);

    steering_joint_pos_cmd_ =
      std::make_shared<hardware_interface::CommandInterface>(steering_joint_name, HW_IF_POSITION);
    std::ignore = steering_joint_pos_cmd_->set_value(position_);

    traction_joint_vel_cmd_ =
      std::make_shared<hardware_interface::CommandInterface>(traction_joint_name, HW_IF_VELOCITY);
    std::ignore = traction_joint_vel_cmd_->set_value(velocity_);
  }

  static void TearDownTestCase() { rclcpp::shutdown(); }

  /// Publish velocity msgs
  /**
   *  linear - magnitude of the linear command in the geometry_msgs::twist message
   *  angular - the magnitude of the angular command in geometry_msgs::twist message
   */
  void publish(double linear, double angular)
  {
    int wait_count = 0;
    auto topic = velocity_publisher->get_topic_name();
    while (pub_node->count_subscribers(topic) == 0)
    {
      if (wait_count >= 5)
      {
        auto error_msg = std::string("publishing to ") + topic + " but no node subscribes to it";
        throw std::runtime_error(error_msg);
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(100));
      ++wait_count;
    }

    geometry_msgs::msg::TwistStamped velocity_message;
    velocity_message.header.stamp = pub_node->get_clock()->now();
    velocity_message.twist.linear.x = linear;
    velocity_message.twist.angular.z = angular;
    velocity_publisher->publish(velocity_message);
  }

  /// \brief wait for the subscriber and publisher to completely setup
  void waitForSetup(rclcpp::Executor & executor)
  {
    constexpr std::chrono::seconds TIMEOUT{2};
    auto clock = pub_node->get_clock();
    auto start = clock->now();
    while (velocity_publisher->get_subscription_count() <= 0)
    {
      if ((clock->now() - start) > TIMEOUT)
      {
        FAIL();
      }
      executor.spin_some();
      std::this_thread::sleep_for(std::chrono::microseconds(10));
    }
  }

  void assignResources(bool reverse_order = false)
  {
    std::vector<LoanedStateInterface> state_ifs;
    state_ifs.emplace_back(
      reverse_order ? traction_joint_vel_state_ : steering_joint_pos_state_, nullptr);
    state_ifs.emplace_back(
      reverse_order ? steering_joint_pos_state_ : traction_joint_vel_state_, nullptr);

    std::vector<LoanedCommandInterface> command_ifs;
    command_ifs.emplace_back(
      reverse_order ? traction_joint_vel_cmd_ : steering_joint_pos_cmd_, nullptr);
    command_ifs.emplace_back(
      reverse_order ? steering_joint_pos_cmd_ : traction_joint_vel_cmd_, nullptr);

    controller_->assign_interfaces(std::move(command_ifs), std::move(state_ifs));
  }

  controller_interface::return_type InitController(
    const std::string traction_joint_name_init = traction_joint_name,
    const std::string steering_joint_name_init = steering_joint_name,
    const std::vector<rclcpp::Parameter> & parameters = {})
  {
    auto node_options = rclcpp::NodeOptions();
    std::vector<rclcpp::Parameter> parameter_overrides;

    parameter_overrides.push_back(
      rclcpp::Parameter("traction_joint_name", rclcpp::ParameterValue(traction_joint_name_init)));
    parameter_overrides.push_back(
      rclcpp::Parameter("steering_joint_name", rclcpp::ParameterValue(steering_joint_name_init)));
    // default parameters
    parameter_overrides.push_back(rclcpp::Parameter("wheelbase", rclcpp::ParameterValue(1.)));
    parameter_overrides.push_back(rclcpp::Parameter("wheel_radius", rclcpp::ParameterValue(0.1)));

    parameter_overrides.insert(parameter_overrides.end(), parameters.begin(), parameters.end());
    node_options.parameter_overrides(parameter_overrides);

    controller_interface::ControllerInterfaceParams params;
    params.controller_name = controller_name;
    params.robot_description = urdf_;
    params.update_rate = 0;
    params.node_namespace = "";
    params.node_options = node_options;
    return controller_->init(params);
  }

  const std::string controller_name = "test_tricycle_controller";
  std::unique_ptr<TestableTricycleController> controller_;

  const double position_ = 0.1;
  const double velocity_ = 0.2;

  hardware_interface::StateInterface::SharedPtr steering_joint_pos_state_;
  hardware_interface::StateInterface::SharedPtr traction_joint_vel_state_;
  hardware_interface::CommandInterface::SharedPtr steering_joint_pos_cmd_;
  hardware_interface::CommandInterface::SharedPtr traction_joint_vel_cmd_;

  rclcpp::Node::SharedPtr pub_node;
  rclcpp::Publisher<geometry_msgs::msg::TwistStamped>::SharedPtr velocity_publisher;

  const std::string urdf_ = "";
};

TEST_F(TestTricycleController, init_fails_without_parameters)
{
  controller_interface::ControllerInterfaceParams params;
  params.controller_name = "controller_name";
  params.robot_description = urdf_;
  params.update_rate = 0;
  params.node_namespace = "";
  params.node_options = controller_->define_custom_node_options();

  const auto ret = controller_->init(params);
  ASSERT_EQ(ret, controller_interface::return_type::ERROR);
}

TEST_F(TestTricycleController, init_fails_if_only_traction_or_steering_side_defined)
{
  ASSERT_EQ(
    InitController(traction_joint_name, std::string()), controller_interface::return_type::ERROR);

  ASSERT_EQ(
    InitController(std::string(), steering_joint_name), controller_interface::return_type::ERROR);
}

TEST_F(TestTricycleController, configure_succeeds_when_joints_are_specified)
{
  ASSERT_EQ(InitController(), controller_interface::return_type::OK);

  ASSERT_EQ(controller_->on_configure(rclcpp_lifecycle::State()), CallbackReturn::SUCCESS);

  // check interface configuration
  auto cmd_if_conf = controller_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, SizeIs(2lu));
  ASSERT_THAT(
    cmd_if_conf.names, UnorderedElementsAre(
                         std::string(traction_joint_name) + "/velocity",
                         std::string(steering_joint_name) + "/position"));
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);
  auto state_if_conf = controller_->state_interface_configuration();
  ASSERT_THAT(state_if_conf.names, SizeIs(2lu));
  ASSERT_THAT(
    state_if_conf.names, UnorderedElementsAre(
                           std::string(traction_joint_name) + "/velocity",
                           std::string(steering_joint_name) + "/position"));
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);
}

TEST_F(TestTricycleController, activate_fails_without_resources_assigned)
{
  ASSERT_EQ(InitController(), controller_interface::return_type::OK);

  ASSERT_EQ(controller_->on_configure(rclcpp_lifecycle::State()), CallbackReturn::SUCCESS);
  ASSERT_EQ(controller_->on_activate(rclcpp_lifecycle::State()), CallbackReturn::ERROR);
}

TEST_F(TestTricycleController, activate_succeeds_with_resources_assigned)
{
  ASSERT_EQ(InitController(), controller_interface::return_type::OK);

  // We implicitly test that by default position feedback is required
  ASSERT_EQ(controller_->on_configure(rclcpp_lifecycle::State()), CallbackReturn::SUCCESS);
  assignResources();
  ASSERT_EQ(controller_->on_activate(rclcpp_lifecycle::State()), CallbackReturn::SUCCESS);
}

TEST_F(TestTricycleController, reactivate_with_reassigned_interfaces)
{
  ASSERT_EQ(
    InitController(
      traction_joint_name, steering_joint_name,
      {rclcpp::Parameter("wheel_radius", 1.0),
       rclcpp::Parameter("velocity_rolling_window_size", 1)}),
    controller_interface::return_type::OK);
  ASSERT_EQ(controller_->configure().id(), State::PRIMARY_STATE_INACTIVE);

  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(controller_->get_node()->get_node_base_interface());

  for (int cycle = 0; cycle < 3; ++cycle)
  {
    SCOPED_TRACE(cycle);
    assignResources(cycle % 2 != 0);
    ASSERT_EQ(controller_->get_node()->activate().id(), State::PRIMARY_STATE_ACTIVE);

    const double velocity = 0.2 * (cycle + 1);
    const double position = 0.1 * (cycle + 1);
    ASSERT_TRUE(traction_joint_vel_state_->set_value(velocity));
    ASSERT_TRUE(steering_joint_pos_state_->set_value(position));
    publish(1.0, 0.0);
    controller_->wait_for_twist(executor);
    const auto command = controller_->getLastReceivedTwist();
    ASSERT_NE(command, nullptr);
    ASSERT_EQ(
      controller_->update(command->header.stamp, rclcpp::Duration::from_seconds(0.01)),
      controller_interface::return_type::OK);
    EXPECT_NEAR(controller_->odometry_.getLinear(), velocity * std::cos(position), 1e-6);
    EXPECT_NEAR(controller_->odometry_.getAngular(), velocity * std::sin(position), 1e-6);
    EXPECT_EQ(1.0, traction_joint_vel_cmd_->get_optional().value());
    EXPECT_EQ(0.0, steering_joint_pos_cmd_->get_optional().value());

    ASSERT_EQ(controller_->get_node()->deactivate().id(), State::PRIMARY_STATE_INACTIVE);
    EXPECT_EQ(0.0, traction_joint_vel_cmd_->get_optional().value());
    EXPECT_EQ(0.0, steering_joint_pos_cmd_->get_optional().value());
    controller_->release_interfaces();
  }
}

TEST_F(TestTricycleController, activate_after_partial_interface_assignment)
{
  ASSERT_EQ(
    InitController(
      traction_joint_name, steering_joint_name, {rclcpp::Parameter("wheel_radius", 1.0)}),
    controller_interface::return_type::OK);
  ASSERT_EQ(controller_->configure().id(), State::PRIMARY_STATE_INACTIVE);

  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(traction_joint_vel_state_, nullptr);
  state_ifs.emplace_back(steering_joint_pos_state_, nullptr);
  std::vector<LoanedCommandInterface> command_ifs;
  command_ifs.emplace_back(traction_joint_vel_cmd_, nullptr);
  controller_->assign_interfaces(std::move(command_ifs), std::move(state_ifs));
  ASSERT_EQ(controller_->on_activate(rclcpp_lifecycle::State()), CallbackReturn::ERROR);
  controller_->release_interfaces();

  assignResources();
  ASSERT_EQ(controller_->get_node()->activate().id(), State::PRIMARY_STATE_ACTIVE);
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(controller_->get_node()->get_node_base_interface());
  publish(1.0, 0.0);
  controller_->wait_for_twist(executor);
  const auto command = controller_->getLastReceivedTwist();
  ASSERT_NE(command, nullptr);
  ASSERT_EQ(
    controller_->update(command->header.stamp, rclcpp::Duration::from_seconds(0.01)),
    controller_interface::return_type::OK);
  EXPECT_EQ(1.0, traction_joint_vel_cmd_->get_optional().value());
  EXPECT_EQ(0.0, steering_joint_pos_cmd_->get_optional().value());

  ASSERT_EQ(controller_->get_node()->deactivate().id(), State::PRIMARY_STATE_INACTIVE);
  EXPECT_EQ(0.0, traction_joint_vel_cmd_->get_optional().value());
  EXPECT_EQ(0.0, steering_joint_pos_cmd_->get_optional().value());
  controller_->release_interfaces();
}

TEST_F(TestTricycleController, cleanup)
{
  ASSERT_EQ(
    InitController(
      traction_joint_name, steering_joint_name,
      {rclcpp::Parameter("wheelbase", 1.2), rclcpp::Parameter("wheel_radius", 0.12)}),
    controller_interface::return_type::OK);

  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(controller_->get_node()->get_node_base_interface());
  auto state = controller_->configure();
  ASSERT_EQ(State::PRIMARY_STATE_INACTIVE, state.id());
  assignResources();

  state = controller_->get_node()->activate();
  ASSERT_EQ(State::PRIMARY_STATE_ACTIVE, state.id());

  waitForSetup(executor);

  // send msg
  const double linear = 1.0;
  const double angular = 1.0;
  publish(linear, angular);
  controller_->wait_for_twist(executor);

  ASSERT_EQ(
    controller_->update(rclcpp::Time(0, 0, RCL_ROS_TIME), rclcpp::Duration::from_seconds(0.01)),
    controller_interface::return_type::OK);

  state = controller_->get_node()->deactivate();
  ASSERT_EQ(State::PRIMARY_STATE_INACTIVE, state.id());

  // should be stopped
  EXPECT_EQ(0.0, steering_joint_pos_cmd_->get_optional().value());
  EXPECT_EQ(0.0, traction_joint_vel_cmd_->get_optional().value());

  state = controller_->get_node()->cleanup();
  ASSERT_EQ(State::PRIMARY_STATE_UNCONFIGURED, state.id());

  // should be stopped
  EXPECT_EQ(0.0, steering_joint_pos_cmd_->get_optional().value());
  EXPECT_EQ(0.0, traction_joint_vel_cmd_->get_optional().value());

  executor.cancel();
}

TEST_F(TestTricycleController, correct_initialization_using_parameters)
{
  ASSERT_EQ(
    InitController(
      traction_joint_name, steering_joint_name,
      {rclcpp::Parameter("wheelbase", 0.4), rclcpp::Parameter("wheel_radius", 1.0)}),
    controller_interface::return_type::OK);

  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(controller_->get_node()->get_node_base_interface());

  auto state = controller_->configure();
  assignResources();

  ASSERT_EQ(State::PRIMARY_STATE_INACTIVE, state.id());
  EXPECT_EQ(position_, steering_joint_pos_cmd_->get_optional().value());
  EXPECT_EQ(velocity_, traction_joint_vel_cmd_->get_optional().value());

  state = controller_->get_node()->activate();
  ASSERT_EQ(State::PRIMARY_STATE_ACTIVE, state.id());

  // send msg
  const double linear = 1.0;
  const double angular = 0.0;
  publish(linear, angular);
  // wait for msg is be published to the system
  controller_->wait_for_twist(executor);

  ASSERT_EQ(
    controller_->update(rclcpp::Time(0, 0, RCL_ROS_TIME), rclcpp::Duration::from_seconds(0.01)),
    controller_interface::return_type::OK);
  EXPECT_EQ(0.0, steering_joint_pos_cmd_->get_optional().value());
  EXPECT_EQ(1.0, traction_joint_vel_cmd_->get_optional().value());

  // deactivated
  // wait so controller process the second point when deactivated
  std::this_thread::sleep_for(std::chrono::milliseconds(500));
  ASSERT_EQ(
    controller_->update(rclcpp::Time(0, 0, RCL_ROS_TIME), rclcpp::Duration::from_seconds(0.01)),
    controller_interface::return_type::OK);
  state = controller_->get_node()->deactivate();
  ASSERT_EQ(state.id(), State::PRIMARY_STATE_INACTIVE);

  EXPECT_EQ(0.0, steering_joint_pos_cmd_->get_optional().value())
    << "Wheels are halted on deactivate()";
  EXPECT_EQ(0.0, traction_joint_vel_cmd_->get_optional().value())
    << "Wheels are halted on deactivate()";

  // cleanup
  state = controller_->get_node()->cleanup();
  ASSERT_EQ(State::PRIMARY_STATE_UNCONFIGURED, state.id());
  EXPECT_EQ(0.0, steering_joint_pos_cmd_->get_optional().value());
  EXPECT_EQ(0.0, traction_joint_vel_cmd_->get_optional().value());

  state = controller_->configure();
  ASSERT_EQ(State::PRIMARY_STATE_INACTIVE, state.id());
  executor.cancel();
}

TEST_F(TestTricycleController, odometry_reset_service)
{
  // 0. correctly initialize and activate the controller
  ASSERT_EQ(
    InitController(
      traction_joint_name, steering_joint_name,
      {rclcpp::Parameter("wheelbase", 0.4), rclcpp::Parameter("wheel_radius", 1.0)}),
    controller_interface::return_type::OK);

  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(controller_->get_node()->get_node_base_interface());
  auto state = controller_->configure();
  assignResources();

  ASSERT_EQ(State::PRIMARY_STATE_INACTIVE, state.id());
  EXPECT_EQ(position_, steering_joint_pos_cmd_->get_optional().value());
  EXPECT_EQ(velocity_, traction_joint_vel_cmd_->get_optional().value());

  state = controller_->get_node()->activate();
  ASSERT_EQ(State::PRIMARY_STATE_ACTIVE, state.id());

  rclcpp::Time test_time(0, 0, RCL_ROS_TIME);
  rclcpp::Duration period = rclcpp::Duration::from_seconds(0.1);

  // 1. move the robot first
  const double linear = 1.0;
  const double angular = 0.0;
  publish(linear, angular);
  controller_->wait_for_twist(executor);
  controller_->update(test_time, period);
  test_time += period;

  // verify it actually moved
  ASSERT_GT(controller_->odometry_.getX(), 0.0);

  // 2. stop the robot and trigger the reset callback
  publish(0.0, 0.0);
  controller_->wait_for_twist(executor);
  auto request = std::make_shared<std_srvs::srv::Empty::Request>();
  auto response = std::make_shared<std_srvs::srv::Empty::Response>();
  controller_->reset_odometry(nullptr, request, response);

  // run update to process the reset request
  // then, verify the odometry values are now back to 0.0
  controller_->update(test_time, period);
  test_time += period;
  EXPECT_EQ(controller_->odometry_.getX(), 0.0);
  EXPECT_EQ(controller_->odometry_.getY(), 0.0);

  // 3. move the robot again
  publish(linear, angular);
  controller_->wait_for_twist(executor);

  // run update twice to ensure velocity integrated and the reset flag was cleared
  controller_->update(test_time, period);
  test_time += period;
  controller_->update(test_time, period);
  ASSERT_GT(controller_->odometry_.getX(), 0.0);

  // 4. deactivate and cleanup
  state = controller_->get_node()->deactivate();
  ASSERT_EQ(state.id(), State::PRIMARY_STATE_INACTIVE);
  state = controller_->get_node()->cleanup();
  ASSERT_EQ(State::PRIMARY_STATE_UNCONFIGURED, state.id());
  state = controller_->configure();
  ASSERT_EQ(State::PRIMARY_STATE_INACTIVE, state.id());
  executor.cancel();
}
