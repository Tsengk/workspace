// Copyright (c) 2021, Stogl Robotics Consulting UG (haftungsbeschränkt)
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/*
 * Authors: Subhas Das, Denis Stogl
 */

#ifndef TEST_FORCE_TORQUE_SENSOR_BROADCASTER_HPP_
#define TEST_FORCE_TORQUE_SENSOR_BROADCASTER_HPP_

#include <gmock/gmock.h>

#include <memory>
#include <string>

#include "controller_interface/test_utils.hpp"

#include "force_torque_sensor_broadcaster/force_torque_sensor_broadcaster.hpp"

using controller_interface::activate_succeeds;
using controller_interface::configure_succeeds;
using controller_interface::deactivate_succeeds;

// subclassing and friending so we can access member variables
class FriendForceTorqueSensorBroadcaster
: public force_torque_sensor_broadcaster::ForceTorqueSensorBroadcaster
{
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, SensorNameParameterNotSet);
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, InterfaceNamesParameterNotSet);
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, FrameIdParameterNotSet);
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, SensorNameParameterIsEmpty);
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, InterfaceNameParameterIsEmpty);

  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, SensorName_ActivateDeactivate_Success);
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, UpdateTest);
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, SensorStatePublishTest);

  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, SensorFilterChain_Configure_Success);
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, SensorFilterChain_ActivateDeactivate_Success);
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, SensorFilterChain_Update_Success);
  FRIEND_TEST(ForceTorqueSensorBroadcasterTest, SensorFilterChain_Publish_Success);
};

class ForceTorqueSensorBroadcasterTest : public ::testing::Test
{
public:
  static void SetUpTestCase();
  static void TearDownTestCase();

  void SetUp();
  void TearDown();

  void SetUpFTSBroadcaster(std::string node_name);

protected:
  const std::string sensor_name_ = "fts_sensor";
  const std::string frame_id_ = "fts_sensor_frame";
  const std::array<double, 6> sensor_values_ = {{1.1, 2.2, 3.3, 4.4, 5.5, 6.6}};

  hardware_interface::StateInterface::SharedPtr fts_force_x_;
  hardware_interface::StateInterface::SharedPtr fts_force_y_;
  hardware_interface::StateInterface::SharedPtr fts_force_z_;
  hardware_interface::StateInterface::SharedPtr fts_torque_x_;
  hardware_interface::StateInterface::SharedPtr fts_torque_y_;
  hardware_interface::StateInterface::SharedPtr fts_torque_z_;

  std::unique_ptr<FriendForceTorqueSensorBroadcaster> fts_broadcaster_;

  void subscribe_and_get_message(
    geometry_msgs::msg::WrenchStamped & wrench_msg, std::string & topic_name);
};

#endif  // TEST_FORCE_TORQUE_SENSOR_BROADCASTER_HPP_
