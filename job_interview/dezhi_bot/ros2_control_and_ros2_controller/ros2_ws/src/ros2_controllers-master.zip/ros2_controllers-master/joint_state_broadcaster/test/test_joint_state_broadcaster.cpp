// Copyright 2020 PAL Robotics SL.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <cstddef>

#include <atomic>
#include <functional>
#include <memory>
#include <numeric>
#include <shared_mutex>
#include <string>
#include <thread>
#include <tuple>
#include <utility>
#include <vector>

#include "gmock/gmock.h"

#include "hardware_interface/loaned_state_interface.hpp"
#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "lifecycle_msgs/msg/state.hpp"
#include "rclcpp/executor.hpp"
#include "rclcpp/executors.hpp"
#include "rclcpp/utilities.hpp"
#include "realtime_tools/realtime_helpers.hpp"
#include "ros2_control_test_assets/descriptions.hpp"
#include "test_joint_state_broadcaster.hpp"

using hardware_interface::HW_IF_EFFORT;
using hardware_interface::HW_IF_POSITION;
using hardware_interface::HW_IF_VELOCITY;
using hardware_interface::LoanedStateInterface;
using std::placeholders::_1;
using testing::Each;
using testing::ElementsAreArray;
using testing::IsEmpty;
using testing::SizeIs;

void JointStateBroadcasterTest::SetUpTestCase() { rclcpp::init(0, nullptr); }

void JointStateBroadcasterTest::TearDownTestCase() { rclcpp::shutdown(); }

void JointStateBroadcasterTest::SetUp()
{
  // initialize broadcaster
  state_broadcaster_ = std::make_unique<FriendJointStateBroadcaster>();

  joint_1_pos_state_ =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[0], interface_names_[0]);
  std::ignore = joint_1_pos_state_->set_value(joint_values_[0]);
  joint_2_pos_state_ =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[1], interface_names_[0]);
  std::ignore = joint_2_pos_state_->set_value(joint_values_[1]);
  joint_3_pos_state_ =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[2], interface_names_[0]);
  std::ignore = joint_3_pos_state_->set_value(joint_values_[2]);
  joint_1_vel_state_ =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[0], interface_names_[1]);
  std::ignore = joint_1_vel_state_->set_value(joint_values_[0]);
  joint_2_vel_state_ =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[1], interface_names_[1]);
  std::ignore = joint_2_vel_state_->set_value(joint_values_[1]);
  joint_3_vel_state_ =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[2], interface_names_[1]);
  std::ignore = joint_3_vel_state_->set_value(joint_values_[2]);
  joint_1_eff_state_ =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[0], interface_names_[2]);
  std::ignore = joint_1_eff_state_->set_value(joint_values_[0]);
  joint_2_eff_state_ =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[1], interface_names_[2]);
  std::ignore = joint_2_eff_state_->set_value(joint_values_[1]);
  joint_3_eff_state_ =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[2], interface_names_[2]);
  std::ignore = joint_3_eff_state_->set_value(joint_values_[2]);

  joint_X_custom_state =
    std::make_shared<hardware_interface::StateInterface>(joint_names_[0], custom_interface_name_);
  std::ignore = joint_X_custom_state->set_value(custom_joint_value_);
}

void JointStateBroadcasterTest::TearDown() { state_broadcaster_.reset(nullptr); }

void JointStateBroadcasterTest::SetUpStateBroadcaster(
  const std::vector<std::string> & joint_names, const std::vector<std::string> & interfaces,
  const std::vector<rclcpp::Parameter> & parameter_overrides)
{
  init_broadcaster_and_set_parameters(
    kThreeJointURDF, joint_names, interfaces, parameter_overrides);
  assign_state_interfaces(joint_names, interfaces);
}

void JointStateBroadcasterTest::init_broadcaster_and_set_parameters(
  const std::string & robot_description, const std::vector<std::string> & joint_names,
  const std::vector<std::string> & interfaces,
  const std::vector<rclcpp::Parameter> & parameter_overrides)
{
  auto local_parameter_overrides = parameter_overrides;
  local_parameter_overrides.push_back(rclcpp::Parameter("frame_id", frame_id_));
  local_parameter_overrides.push_back(rclcpp::Parameter("joints", joint_names));
  local_parameter_overrides.push_back(rclcpp::Parameter("interfaces", interfaces));

  controller_interface::ControllerInterfaceParams params;
  params.controller_name = "joint_state_broadcaster";
  params.robot_description = robot_description;
  params.update_rate = 0;
  params.node_namespace = "";
  params.node_options = state_broadcaster_->define_custom_node_options()
                          .allow_undeclared_parameters(false)
                          .parameter_overrides(local_parameter_overrides)
                          .automatically_declare_parameters_from_overrides(false);
  ;
  const auto result = state_broadcaster_->init(params);
  ASSERT_EQ(result, controller_interface::return_type::OK);
}

void JointStateBroadcasterTest::assign_state_interfaces(
  const std::vector<std::string> & joint_names, const std::vector<std::string> & interfaces)
{
  std::vector<LoanedStateInterface> state_ifs;

  if (joint_names.empty() || interfaces.empty())
  {
    state_ifs.emplace_back(joint_1_pos_state_);
    state_ifs.emplace_back(joint_2_pos_state_);
    state_ifs.emplace_back(joint_3_pos_state_);
    state_ifs.emplace_back(joint_1_vel_state_);
    state_ifs.emplace_back(joint_2_vel_state_);
    state_ifs.emplace_back(joint_3_vel_state_);
    state_ifs.emplace_back(joint_1_eff_state_);
    state_ifs.emplace_back(joint_2_eff_state_);
    state_ifs.emplace_back(joint_3_eff_state_);
  }
  else
  {
    for (const auto & joint : joint_names)
    {
      for (const auto & interface : interfaces)
      {
        if (joint == joint_names_[0] && interface == interface_names_[0])
        {
          state_ifs.emplace_back(joint_1_pos_state_);
        }
        if (joint == joint_names_[1] && interface == interface_names_[0])
        {
          state_ifs.emplace_back(joint_2_pos_state_);
        }
        if (joint == joint_names_[2] && interface == interface_names_[0])
        {
          state_ifs.emplace_back(joint_3_pos_state_);
        }
        if (joint == joint_names_[0] && interface == interface_names_[1])
        {
          state_ifs.emplace_back(joint_1_vel_state_);
        }
        if (joint == joint_names_[1] && interface == interface_names_[1])
        {
          state_ifs.emplace_back(joint_2_vel_state_);
        }
        if (joint == joint_names_[2] && interface == interface_names_[1])
        {
          state_ifs.emplace_back(joint_3_vel_state_);
        }
        if (joint == joint_names_[0] && interface == interface_names_[2])
        {
          state_ifs.emplace_back(joint_1_eff_state_);
        }
        if (joint == joint_names_[1] && interface == interface_names_[2])
        {
          state_ifs.emplace_back(joint_2_eff_state_);
        }
        if (joint == joint_names_[2] && interface == interface_names_[2])
        {
          state_ifs.emplace_back(joint_3_eff_state_);
        }
        if (interface == custom_interface_name_)
        {
          state_ifs.emplace_back(joint_X_custom_state);
        }
      }
    }
  }

  state_broadcaster_->assign_interfaces({}, std::move(state_ifs));
}

TEST_F(JointStateBroadcasterTest, ActivateEmptyTest)
{
  // publisher not initialized yet
  ASSERT_FALSE(state_broadcaster_->joint_state_publisher_);

  SetUpStateBroadcaster();
  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = joint_names_.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  // 3 URDF joints (joint1, joint2, joint3) × 3 standard interfaces
  ASSERT_THAT(state_if_conf.names, SizeIs(joint_names_.size() * 3));
  EXPECT_EQ(
    state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL_BEST_EFFORT);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(joint_names_));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
}

TEST_F(JointStateBroadcasterTest, ReactivateTheControllerWithDifferentInterfacesTest)
{
  // publisher not initialized yet
  ASSERT_FALSE(state_broadcaster_->joint_state_publisher_);

  SetUpStateBroadcaster();
  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = joint_names_.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  // 3 URDF joints × 3 standard interfaces
  ASSERT_THAT(state_if_conf.names, SizeIs(joint_names_.size() * 3));
  EXPECT_EQ(
    state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL_BEST_EFFORT);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(joint_names_));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));

  // Now deactivate and activate with only 2 set of joints and interfaces (to create as in one of
  // the interface is unavailable)
  ASSERT_TRUE(deactivate_succeeds(state_broadcaster_));
  const std::vector<std::string> JOINT_NAMES = {"joint1", "joint2"};
  assign_state_interfaces(JOINT_NAMES, interface_names_);

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS_WITH_ONE_DEACTIVATED = JOINT_NAMES.size();

  // check interface configuration
  cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  state_if_conf = state_broadcaster_->state_interface_configuration();
  // params are still cleared from configure (URDF mode), so still INDIVIDUAL_BEST_EFFORT
  ASSERT_THAT(state_if_conf.names, SizeIs(joint_names_.size() * 3));
  EXPECT_EQ(
    state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL_BEST_EFFORT);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & new_joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(new_joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(new_joint_state_msg.name, ElementsAreArray(JOINT_NAMES));
  ASSERT_THAT(new_joint_state_msg.position, SizeIs(NUM_JOINTS_WITH_ONE_DEACTIVATED));
  ASSERT_THAT(new_joint_state_msg.velocity, SizeIs(NUM_JOINTS_WITH_ONE_DEACTIVATED));
  ASSERT_THAT(new_joint_state_msg.effort, SizeIs(NUM_JOINTS_WITH_ONE_DEACTIVATED));
}

TEST_F(JointStateBroadcasterTest, ActivateTestWithoutJointsParameter)
{
  const std::vector<std::string> JOINT_NAMES = {};
  const std::vector<std::string> IF_NAMES = {interface_names_[0]};
  SetUpStateBroadcaster(JOINT_NAMES, IF_NAMES);

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = joint_names_.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  // 3 URDF joints (joint1, joint2, joint3) × 3 standard interfaces
  ASSERT_THAT(state_if_conf.names, SizeIs(joint_names_.size() * 3));
  EXPECT_EQ(
    state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL_BEST_EFFORT);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(joint_names_));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
}

TEST_F(JointStateBroadcasterTest, ActivateTestWithoutJointsParameterInvalidURDF)
{
  const std::vector<std::string> JOINT_NAMES = {};
  const std::vector<std::string> IF_NAMES = {interface_names_[0]};
  init_broadcaster_and_set_parameters("<invalid_urdf></invalid_urdf>", JOINT_NAMES, IF_NAMES);
  assign_state_interfaces(JOINT_NAMES, IF_NAMES);

  // URDF mode (joints empty) with an unparsable robot description must fail at configure
  ASSERT_FALSE(configure_succeeds(state_broadcaster_));
}

TEST_F(JointStateBroadcasterTest, ActivateTestWithoutJointsParameterWithRobotDescription)
{
  const std::vector<std::string> JOINT_NAMES = {};
  const std::vector<std::string> IF_NAMES = {interface_names_[0]};

  std::string urdf_to_test =
    std::string(ros2_control_test_assets::urdf_head_continuous_with_limits) +
    ros2_control_test_assets::hardware_resources + ros2_control_test_assets::urdf_tail;
  const std::vector<std::string> joint_in_urdf({"joint1", "joint2"});
  init_broadcaster_and_set_parameters(urdf_to_test, JOINT_NAMES, IF_NAMES);
  assign_state_interfaces(JOINT_NAMES, IF_NAMES);

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = joint_in_urdf.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  // URDF loaded: request specific joints with BEST_EFFORT (3 standard interfaces per joint)
  ASSERT_THAT(state_if_conf.names, SizeIs(joint_in_urdf.size() * 3));
  EXPECT_EQ(
    state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL_BEST_EFFORT);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(joint_in_urdf));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
}

TEST_F(JointStateBroadcasterTest, ActivateTestWithJointsAndNoInterfaces)
{
  const std::vector<std::string> JOINT_NAMES = {"joint1"};
  const std::vector<std::string> IF_NAMES = {};
  std::string urdf_to_test =
    std::string(ros2_control_test_assets::urdf_head_continuous_with_limits) +
    ros2_control_test_assets::hardware_resources + ros2_control_test_assets::urdf_tail;
  const std::vector<std::string> joint_in_urdf({"joint1", "joint2"});
  init_broadcaster_and_set_parameters(urdf_to_test, JOINT_NAMES, IF_NAMES);
  assign_state_interfaces(JOINT_NAMES, IF_NAMES);

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = joint_in_urdf.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  // URDF loaded: request specific joints with BEST_EFFORT (3 standard interfaces per joint)
  ASSERT_THAT(state_if_conf.names, SizeIs(joint_in_urdf.size() * 3));
  EXPECT_EQ(
    state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL_BEST_EFFORT);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(joint_in_urdf));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
}

TEST_F(JointStateBroadcasterTest, ActivateTestWithJointsAndInterfaces)
{
  const std::vector<std::string> JOINT_NAMES = {"joint1"};
  const std::vector<std::string> IF_NAMES = interface_names_;
  std::string urdf_to_test =
    std::string(ros2_control_test_assets::urdf_head_continuous_with_limits) +
    ros2_control_test_assets::hardware_resources + ros2_control_test_assets::urdf_tail;
  init_broadcaster_and_set_parameters(urdf_to_test, JOINT_NAMES, IF_NAMES);
  assign_state_interfaces(JOINT_NAMES, IF_NAMES);

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = JOINT_NAMES.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  ASSERT_THAT(state_if_conf.names, SizeIs(JOINT_NAMES.size() * IF_NAMES.size()));
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(JOINT_NAMES));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
}

TEST_F(JointStateBroadcasterTest, ActivateTestWithoutInterfacesParameter)
{
  const std::vector<std::string> JOINT_NAMES = {"joint1"};
  const std::vector<std::string> IF_NAMES = {};
  SetUpStateBroadcaster(JOINT_NAMES, IF_NAMES);

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = joint_names_.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  // 3 URDF joints (joint1, joint2, joint3) × 3 standard interfaces
  ASSERT_THAT(state_if_conf.names, SizeIs(joint_names_.size() * 3));
  EXPECT_EQ(
    state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL_BEST_EFFORT);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(joint_names_));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
}

TEST_F(JointStateBroadcasterTest, ActivateDeactivateTestTwoJointsOneInterface)
{
  const std::vector<std::string> JOINT_NAMES = {joint_names_[0], joint_names_[1]};
  const std::vector<std::string> IF_NAMES = {interface_names_[0]};
  SetUpStateBroadcaster(JOINT_NAMES, IF_NAMES);

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = JOINT_NAMES.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  ASSERT_THAT(state_if_conf.names, SizeIs(JOINT_NAMES.size() * IF_NAMES.size()));
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(JOINT_NAMES));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  for (auto i = 0ul; i < NUM_JOINTS; ++i)
  {
    ASSERT_TRUE(std::isnan(joint_state_msg.velocity[i]));
  }
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
  for (auto i = 0ul; i < NUM_JOINTS; ++i)
  {
    ASSERT_TRUE(std::isnan(joint_state_msg.effort[i]));
  }

  // deactivate
  ASSERT_TRUE(deactivate_succeeds(state_broadcaster_));
  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  // check interface configuration
  cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  state_if_conf = state_broadcaster_->state_interface_configuration();
  ASSERT_THAT(
    state_if_conf.names, SizeIs(JOINT_NAMES.size() * IF_NAMES.size()));  // does not change
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);
}

TEST_F(JointStateBroadcasterTest, ActivateTestOneJointTwoInterfaces)
{
  const std::vector<std::string> JOINT_NAMES = {joint_names_[0]};
  const std::vector<std::string> IF_NAMES = {interface_names_[0], interface_names_[1]};
  SetUpStateBroadcaster(JOINT_NAMES, IF_NAMES);

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = JOINT_NAMES.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  ASSERT_THAT(state_if_conf.names, SizeIs(JOINT_NAMES.size() * IF_NAMES.size()));
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(JOINT_NAMES));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
  for (auto i = 0ul; i < NUM_JOINTS; ++i)
  {
    ASSERT_TRUE(std::isnan(joint_state_msg.effort[i]));
  }
}

TEST_F(JointStateBroadcasterTest, ActivateTestTwoJointTwoInterfacesAllMissing)
{
  const std::vector<std::string> JOINT_NAMES = {joint_names_[0], joint_names_[1]};
  const std::vector<std::string> IF_NAMES = {interface_names_[0], interface_names_[1]};

  init_broadcaster_and_set_parameters("", JOINT_NAMES, {interface_names_[0], interface_names_[1]});

  // assign state with interfaces which are not set in parameters --> We should actually not assign
  // anything because CM will also not do that
  // assign_state_interfaces(JOINT_NAMES, {interface_names_[2]});

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  // is none of requested interfaces do not exist, the controller will not be activated
  try
  {
    activate_succeeds(state_broadcaster_);
    FAIL() << "Expected std::runtime_error to be thrown";
  }
  catch (const std::runtime_error & e)
  {
    EXPECT_STREQ(
      e.what(),
      "Unexpected controller state in activate_succeeds: 1");  // State goes to ErrorProcessing then
                                                               // Unconfigured(1)
  }
  catch (...)
  {
    FAIL() << "Expected std::runtime_error, but a different exception was thrown";
  }
}

TEST_F(JointStateBroadcasterTest, ActivateTestTwoJointTwoInterfacesOneMissing)
{
  const std::vector<std::string> JOINT_NAMES = {joint_names_[0], joint_names_[1]};
  const std::vector<std::string> IF_NAMES = {interface_names_[0], interface_names_[1]};

  init_broadcaster_and_set_parameters("", JOINT_NAMES, {interface_names_[0], interface_names_[1]});

  // Manually assign existing interfaces --> one we need is missing
  std::vector<LoanedStateInterface> state_ifs;

  state_ifs.emplace_back(joint_1_pos_state_);
  // Missing Joint 1 vel state interface
  state_ifs.emplace_back(joint_2_pos_state_);
  state_ifs.emplace_back(joint_2_vel_state_);

  state_broadcaster_->assign_interfaces({}, std::move(state_ifs));

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  // here a warning output is expected!
  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = JOINT_NAMES.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  ASSERT_THAT(state_if_conf.names, SizeIs(JOINT_NAMES.size() * IF_NAMES.size()));
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->realtime_joint_state_publisher_);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(JOINT_NAMES));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
  // velocity for joint 1 should be nan because state interface does not exit
  ASSERT_TRUE(std::isnan(joint_state_msg.velocity[0]));
  for (auto i = 0ul; i < NUM_JOINTS; ++i)
  {
    ASSERT_TRUE(std::isnan(joint_state_msg.effort[i]));
  }
}

TEST_F(JointStateBroadcasterTest, TestCustomInterfaceWithoutMapping)
{
  const std::vector<std::string> JOINT_NAMES = {joint_names_[0]};
  const std::vector<std::string> IF_NAMES = {custom_interface_name_};
  SetUpStateBroadcaster(JOINT_NAMES, IF_NAMES);

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  ASSERT_THAT(state_if_conf.names, SizeIs(JOINT_NAMES.size() * IF_NAMES.size()));
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, SizeIs(0));
  ASSERT_THAT(joint_state_msg.position, SizeIs(0));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(0));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(0));

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->joint_state_publisher_);
}

TEST_F(JointStateBroadcasterTest, TestCustomInterfaceMapping)
{
  const std::vector<std::string> JOINT_NAMES = {joint_names_[0]};
  const std::vector<std::string> IF_NAMES = {custom_interface_name_};
  SetUpStateBroadcaster(
    JOINT_NAMES, IF_NAMES,
    {rclcpp::Parameter(
      std::string("map_interface_to_joint_state.") + HW_IF_POSITION, custom_interface_name_)});

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = JOINT_NAMES.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  ASSERT_THAT(state_if_conf.names, SizeIs(JOINT_NAMES.size() * IF_NAMES.size()));
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(JOINT_NAMES));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  for (auto i = 0ul; i < NUM_JOINTS; ++i)
  {
    ASSERT_TRUE(std::isnan(joint_state_msg.velocity[i]));
  }
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
  for (auto i = 0ul; i < NUM_JOINTS; ++i)
  {
    ASSERT_TRUE(std::isnan(joint_state_msg.effort[i]));
  }

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->joint_state_publisher_);
}

TEST_F(JointStateBroadcasterTest, TestCustomInterfaceMappingIgnoredWhenVelocityInterfaceIsRequested)
{
  constexpr auto custom_velocity_interface = "derived_velocity";
  const std::vector<std::string> JOINT_NAMES = {joint_names_[0]};
  const std::vector<std::string> IF_NAMES = {HW_IF_VELOCITY};
  SetUpStateBroadcaster(
    JOINT_NAMES, IF_NAMES,
    {rclcpp::Parameter(
      std::string("map_interface_to_joint_state.") + HW_IF_VELOCITY, custom_velocity_interface)});

  // configure ok; a warning is expected because the custom velocity mapping is ignored
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  const auto velocity_mapping =
    state_broadcaster_->map_interface_to_joint_state_.find(HW_IF_VELOCITY);
  ASSERT_NE(velocity_mapping, state_broadcaster_->map_interface_to_joint_state_.end());
  EXPECT_EQ(velocity_mapping->second, HW_IF_VELOCITY);
  EXPECT_EQ(state_broadcaster_->map_interface_to_joint_state_.count(custom_velocity_interface), 0u);

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  const size_t NUM_JOINTS = JOINT_NAMES.size();

  // check interface configuration
  auto cmd_if_conf = state_broadcaster_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, IsEmpty());
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::NONE);
  auto state_if_conf = state_broadcaster_->state_interface_configuration();
  ASSERT_THAT(state_if_conf.names, SizeIs(JOINT_NAMES.size() * IF_NAMES.size()));
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(JOINT_NAMES));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_TRUE(std::isnan(joint_state_msg.position[0]));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_TRUE(std::isnan(joint_state_msg.velocity[0]));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
  ASSERT_TRUE(std::isnan(joint_state_msg.effort[0]));

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->joint_state_publisher_);
}

TEST_F(JointStateBroadcasterTest, TestCustomInterfaceMappingUpdate)
{
  const std::vector<std::string> JOINT_NAMES = {joint_names_[0]};
  const std::vector<std::string> IF_NAMES = {custom_interface_name_};
  SetUpStateBroadcaster(
    JOINT_NAMES, IF_NAMES,
    {rclcpp::Parameter(
      std::string("map_interface_to_joint_state.") + HW_IF_POSITION, custom_interface_name_)});

  sensor_msgs::msg::JointState joint_state_msg;
  activate_and_get_joint_state_message("joint_states", joint_state_msg);

  const size_t NUM_JOINTS = JOINT_NAMES.size();

  // joint state initialized
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(JOINT_NAMES));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_EQ(joint_state_msg.position[0], custom_joint_value_);
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  for (auto i = 0ul; i < NUM_JOINTS; ++i)
  {
    ASSERT_TRUE(std::isnan(joint_state_msg.velocity[i]));
  }
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
  for (auto i = 0ul; i < NUM_JOINTS; ++i)
  {
    ASSERT_TRUE(std::isnan(joint_state_msg.effort[i]));
  }

  // publisher initialized
  ASSERT_TRUE(state_broadcaster_->joint_state_publisher_);
}

TEST_F(JointStateBroadcasterTest, UpdateTest)
{
  SetUpStateBroadcaster();

  ASSERT_TRUE(configure_succeeds(state_broadcaster_));
  ASSERT_TRUE(activate_succeeds(state_broadcaster_));
  ASSERT_EQ(
    state_broadcaster_->update(rclcpp::Time(0), rclcpp::Duration::from_seconds(0.01)),
    controller_interface::return_type::OK);
}

TEST_F(JointStateBroadcasterTest, UpdatePerformanceTest)
{
  // Generate a URDF with all 29 test joints (joint_1 ... joint_29)
  std::string perf_urdf =
    "<?xml version=\"1.0\" ?><robot name=\"PerfRobot\"><link name=\"base_link\"/>";
  for (auto joint = 1u; joint < 30; ++joint)
  {
    const auto jname = "joint_" + std::to_string(joint);
    const auto parent = joint == 1u ? "base_link" : "link_" + std::to_string(joint - 1);
    const auto child = "link_" + std::to_string(joint);
    perf_urdf += "<link name=\"" + child + "\"/>";
    perf_urdf += "<joint name=\"" + jname + "\" type=\"revolute\">";
    perf_urdf += "<parent link=\"" + parent + "\"/><child link=\"" + child + "\"/>";
    perf_urdf += "<limit effort=\"1\" velocity=\"1\" lower=\"-3.14\" upper=\"3.14\"/>";
    perf_urdf += "<axis xyz=\"0 0 1\"/></joint>";
  }
  perf_urdf += "</robot>";

  controller_interface::ControllerInterfaceParams params;
  params.controller_name = "joint_state_broadcaster";
  params.robot_description = perf_urdf;
  params.update_rate = 0;
  params.node_namespace = "";
  params.node_options = state_broadcaster_->define_custom_node_options();
  const auto result = state_broadcaster_->init(params);
  ASSERT_EQ(result, controller_interface::return_type::OK);

  custom_joint_value_ = 12.34;

  // build our own test interfaces: robot has ~500 state interfaces
  for (auto joint = 1u; joint < 30; ++joint)
  {
    const auto joint_name = "joint_" + std::to_string(joint);

    // standard
    auto state_position =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "position");
    std::ignore = state_position->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_position);
    auto state_velocity =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "velocity");
    std::ignore = state_velocity->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_velocity);
    auto state_effort = std::make_shared<hardware_interface::StateInterface>(joint_name, "effort");
    std::ignore = state_effort->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_effort);

    // non standard
    auto state_mode = std::make_shared<hardware_interface::StateInterface>(joint_name, "mode");
    std::ignore = state_mode->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_mode);
    auto state_absolute_position =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "absolute_position");
    std::ignore = state_absolute_position->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_absolute_position);
    auto state_acceleration =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "acceleration");
    std::ignore = state_acceleration->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_acceleration);
    auto state_current =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "current");
    std::ignore = state_current->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_current);
    auto state_torque = std::make_shared<hardware_interface::StateInterface>(joint_name, "torque");
    std::ignore = state_torque->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_torque);
    auto state_force = std::make_shared<hardware_interface::StateInterface>(joint_name, "force");
    std::ignore = state_force->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_force);
    auto state_temperature_board =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "temperature_board");
    std::ignore = state_temperature_board->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_temperature_board);
    auto state_temperature_motor =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "temperature_motor");
    std::ignore = state_temperature_motor->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_temperature_motor);

    auto state_position_kd =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "position.kd");
    std::ignore = state_position_kd->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_position_kd);
    auto state_position_ki =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "position.ki");
    std::ignore = state_position_ki->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_position_ki);
    auto state_position_kp =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "position.kp");
    std::ignore = state_position_kp->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_position_kp);

    auto state_velocity_kd =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "velocity.kd");
    std::ignore = state_velocity_kd->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_velocity_kd);
    auto state_velocity_ki =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "velocity.ki");
    std::ignore = state_velocity_ki->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_velocity_ki);
    auto state_velocity_kp =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "velocity.kp");
    std::ignore = state_velocity_kp->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_velocity_kp);

    auto state_current_kd =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "current.kd");
    std::ignore = state_current_kd->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_current_kd);
    auto state_current_ki =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "current.ki");
    std::ignore = state_current_ki->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_current_ki);
    auto state_current_kp =
      std::make_shared<hardware_interface::StateInterface>(joint_name, "current.kp");
    std::ignore = state_current_kp->set_value(custom_joint_value_);
    test_interfaces_.emplace_back(state_current_kp);
  }

  RCLCPP_INFO(
    state_broadcaster_->get_node()->get_logger(), "Number of test interfaces: %zu",
    test_interfaces_.size());

  std::vector<LoanedStateInterface> state_interfaces;
  for (const auto & tif : test_interfaces_)
  {
    state_interfaces.emplace_back(tif, nullptr);
  }

  state_broadcaster_->assign_interfaces({}, std::move(state_interfaces));

  ASSERT_TRUE(configure_succeeds(state_broadcaster_));
  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  if (!realtime_tools::configure_sched_fifo(50))
  {
    RCLCPP_WARN(
      state_broadcaster_->get_node()->get_logger(),
      "Could not enable FIFO RT scheduling policy: with error number <%i>(%s)", errno,
      strerror(errno));
  }

  constexpr auto kNumSamples = 10000u;
  std::vector<int64_t> measures;
  for (auto i = 0u; i < kNumSamples; ++i)
  {
    const auto now = std::chrono::steady_clock::now();

    ASSERT_EQ(
      state_broadcaster_->update(rclcpp::Time(0), rclcpp::Duration::from_seconds(0.01)),
      controller_interface::return_type::OK);

    // print time taken
    const auto elapsed = std::chrono::steady_clock::now() - now;
    const auto elapsed_us = std::chrono::duration_cast<std::chrono::microseconds>(elapsed);

    measures.push_back(elapsed_us.count());
  }

  const auto average =
    std::accumulate(measures.begin(), measures.end(), 0.0) / static_cast<double>(measures.size());
  const auto variance = std::accumulate(
                          measures.begin(), measures.end(), 0.0, [average](double accum, double x)
                          { return accum + (x - average) * (x - average); }) /
                        static_cast<double>(measures.size());

  RCLCPP_INFO(state_broadcaster_->get_node()->get_logger(), "Average update time: %lf us", average);
  RCLCPP_INFO(state_broadcaster_->get_node()->get_logger(), "Variance: %lf us", variance);
}

void JointStateBroadcasterTest::activate_and_get_joint_state_message(
  const std::string & topic, sensor_msgs::msg::JointState & joint_state_msg)
{
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));
  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  sensor_msgs::msg::JointState::SharedPtr received_msg;
  rclcpp::Node test_node("test_node");
  auto subs_callback = [&](const sensor_msgs::msg::JointState::SharedPtr msg)
  { received_msg = msg; };
  auto subscription =
    test_node.create_subscription<sensor_msgs::msg::JointState>(topic, 10, subs_callback);

  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(test_node.get_node_base_interface());

  // call update to publish the test value
  // since update doesn't guarantee a published message, republish until received
  int max_sub_check_loop_count = 5;  // max number of tries for pub/sub loop
  while (max_sub_check_loop_count--)
  {
    state_broadcaster_->update(rclcpp::Time(0), rclcpp::Duration::from_seconds(0.01));
    const auto timeout = std::chrono::milliseconds{5};
    const auto until = test_node.get_clock()->now() + timeout;
    while (!received_msg && test_node.get_clock()->now() < until)
    {
      executor.spin_some();
      std::this_thread::sleep_for(std::chrono::microseconds(10));
    }
    // check if message has been received
    if (received_msg.get())
    {
      break;
    }
  }
  ASSERT_GE(max_sub_check_loop_count, 0) << "Test was unable to publish a message through "
                                            "controller/broadcaster update loop";
  ASSERT_TRUE(received_msg);

  // take message from subscription
  joint_state_msg = *received_msg;
}

void JointStateBroadcasterTest::test_published_joint_state_message(const std::string & topic)
{
  sensor_msgs::msg::JointState joint_state_msg;
  activate_and_get_joint_state_message(topic, joint_state_msg);

  const size_t NUM_JOINTS = joint_names_.size();
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, SizeIs(NUM_JOINTS));
  // the order in the message may be different
  // we only check that all values in this test are present in the message
  // and that it is the same across the interfaces
  // for test purposes they are mapped to the same doubles
  ASSERT_THAT(joint_state_msg.position, ElementsAreArray(joint_values_));
  ASSERT_THAT(joint_state_msg.velocity, ElementsAreArray(joint_state_msg.position));
  ASSERT_THAT(joint_state_msg.effort, ElementsAreArray(joint_state_msg.position));
}

TEST_F(JointStateBroadcasterTest, JointStatePublishTest)
{
  SetUpStateBroadcaster();

  test_published_joint_state_message("joint_states");
}

TEST_F(JointStateBroadcasterTest, JointStatePublishTestLocalTopic)
{
  SetUpStateBroadcaster({}, {}, {rclcpp::Parameter("use_local_topics", true)});

  test_published_joint_state_message("joint_state_broadcaster/joint_states");
}

TEST_F(JointStateBroadcasterTest, ExtraJointStatePublishTest)
{
  // publisher not initialized yet
  ASSERT_FALSE(state_broadcaster_->realtime_joint_state_publisher_);

  // Add extra joints as parameters
  const std::vector<std::string> extra_joint_names = {"extra1", "extra2", "extra3"};
  SetUpStateBroadcaster({}, {}, {rclcpp::Parameter("extra_joints", extra_joint_names)});

  // configure ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));

  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  std::vector<std::string> all_joint_names = joint_names_;
  all_joint_names.insert(all_joint_names.end(), extra_joint_names.begin(), extra_joint_names.end());
  const size_t NUM_JOINTS = all_joint_names.size();

  // joint state initialized
  const auto & joint_state_msg = state_broadcaster_->joint_state_msg_;
  ASSERT_EQ(joint_state_msg.header.frame_id, frame_id_);
  ASSERT_THAT(joint_state_msg.name, ElementsAreArray(all_joint_names));
  ASSERT_THAT(joint_state_msg.position, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.velocity, SizeIs(NUM_JOINTS));
  ASSERT_THAT(joint_state_msg.effort, SizeIs(NUM_JOINTS));
}

TEST_F(JointStateBroadcasterTest, NoThrowWithBooleanInterfaceTest)
{
  const std::string JOINT_NAME = joint_names_[0];
  const std::string IF_NAME = "is_moving";
  SetUpStateBroadcaster({JOINT_NAME}, {IF_NAME});

  init_broadcaster_and_set_parameters("", {JOINT_NAME}, {IF_NAME});

  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(joint_1_moving_state_);
  state_broadcaster_->assign_interfaces({}, std::move(state_ifs));

  // configure and activate ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));
  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  // update should not throw
  ASSERT_NO_THROW(
    state_broadcaster_->update(rclcpp::Time(0), rclcpp::Duration::from_seconds(0.01)));
}

TEST_F(JointStateBroadcasterTest, NoThrowWithBooleanAndDoubleInterfaceTest)
{
  const std::string JOINT_NAME = joint_names_[0];
  const std::string IF_NAME = "is_moving";
  SetUpStateBroadcaster({JOINT_NAME}, {IF_NAME});

  init_broadcaster_and_set_parameters("", {JOINT_NAME}, {IF_NAME});

  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(joint_1_moving_state_);
  state_ifs.emplace_back(joint_1_pos_state_);
  state_ifs.emplace_back(joint_1_vel_state_);
  state_ifs.emplace_back(joint_1_eff_state_);
  state_broadcaster_->assign_interfaces({}, std::move(state_ifs));

  // configure and activate ok
  ASSERT_TRUE(configure_succeeds(state_broadcaster_));
  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  // update should not throw
  ASSERT_NO_THROW(
    state_broadcaster_->update(rclcpp::Time(0), rclcpp::Duration::from_seconds(0.01)));

  // joint states
  ASSERT_THAT(state_broadcaster_->joint_state_msg_.name, ElementsAreArray({joint_names_[0]}));
  ASSERT_THAT(state_broadcaster_->joint_state_msg_.position, SizeIs(1));
  ASSERT_THAT(state_broadcaster_->joint_state_msg_.velocity, SizeIs(1));
  ASSERT_THAT(state_broadcaster_->joint_state_msg_.effort, SizeIs(1));
}

// Regression test: when a double interface temporarily fails to be read
// (get_optional returns nullopt as it is unable to lock), map_index must still advance so that
// subsequent interfaces are written to the correct mapped_values_ indexes.
//
// Without the fix, if state_interfaces_[i] returns nullopt, the next interface's value is
// written into index i instead of index i+1, corrupting all subsequent joint state values.
TEST_F(JointStateBroadcasterTest, CorrectMappingWhenInterfaceReadFailsTest)
{
  const std::string JOINT_NAMES[] = {"joint1", "joint2", "joint3"};
  const double INIT_POS[] = {1.1, 2.2, 3.3};

  auto j1 = std::make_shared<hardware_interface::StateInterface>(
    JOINT_NAMES[0], HW_IF_POSITION, "double", std::to_string(INIT_POS[0]));
  auto j2 = std::make_shared<hardware_interface::StateInterface>(
    JOINT_NAMES[1], HW_IF_POSITION, "double", std::to_string(INIT_POS[1]));
  auto j3 = std::make_shared<hardware_interface::StateInterface>(
    JOINT_NAMES[2], HW_IF_POSITION, "double", std::to_string(INIT_POS[2]));

  init_broadcaster_and_set_parameters(
    "", {JOINT_NAMES[0], JOINT_NAMES[1], JOINT_NAMES[2]}, {HW_IF_POSITION});

  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(j1);
  state_ifs.emplace_back(j2);
  state_ifs.emplace_back(j3);
  state_broadcaster_->assign_interfaces({}, std::move(state_ifs));

  ASSERT_TRUE(configure_succeeds(state_broadcaster_));
  ASSERT_TRUE(activate_succeeds(state_broadcaster_));

  ASSERT_THAT(
    state_broadcaster_->joint_state_msg_.name,
    ElementsAreArray({JOINT_NAMES[0], JOINT_NAMES[1], JOINT_NAMES[2]}));

  /// Simulate a temporarily-unavailable first interface
  // Hold an exclusive lock on state_interfaces_[0]'s mutex from a helper thread.
  // While the lock is held, get_optional(0) on state_interfaces_[0] cannot acquire the
  // shared lock and returns nullopt.
  std::atomic<bool> lock_held{false};
  std::atomic<bool> release_lock{false};

  std::thread locker(
    [&]()
    {
      // Acquire exclusive lock on the first interface's handle mutex
      std::unique_lock<std::shared_mutex> lk(j1->get_mutex());
      lock_held.store(true, std::memory_order_release);
      // Hold it until the main thread finishes its update() call
      while (!release_lock.load(std::memory_order_acquire))
      {
        std::this_thread::yield();
      }
    });

  // Wait until the locker thread actually owns the mutex
  while (!lock_held.load(std::memory_order_acquire))
  {
    std::this_thread::yield();
  }

  // Call update(): joint1/position read will return nullopt (lock held by locker thread).
  ASSERT_NO_THROW(
    state_broadcaster_->update(rclcpp::Time(0), rclcpp::Duration::from_seconds(0.01)));

  release_lock.store(true, std::memory_order_release);
  locker.join();

  const auto & names = state_broadcaster_->joint_state_msg_.name;
  const auto & pos = state_broadcaster_->joint_state_msg_.position;
  ASSERT_EQ(pos.size(), 3u);

  // joint1 was not readable, its index must NOT contain joint2's value (2.2).
  // (It will hold the initial NaN or any prior value, not 2.2.)
  EXPECT_EQ(names[0], JOINT_NAMES[0]);
  EXPECT_NE(pos[0], INIT_POS[1])
    << "joint1's position slot was overwritten with joint2's value — map_index bug is present";

  EXPECT_EQ(names[1], JOINT_NAMES[1]);
  EXPECT_DOUBLE_EQ(pos[1], INIT_POS[1])
    << "joint2's position slot has wrong value — map_index was shifted by the nullopt";

  EXPECT_EQ(names[2], JOINT_NAMES[2]);
  EXPECT_DOUBLE_EQ(pos[2], INIT_POS[2])
    << "joint3's position slot has wrong value — map_index was shifted by the nullopt";
}
