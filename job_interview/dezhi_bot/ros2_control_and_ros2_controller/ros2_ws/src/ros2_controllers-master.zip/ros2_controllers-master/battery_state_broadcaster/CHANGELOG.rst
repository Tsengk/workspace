^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package battery_state_broadcaster
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


6.10.1 (2026-11-04)
-------------------

6.10.0 (2026-10-05)
-------------------

6.9.0 (2026-08-12)
------------------
* Add battery_state_broadcaster (`#2086 <https://github.com/ros-controls/ros2_controllers/issues/2086>`_)
* Contributors: Christoph Fröhlich, Jonas Otto, Yara Shahin

The entries below refer to the standalone `ipa320/ros_battery_monitoring <https://github.com/ipa320/ros_battery_monitoring>`_ package,
from which this broadcaster originates.

1.1.0 (2025-09-26)
------------------
* address deprecations in ros2_control for kilted
* Don't make a temporary copy of semantic component (`#9 <https://github.com/ipa320/ros_battery_monitoring/pull/9>`_)
* Contributors: Christoph Froehlich, Jonas Otto

1.0.2 (2025-06-01)
------------------
* Replace ament_target_dependencies with target_link_libraries (`#6 <https://github.com/ipa320/ros_battery_monitoring/issues/6>`_)
* Contributors: Alejandro Hernandez Cordero, Jonas Otto

1.0.1 (2025-02-06)
------------------
* fix realtime_tools include
* Contributors: Jonas Otto

1.0.0 (2024-08-14)
------------------
* initial release
* Contributors: Jonas Otto
