// Copyright 2017 Open Source Robotics Foundation, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif

#include "joint_trajectory_controller/trajectory.hpp"

#include <cmath>
#include <memory>

#include "angles/angles.h"
#include "hardware_interface/macros.hpp"
#include "rclcpp/duration.hpp"
#include "rclcpp/time.hpp"

namespace joint_trajectory_controller
{
Trajectory::Trajectory() : trajectory_start_time_(0), time_before_traj_msg_(0) {}

Trajectory::Trajectory(std::shared_ptr<trajectory_msgs::msg::JointTrajectory> joint_trajectory)
: trajectory_msg_(joint_trajectory),
  trajectory_start_time_(static_cast<rclcpp::Time>(joint_trajectory->header.stamp))
{
}

Trajectory::Trajectory(
  const rclcpp::Time & current_time,
  const trajectory_msgs::msg::JointTrajectoryPoint & current_point,
  std::shared_ptr<trajectory_msgs::msg::JointTrajectory> joint_trajectory)
: trajectory_msg_(joint_trajectory),
  trajectory_start_time_(static_cast<rclcpp::Time>(joint_trajectory->header.stamp))
{
  set_point_before_trajectory_msg(current_time, current_point);
  update(joint_trajectory);
}

void Trajectory::set_point_before_trajectory_msg(
  const rclcpp::Time & current_time,
  const trajectory_msgs::msg::JointTrajectoryPoint & current_point,
  const std::vector<bool> & joints_angle_wraparound)
{
  time_before_traj_msg_ = current_time;
  state_before_traj_msg_ = current_point;

  // If the current state doesn't contain velocities / accelerations, but the first trajectory
  // point does, initialize them to zero. Otherwise the segment going from the current state to the
  // first trajectory point will use another degree of spline interpolation than the rest of the
  // trajectory.
  if (current_point.velocities.empty() && !trajectory_msg_->points[0].velocities.empty())
  {
    state_before_traj_msg_.velocities.resize(trajectory_msg_->points[0].velocities.size(), 0.0);
  }
  if (current_point.accelerations.empty() && !trajectory_msg_->points[0].accelerations.empty())
  {
    state_before_traj_msg_.accelerations.resize(
      trajectory_msg_->points[0].accelerations.size(), 0.0);
  }

  // Compute offsets due to wrapping joints
  wraparound_joint(
    state_before_traj_msg_.positions, trajectory_msg_->points[0].positions,
    joints_angle_wraparound);
}

void wraparound_joint(
  std::vector<double> & current_position, const std::vector<double> next_position,
  const std::vector<bool> & joints_angle_wraparound)
{
  double dist;
  // joints_angle_wraparound is even empty, or has the same size as the number of joints
  for (size_t i = 0; i < joints_angle_wraparound.size(); i++)
  {
    if (joints_angle_wraparound[i])
    {
      dist = angles::shortest_angular_distance(current_position[i], next_position[i]);

      // Deal with singularity at M_PI shortest distance
      if (std::abs(std::abs(dist) - M_PI) < 1e-9)
      {
        dist = next_position[i] > current_position[i] ? std::abs(dist) : -std::abs(dist);
      }

      current_position[i] = next_position[i] - dist;
    }
  }
}

bool fill_cubic_spline_velocities(
  trajectory_msgs::msg::JointTrajectory & traj, const std::vector<double> & start_velocity)
{
  const size_t n = traj.points.size();
  if (n < 2)
  {
    return false;
  }
  const size_t n_joints = traj.points[0].positions.size();
  if (n_joints == 0)
  {
    return false;
  }
  if (!start_velocity.empty() && start_velocity.size() != n_joints)
  {
    return false;
  }
  for (const auto & point : traj.points)
  {
    if (point.positions.size() != n_joints)
    {
      return false;
    }
  }

  // Waypoint times; bail on non-increasing timing (zero/negative duration -> divide by zero).
  std::vector<double> times(n);
  for (size_t i = 0; i < n; ++i)
  {
    times[i] = rclcpp::Duration(traj.points[i].time_from_start).seconds();
    if (i > 0 && times[i] <= times[i - 1])
    {
      return false;
    }
  }

  // Per-joint tridiagonal solve (Thomas algorithm); non-RT, so per-call scratch is fine.
  std::vector<double> lower_diagonal(n), diagonal(n), upper_diagonal(n), rhs(n);
  std::vector<double> forward_sweep(n), velocities(n);

  for (auto & point : traj.points)
  {
    point.velocities.assign(n_joints, 0.0);
  }

  // Coefficients of the cubic-spline continuity equation which come from the 2nd derivative
  constexpr double diagonal_coefficient = 2.0;
  constexpr double rhs_coefficient = 3.0;

  for (size_t joint = 0; joint < n_joints; ++joint)
  {
    // Clamped start when a start velocity is given, otherwise at rest.
    diagonal[0] = 1.0;
    upper_diagonal[0] = 0.0;
    rhs[0] = start_velocity.empty() ? 0.0 : start_velocity[joint];
    lower_diagonal[n - 1] = 0.0;
    diagonal[n - 1] = 1.0;
    rhs[n - 1] = 0.0;

    // Interior knots: each row enforces continuous acceleration (global cubic-spline condition).
    for (size_t i = 1; i < n - 1; ++i)
    {
      const double duration_prev = times[i] - times[i - 1];
      const double duration_next = times[i + 1] - times[i];
      const double pos_prev = traj.points[i - 1].positions[joint];
      const double pos_curr = traj.points[i].positions[joint];
      const double pos_next = traj.points[i + 1].positions[joint];

      lower_diagonal[i] = 1.0 / duration_prev;
      diagonal[i] = diagonal_coefficient * (1.0 / duration_prev + 1.0 / duration_next);
      upper_diagonal[i] = 1.0 / duration_next;
      rhs[i] = rhs_coefficient * ((pos_next - pos_curr) / (duration_next * duration_next) +
                                  (pos_curr - pos_prev) / (duration_prev * duration_prev));
    }

    // Thomas algorithm: forward sweep ...
    forward_sweep[0] = upper_diagonal[0] / diagonal[0];
    velocities[0] = rhs[0] / diagonal[0];
    for (size_t i = 1; i < n; ++i)
    {
      const double pivot = diagonal[i] - lower_diagonal[i] * forward_sweep[i - 1];
      forward_sweep[i] = (i + 1 < n) ? upper_diagonal[i] / pivot : 0.0;
      velocities[i] = (rhs[i] - lower_diagonal[i] * velocities[i - 1]) / pivot;
    }
    // ... then back substitution.
    for (size_t i = n - 1; i-- > 0;)
    {
      velocities[i] -= forward_sweep[i] * velocities[i + 1];
    }

    for (size_t i = 0; i < n; ++i)
    {
      traj.points[i].velocities[joint] = velocities[i];
    }
  }
  return true;
}

void Trajectory::update(std::shared_ptr<trajectory_msgs::msg::JointTrajectory> joint_trajectory)
{
  trajectory_msg_ = joint_trajectory;
  trajectory_start_time_ = static_cast<rclcpp::Time>(joint_trajectory->header.stamp);
  sampled_already_ = false;
  last_sample_idx_ = 0;
}

bool Trajectory::sample(
  const rclcpp::Time & sample_time,
  const interpolation_methods::InterpolationMethod interpolation_method,
  trajectory_msgs::msg::JointTrajectoryPoint & output_state,
  TrajectoryPointConstIter & start_segment_itr, TrajectoryPointConstIter & end_segment_itr,
  const bool search_monotonically_increasing)
{
  THROW_ON_NULLPTR(trajectory_msg_)

  if (trajectory_msg_->points.empty())
  {
    start_segment_itr = end();
    end_segment_itr = end();
    return false;
  }

  // first sampling of this trajectory
  if (!sampled_already_)
  {
    if (trajectory_start_time_.seconds() == 0.0)
    {
      trajectory_start_time_ = sample_time;
    }

    sampled_already_ = true;
  }

  // sampling before the current point
  if (sample_time < time_before_traj_msg_)
  {
    return false;
  }

  output_state = trajectory_msgs::msg::JointTrajectoryPoint();
  auto & first_point_in_msg = trajectory_msg_->points[0];
  const rclcpp::Time first_point_timestamp =
    trajectory_start_time_ + first_point_in_msg.time_from_start;

  // current time hasn't reached traj time of the first point in the msg yet
  if (sample_time < first_point_timestamp)
  {
    // If interpolation is disabled, just forward the next waypoint
    if (interpolation_method == interpolation_methods::InterpolationMethod::NONE)
    {
      output_state = state_before_traj_msg_;
    }
    else
    {
      // it changes points only if position and velocity do not exist, but their derivatives
      deduce_from_derivatives(
        state_before_traj_msg_, first_point_in_msg, state_before_traj_msg_.positions.size(),
        (first_point_timestamp - time_before_traj_msg_).seconds());

      interpolate_between_points(
        time_before_traj_msg_, state_before_traj_msg_, first_point_timestamp, first_point_in_msg,
        sample_time, output_state);
    }
    start_segment_itr = begin();  // no segments before the first
    end_segment_itr = begin();
    return true;
  }

  // time_from_start + trajectory time is the expected arrival time of trajectory
  const auto last_idx = trajectory_msg_->points.size() - 1;
  for (size_t i = last_sample_idx_; i < last_idx; ++i)
  {
    auto & point = trajectory_msg_->points[i];
    auto & next_point = trajectory_msg_->points[i + 1];

    const rclcpp::Time t0 = trajectory_start_time_ + point.time_from_start;
    const rclcpp::Time t1 = trajectory_start_time_ + next_point.time_from_start;

    if (sample_time >= t0 && sample_time < t1)
    {
      // If interpolation is disabled, just forward the next waypoint
      if (interpolation_method == interpolation_methods::InterpolationMethod::NONE)
      {
        output_state = next_point;
      }
      // Do interpolation
      else
      {
        // it changes points only if position and velocity do not exist, but their derivatives
        deduce_from_derivatives(
          point, next_point, state_before_traj_msg_.positions.size(), (t1 - t0).seconds());

        interpolate_between_points(t0, point, t1, next_point, sample_time, output_state);
      }
      start_segment_itr = begin() + static_cast<TrajectoryPointConstIter::difference_type>(i);
      end_segment_itr = begin() + static_cast<TrajectoryPointConstIter::difference_type>(i + 1);
      output_state.time_from_start = next_point.time_from_start;
      if (search_monotonically_increasing)
      {
        last_sample_idx_ = i;
      }
      return true;
    }
  }

  // whole animation has played out
  start_segment_itr = --end();
  end_segment_itr = end();
  if (search_monotonically_increasing)
  {
    last_sample_idx_ = last_idx;
  }

  // If the last segment was never entered (e.g. sample_time jumped past a very
  // short last segment because the controller rate is slower than the segment
  // duration), the last trajectory point's positions may have never been
  // deduced from velocities. Recover by deducing them from the previous point
  // if that point has positions; otherwise return false so the caller does not
  // dereference an empty positions vector downstream. See #2282.
  if (trajectory_msg_->points[last_idx].positions.empty() && last_idx > 0)
  {
    auto & prev_point = trajectory_msg_->points[last_idx - 1];
    auto & last_point = trajectory_msg_->points[last_idx];
    if (!prev_point.positions.empty())
    {
      const rclcpp::Time t_prev = trajectory_start_time_ + prev_point.time_from_start;
      const rclcpp::Time t_last = trajectory_start_time_ + last_point.time_from_start;
      deduce_from_derivatives(
        prev_point, last_point, state_before_traj_msg_.positions.size(),
        (t_last - t_prev).seconds());
    }
  }

  output_state = (*start_segment_itr);
  if (output_state.positions.empty())
  {
    start_segment_itr = end();
    end_segment_itr = end();
    return false;
  }
  // the trajectories in msg may have empty velocities/accel, so resize them
  if (output_state.velocities.empty())
  {
    output_state.velocities.resize(output_state.positions.size(), 0.0);
  }
  if (output_state.accelerations.empty())
  {
    output_state.accelerations.resize(output_state.positions.size(), 0.0);
  }
  if (output_state.effort.empty())
  {
    output_state.effort.resize(output_state.positions.size(), 0.0);
  }
  return true;
}

void Trajectory::interpolate_between_points(
  const rclcpp::Time & time_a, const trajectory_msgs::msg::JointTrajectoryPoint & state_a,
  const rclcpp::Time & time_b, const trajectory_msgs::msg::JointTrajectoryPoint & state_b,
  const rclcpp::Time & sample_time, trajectory_msgs::msg::JointTrajectoryPoint & output)
{
  rclcpp::Duration duration_so_far = sample_time - time_a;
  rclcpp::Duration duration_btwn_points = time_b - time_a;

  const size_t dim = state_a.positions.size();
  output.positions.resize(dim, 0.0);
  output.velocities.resize(dim, 0.0);
  output.accelerations.resize(dim, 0.0);
  output.effort.resize(dim, 0.0);

  auto generate_powers = [](int n, double x, double * powers)
  {
    powers[0] = 1.0;
    for (int i = 1; i <= n; ++i)
    {
      powers[i] = powers[i - 1] * x;
    }
  };

  bool has_velocity = !state_a.velocities.empty() && !state_b.velocities.empty();
  bool has_accel = !state_a.accelerations.empty() && !state_b.accelerations.empty();
  bool has_effort = !state_a.effort.empty() && !state_b.effort.empty();
  if (duration_so_far.seconds() < 0.0)
  {
    duration_so_far = rclcpp::Duration::from_seconds(0.0);
    has_velocity = has_accel = false;
  }
  if (duration_so_far.seconds() > duration_btwn_points.seconds())
  {
    duration_so_far = duration_btwn_points;
    has_velocity = has_accel = false;
  }

  double t[6];
  generate_powers(5, duration_so_far.seconds(), t);

  if (has_effort)
  {
    // do linear interpolation
    for (size_t i = 0; i < dim; ++i)
    {
      double start_effort = state_a.effort[i];
      double end_effort = state_b.effort[i];

      double coefficients[2] = {0.0, 0.0};
      coefficients[0] = start_effort;
      if (duration_btwn_points.seconds() != 0.0)
      {
        coefficients[1] = (end_effort - start_effort) / duration_btwn_points.seconds();
      }

      output.effort[i] = t[0] * coefficients[0] + t[1] * coefficients[1];
    }
  }

  if (!has_velocity && !has_accel)
  {
    // do linear interpolation
    for (size_t i = 0; i < dim; ++i)
    {
      double start_pos = state_a.positions[i];
      double end_pos = state_b.positions[i];

      double coefficients[2] = {0.0, 0.0};
      coefficients[0] = start_pos;
      if (duration_btwn_points.seconds() != 0.0)
      {
        coefficients[1] = (end_pos - start_pos) / duration_btwn_points.seconds();
      }

      output.positions[i] = t[0] * coefficients[0] + t[1] * coefficients[1];
      output.velocities[i] = t[0] * coefficients[1];
    }
  }
  else if (has_velocity && !has_accel)
  {
    // do cubic interpolation
    double T[4];
    generate_powers(3, duration_btwn_points.seconds(), T);

    for (size_t i = 0; i < dim; ++i)
    {
      double start_pos = state_a.positions[i];
      double start_vel = state_a.velocities[i];
      double end_pos = state_b.positions[i];
      double end_vel = state_b.velocities[i];

      double coefficients[4] = {0.0, 0.0, 0.0, 0.0};
      coefficients[0] = start_pos;
      coefficients[1] = start_vel;
      if (duration_btwn_points.seconds() != 0.0)
      {
        coefficients[2] =
          (-3.0 * start_pos + 3.0 * end_pos - 2.0 * start_vel * T[1] - end_vel * T[1]) / T[2];
        coefficients[3] =
          (2.0 * start_pos - 2.0 * end_pos + start_vel * T[1] + end_vel * T[1]) / T[3];
      }

      output.positions[i] = t[0] * coefficients[0] + t[1] * coefficients[1] +
                            t[2] * coefficients[2] + t[3] * coefficients[3];
      output.velocities[i] =
        t[0] * coefficients[1] + t[1] * 2.0 * coefficients[2] + t[2] * 3.0 * coefficients[3];
      output.accelerations[i] = t[0] * 2.0 * coefficients[2] + t[1] * 6.0 * coefficients[3];
    }
  }
  else if (has_velocity && has_accel)
  {
    // do quintic interpolation
    double T[6];
    generate_powers(5, duration_btwn_points.seconds(), T);

    for (size_t i = 0; i < dim; ++i)
    {
      double start_pos = state_a.positions[i];
      double start_vel = state_a.velocities[i];
      double start_acc = state_a.accelerations[i];
      double end_pos = state_b.positions[i];
      double end_vel = state_b.velocities[i];
      double end_acc = state_b.accelerations[i];

      double coefficients[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
      coefficients[0] = start_pos;
      coefficients[1] = start_vel;
      coefficients[2] = 0.5 * start_acc;
      if (duration_btwn_points.seconds() != 0.0)
      {
        coefficients[3] = (-20.0 * start_pos + 20.0 * end_pos - 3.0 * start_acc * T[2] +
                           end_acc * T[2] - 12.0 * start_vel * T[1] - 8.0 * end_vel * T[1]) /
                          (2.0 * T[3]);
        coefficients[4] = (30.0 * start_pos - 30.0 * end_pos + 3.0 * start_acc * T[2] -
                           2.0 * end_acc * T[2] + 16.0 * start_vel * T[1] + 14.0 * end_vel * T[1]) /
                          (2.0 * T[4]);
        coefficients[5] = (-12.0 * start_pos + 12.0 * end_pos - start_acc * T[2] + end_acc * T[2] -
                           6.0 * start_vel * T[1] - 6.0 * end_vel * T[1]) /
                          (2.0 * T[5]);
      }

      output.positions[i] = t[0] * coefficients[0] + t[1] * coefficients[1] +
                            t[2] * coefficients[2] + t[3] * coefficients[3] +
                            t[4] * coefficients[4] + t[5] * coefficients[5];
      output.velocities[i] = t[0] * coefficients[1] + t[1] * 2.0 * coefficients[2] +
                             t[2] * 3.0 * coefficients[3] + t[3] * 4.0 * coefficients[4] +
                             t[4] * 5.0 * coefficients[5];
      output.accelerations[i] = t[0] * 2.0 * coefficients[2] + t[1] * 6.0 * coefficients[3] +
                                t[2] * 12.0 * coefficients[4] + t[3] * 20.0 * coefficients[5];
    }
  }
}

void Trajectory::deduce_from_derivatives(
  trajectory_msgs::msg::JointTrajectoryPoint & first_state,
  trajectory_msgs::msg::JointTrajectoryPoint & second_state, const size_t dim, const double delta_t)
{
  if (first_state.effort.empty())
  {
    first_state.effort.assign(dim, 0.0);
  }
  if (second_state.effort.empty())
  {
    second_state.effort.assign(dim, 0.0);
  }
  if (second_state.positions.empty())
  {
    second_state.positions.resize(dim);
    if (first_state.velocities.empty())
    {
      first_state.velocities.resize(dim, 0.0);
    }
    if (second_state.velocities.empty())
    {
      second_state.velocities.resize(dim);
      if (first_state.accelerations.empty())
      {
        first_state.accelerations.resize(dim, 0.0);
      }
      for (size_t i = 0; i < dim; ++i)
      {
        second_state.velocities[i] =
          first_state.velocities[i] +
          (first_state.accelerations[i] + second_state.accelerations[i]) * 0.5 * delta_t;
      }
    }
    for (size_t i = 0; i < dim; ++i)
    {
      // second state velocity should be reached on the end of the segment, so use middle
      second_state.positions[i] =
        first_state.positions[i] +
        (first_state.velocities[i] + second_state.velocities[i]) * 0.5 * delta_t;
    }
  }
}

TrajectoryPointConstIter Trajectory::begin() const
{
  THROW_ON_NULLPTR(trajectory_msg_)

  return trajectory_msg_->points.begin();
}

TrajectoryPointConstIter Trajectory::end() const
{
  THROW_ON_NULLPTR(trajectory_msg_)

  return trajectory_msg_->points.end();
}

rclcpp::Time Trajectory::time_from_start() const { return trajectory_start_time_; }

bool Trajectory::has_trajectory_msg() const { return trajectory_msg_.get() != nullptr; }

bool Trajectory::has_nontrivial_msg() const
{
  return has_trajectory_msg() && trajectory_msg_->points.size() > 1;
}

}  // namespace joint_trajectory_controller
