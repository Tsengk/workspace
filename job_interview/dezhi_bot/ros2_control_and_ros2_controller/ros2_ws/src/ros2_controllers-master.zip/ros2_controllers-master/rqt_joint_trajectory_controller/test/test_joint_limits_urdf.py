# Copyright 2026 ros2_control Development Team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Unit tests for joint_limits_urdf.py.

Most tests are ROS-free: they call parse_joint_limits() directly with URDF
strings and assert on the returned dict. No node, no topic, no
robot_description publisher is needed.

The last group tests the callback and get_joint_limits() handling of the
robot_description using a minimal fake node stub, still without any live ROS node,
context, or executor.

Run with:
    pytest rqt_joint_trajectory_controller/test/test_joint_limits_urdf.py -v
"""

import math
import time
from unittest.mock import Mock

import pytest

from rqt_joint_trajectory_controller import joint_limits_urdf
from rqt_joint_trajectory_controller.joint_limits_urdf import (
    callback as robot_description_callback,
    get_joint_limits,
    parse_joint_limits,
)

# ---------------------------------------------------------------------------
# Small URDF builder helpers
#
# Real robot URDFs are hundreds of lines long, but for testing we only need
# the minimum valid XML that exercises one specific behaviour. These helpers
# let each test build exactly what it needs in two or three lines.
# ---------------------------------------------------------------------------


def _robot(*joint_snippets):
    """Wrap joint snippets inside a minimal valid <robot> element."""
    body = "\n".join(joint_snippets)
    return f'<?xml version="1.0"?><robot name="r"><link name="base"/>{body}</robot>'


def _revolute(name, lower, upper, velocity):
    """A revolute joint with explicit position and velocity limits."""
    return (
        f'<link name="{name}_link"/>'
        f'<joint name="{name}" type="revolute">'
        f'<parent link="base"/><child link="{name}_link"/>'
        f'<limit lower="{lower}" upper="{upper}" velocity="{velocity}" effort="10"/>'
        f"</joint>"
    )


def _continuous(name, velocity):
    """A continuous joint — no lower/upper attributes."""
    return (
        f'<link name="{name}_link"/>'
        f'<joint name="{name}" type="continuous">'
        f'<parent link="base"/><child link="{name}_link"/>'
        f'<limit velocity="{velocity}" effort="10"/>'
        f"</joint>"
    )


def _fixed(name):
    """A fixed joint — no limits element at all."""
    return (
        f'<link name="{name}_link"/>'
        f'<joint name="{name}" type="fixed">'
        f'<parent link="base"/><child link="{name}_link"/>'
        f"</joint>"
    )


class _TestLogger:
    def __init__(self):
        self.info_messages = []
        self.warning_messages = []

    def info(self, msg):
        self.info_messages.append(msg)

    def warning(self, msg, **kwargs):
        self.warning_messages.append(msg)


class _TestNode:
    def __init__(self, logger):
        self._logger = logger

    def get_logger(self):
        return self._logger


# ---------------------------------------------------------------------------
# Group 1: Revolute joint — the most common joint type in a robot arm.
# The function must return exactly the values written in the URDF.
# ---------------------------------------------------------------------------


def test_revolute_joint_appears_in_result():
    result = parse_joint_limits(_robot(_revolute("j1", -1.5, 1.5, 2.0)), ["j1"])
    assert "j1" in result


def test_revolute_joint_min_position():
    result = parse_joint_limits(_robot(_revolute("j1", -1.5, 1.5, 2.0)), ["j1"])
    assert result["j1"]["min_position"] == pytest.approx(-1.5)


def test_revolute_joint_max_position():
    result = parse_joint_limits(_robot(_revolute("j1", -1.5, 1.5, 2.0)), ["j1"])
    assert result["j1"]["max_position"] == pytest.approx(1.5)


def test_revolute_joint_max_velocity():
    result = parse_joint_limits(_robot(_revolute("j1", -1.5, 1.5, 2.0)), ["j1"])
    assert result["j1"]["max_velocity"] == pytest.approx(2.0)


def test_revolute_joint_has_position_limits_true():
    # Revolute joints are bounded — the GUI slider should enforce limits
    result = parse_joint_limits(_robot(_revolute("j1", -1.5, 1.5, 2.0)), ["j1"])
    assert result["j1"]["has_position_limits"] is True


# ---------------------------------------------------------------------------
# Group 2: Continuous joint — like a wheel, no position bounds.
# When lower/upper are absent, urdf_parser_py defaults them to 0.
# Our code detects min >= max and defaults to -pi / +pi so the slider
# has a usable range.
# ---------------------------------------------------------------------------


def test_continuous_joint_appears_in_result():
    result = parse_joint_limits(_robot(_continuous("wheel", 5.0)), ["wheel"])
    assert "wheel" in result


def test_continuous_joint_min_defaults_to_minus_pi():
    result = parse_joint_limits(_robot(_continuous("wheel", 5.0)), ["wheel"])
    assert result["wheel"]["min_position"] == pytest.approx(-math.pi)


def test_continuous_joint_max_defaults_to_plus_pi():
    result = parse_joint_limits(_robot(_continuous("wheel", 5.0)), ["wheel"])
    assert result["wheel"]["max_position"] == pytest.approx(math.pi)


def test_continuous_joint_has_position_limits_true():
    # Continuous joints are unbounded — it still gets position limits to activate the slider
    result = parse_joint_limits(_robot(_continuous("wheel", 5.0)), ["wheel"])
    assert result["wheel"]["has_position_limits"] is True


def test_continuous_joint_velocity_is_preserved():
    result = parse_joint_limits(_robot(_continuous("wheel", 5.0)), ["wheel"])
    assert result["wheel"]["max_velocity"] == pytest.approx(5.0)


# ---------------------------------------------------------------------------
# Group 3: Fixed joints — they have no DOF and must be completely ignored.
# ---------------------------------------------------------------------------


def test_urdf_with_only_fixed_joints_returns_empty_dict():
    result = parse_joint_limits(_robot(_fixed("j1"), _fixed("j2")), [])
    assert result == {}


# ---------------------------------------------------------------------------
# Group 4: Multiple joints — all non-fixed joints must appear in the result.
# This mirrors a real robot arm with mixed joint types.
# ---------------------------------------------------------------------------


def test_multiple_joints_all_present():
    urdf = _robot(
        _revolute("shoulder", -1.0, 1.0, 1.0),
        _revolute("elbow", -2.0, 2.0, 1.5),
        _continuous("wrist_roll", 3.0),
        _fixed("tool_mount"),
    )
    result = parse_joint_limits(urdf, ["shoulder", "elbow", "wrist_roll"])
    assert set(result.keys()) == {"shoulder", "elbow", "wrist_roll"}


def test_multiple_joints_fixed_excluded():
    urdf = _robot(
        _revolute("shoulder", -1.0, 1.0, 1.0),
        _fixed("tool_mount"),
    )
    result = parse_joint_limits(urdf, [])
    assert "tool_mount" not in result


def test_multiple_joints_individual_limits_correct():
    urdf = _robot(
        _revolute("shoulder", -1.0, 1.0, 1.0),
        _revolute("elbow", -2.0, 2.0, 1.5),
    )
    result = parse_joint_limits(urdf, ["shoulder", "elbow"])
    assert result["elbow"]["min_position"] == pytest.approx(-2.0)
    assert result["shoulder"]["max_velocity"] == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# Group 5: Safety controller soft limits.
# When use_smallest_joint_limits=True, soft limits should narrow the range.
# When False, only the hard limits from <limit> should be used.
# ---------------------------------------------------------------------------


def test_soft_limits_narrow_range_when_flag_true():
    urdf = _robot(
        '<link name="j1_link"/>'
        '<joint name="j1" type="revolute">'
        '<parent link="base"/><child link="j1_link"/>'
        '<limit lower="-2.0" upper="2.0" velocity="1.0" effort="10"/>'
        '<safety_controller soft_lower_limit="-1.0" soft_upper_limit="1.0"'
        ' k_position="100" k_velocity="10"/>'
        "</joint>"
    )
    result = parse_joint_limits(urdf, ["j1"], use_smallest_joint_limits=True)
    assert result["j1"]["min_position"] == pytest.approx(-1.0)
    assert result["j1"]["max_position"] == pytest.approx(1.0)


def test_soft_limits_ignored_when_flag_false():
    urdf = _robot(
        '<link name="j1_link"/>'
        '<joint name="j1" type="revolute">'
        '<parent link="base"/><child link="j1_link"/>'
        '<limit lower="-2.0" upper="2.0" velocity="1.0" effort="10"/>'
        '<safety_controller soft_lower_limit="-1.0" soft_upper_limit="1.0"'
        ' k_position="100" k_velocity="10"/>'
        "</joint>"
    )
    result = parse_joint_limits(urdf, ["j1"], use_smallest_joint_limits=False)
    assert result["j1"]["min_position"] == pytest.approx(-2.0)
    assert result["j1"]["max_position"] == pytest.approx(2.0)


# ---------------------------------------------------------------------------
# Group 6: Mimic joints — follow another joint mechanically.
# They cannot be independently commanded, so the GUI must not show a
# slider for them. They must be absent from free_joints.
# ---------------------------------------------------------------------------


def test_mimic_joint_excluded_from_result():
    urdf = _robot(
        _revolute("driver", -1.0, 1.0, 1.0),
        '<link name="follower_link"/>'
        '<joint name="follower" type="revolute">'
        '<parent link="base"/><child link="follower_link"/>'
        '<limit lower="-1.0" upper="1.0" velocity="1.0" effort="5"/>'
        '<mimic joint="driver" multiplier="1.0" offset="0.0"/>'
        "</joint>",
    )
    result = parse_joint_limits(urdf, ["driver"])
    assert "follower" not in result


def test_driver_joint_present_when_follower_is_mimic():
    urdf = _robot(
        _revolute("driver", -1.0, 1.0, 1.0),
        '<link name="follower_link"/>'
        '<joint name="follower" type="revolute">'
        '<parent link="base"/><child link="follower_link"/>'
        '<limit lower="-1.0" upper="1.0" velocity="1.0" effort="5"/>'
        '<mimic joint="driver" multiplier="1.0" offset="0.0"/>'
        "</joint>",
    )
    result = parse_joint_limits(urdf, ["driver"])
    assert "driver" in result


# ---------------------------------------------------------------------------
# Group 7: Error cases — validation by urdf_parser_py and our application
# logic. Some errors are caught by the library during parsing, others
# by our code after parsing succeeds.
# ---------------------------------------------------------------------------


def test_missing_limit_tag_for_required_joint_raises():
    """Joint in joints_names with no <limit> element at all must raise.

    urdf_parser_py sets joint.limit to None when no <limit> element is
    present. Our code checks for this and raises an exception for joints
    that the active controller manages.
    """
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        "</joint>"
    )
    with pytest.raises(Exception, match="Missing limits tag"):
        parse_joint_limits(urdf, ["j"])


def test_missing_limit_tag_allow_incomplete_false_still_raises():
    """Explicit strict mode keeps raising on missing <limit> tags."""
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        "</joint>"
    )
    with pytest.raises(Exception, match="Missing limits tag"):
        parse_joint_limits(urdf, ["j"], allow_incomplete_joints=False)


def test_missing_limit_tag_for_unrequired_joint_skipped_silently():
    """Joint NOT in joints_names with no <limit> is silently ignored.

    The URDF may describe joints that this controller does not manage.
    Those joints do not need limits.
    """
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        "</joint>"
    )
    result = parse_joint_limits(urdf, [])
    assert "j" not in result


def test_revolute_joint_missing_lower_upper_raises():
    """Revolute joint with no lower/upper attributes raises.

    urdf_parser_py defaults missing lower/upper to 0. Our code detects
    the invalid range (min >= max) and raises for non-continuous joints.
    """
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        '<limit velocity="1.0" effort="5"/>'
        "</joint>"
    )
    with pytest.raises(Exception, match="Missing lower/upper position limits"):
        parse_joint_limits(urdf, ["j"])


def test_missing_lower_upper_allow_incomplete_false_still_raises():
    """Explicit strict mode keeps raising on missing lower/upper limits."""
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        '<limit velocity="1.0" effort="5"/>'
        "</joint>"
    )
    with pytest.raises(Exception, match="Missing lower/upper position limits"):
        parse_joint_limits(urdf, ["j"], allow_incomplete_joints=False)


def test_missing_limit_tag_allow_incomplete_true_returns_disabled_joint():
    """Tolerant mode keeps required joints but marks them non-position-limited."""
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        "</joint>"
    )
    result = parse_joint_limits(urdf, ["j"], allow_incomplete_joints=True)
    assert result["j"]["has_position_limits"] is False
    assert result["j"]["min_position"] == pytest.approx(-2.0 * math.pi)
    assert result["j"]["max_position"] == pytest.approx(2.0 * math.pi)
    assert result["j"]["max_velocity"] == pytest.approx(1.0)


def test_missing_limit_tag_allow_incomplete_true_logs_warning():
    """Tolerant mode emits a warning through the provided logger."""
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        "</joint>"
    )
    logger = _TestLogger()
    parse_joint_limits(urdf, ["j"], allow_incomplete_joints=True, logger=logger)
    assert len(logger.warning_messages) == 1
    assert "has no <limit> tag" in logger.warning_messages[0]


def test_missing_lower_upper_allow_incomplete_true_returns_disabled_joint():
    """Tolerant mode handles missing lower/upper by creating a disabled slider joint."""
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        '<limit velocity="1.0" effort="5"/>'
        "</joint>"
    )
    result = parse_joint_limits(urdf, ["j"], allow_incomplete_joints=True)
    assert result["j"]["has_position_limits"] is False
    assert result["j"]["min_position"] == pytest.approx(-2.0 * math.pi)
    assert result["j"]["max_position"] == pytest.approx(2.0 * math.pi)
    assert result["j"]["max_velocity"] == pytest.approx(1.0)


def test_missing_lower_upper_allow_incomplete_true_logs_warning():
    """Tolerant mode logs when position bounds are incomplete."""
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        '<limit velocity="1.0" effort="5"/>'
        "</joint>"
    )
    logger = _TestLogger()
    parse_joint_limits(urdf, ["j"], allow_incomplete_joints=True, logger=logger)
    assert len(logger.warning_messages) == 1
    assert "missing/empty lower/upper position limits" in logger.warning_messages[0]


def test_missing_velocity_raises():
    """Joint with no velocity attribute raises a parse error.

    urdf_parser_py performs strict XML validation during parsing and
    rejects a <limit> element missing the required velocity attribute.
    The error comes from the library itself, before our code inspects
    the joint.
    """
    urdf = _robot(
        '<link name="j_link"/>'
        '<joint name="j" type="revolute">'
        '<parent link="base"/><child link="j_link"/>'
        '<limit lower="-1.0" upper="1.0" effort="5"/>'
        "</joint>"
    )
    with pytest.raises(Exception, match="Required attribute not set in XML: velocity"):
        parse_joint_limits(urdf, ["j"])


# ---------------------------------------------------------------------------
# Group 8: robot_description handling.
#
# get_joint_limits() is called from the GUI thread with a node that may be
# context.node, which rqt_gui_py already spins on its own thread. It must
# neither spin that node nor wait for the robot_description; the
# subscription callback stores the message for later calls.
# A minimal fake node/message is used, so no real rclpy node, context, or
# executor is involved.
# ---------------------------------------------------------------------------


class _FakeMsg:
    def __init__(self, data):
        self.data = data


class _FakeSubscribingNode(_TestNode):
    """Minimal node stub that records create_subscription() calls and returns a handle."""

    def __init__(self, logger):
        super().__init__(logger)
        self.subscriptions = []

    def create_subscription(self, msg_type, topic, cb, qos_profile):
        handle = (msg_type, topic, cb, qos_profile)
        self.subscriptions.append(handle)
        return handle


@pytest.fixture
def _clean_description_state():
    """Reset the module-level description cache and event around each test."""
    joint_limits_urdf.description = ""
    yield
    joint_limits_urdf.description = ""


@pytest.fixture
def _node(_clean_description_state):
    return _TestNode(_TestLogger())


@pytest.fixture
def _no_spin_once(monkeypatch):
    """
    Fail loudly if get_joint_limits() ever calls rclpy.spin_once().

    It must not: node may be context.node, which rqt_gui_py already spins
    on another thread, so spinning it again here would race.
    """
    spin_once = Mock(side_effect=AssertionError("spin_once must not be called"))
    monkeypatch.setattr(joint_limits_urdf.rclpy, "spin_once", spin_once)
    return spin_once


def _minimal_urdf():
    return _robot(_revolute("j1", -1.0, 1.0, 1.0))


def test_callback_sets_description(_clean_description_state):
    assert joint_limits_urdf.description == ""

    robot_description_callback(_FakeMsg(_minimal_urdf()))

    assert joint_limits_urdf.description == _minimal_urdf()


def test_subscribe_to_robot_description_returns_owned_subscription(_clean_description_state):
    """subscribe_to_robot_description() must return the handle so the caller can destroy it later.

    The plugin needs this to destroy its own subscription in shutdown_plugin() without
    relying on context.node's destruction, since it doesn't own that node.
    """
    node = _FakeSubscribingNode(_TestLogger())
    sub = joint_limits_urdf.subscribe_to_robot_description(node)

    assert node.subscriptions == [sub]
    _msg_type, topic, cb, _qos = sub
    assert topic == "robot_description"
    assert cb is robot_description_callback


def test_get_joint_limits_does_not_call_spin_once(_node, _no_spin_once):
    joint_limits_urdf.description = _minimal_urdf()

    result = get_joint_limits(_node, ["j1"])

    assert "j1" in result
    _no_spin_once.assert_not_called()


def test_get_joint_limits_returns_empty_dict_immediately_without_description(_node):
    """
    get_joint_limits() runs on the GUI thread, so it must not wait for the
    robot_description. The plugin retries on its next controller list update.
    """
    start = time.monotonic()
    result = get_joint_limits(_node, ["j1"])

    assert result == {}
    assert time.monotonic() - start < 1.0
    assert _node.get_logger().warning_messages


def test_get_joint_limits_uses_description_received_later(_node):
    assert get_joint_limits(_node, ["j1"]) == {}

    robot_description_callback(_FakeMsg(_minimal_urdf()))

    assert "j1" in get_joint_limits(_node, ["j1"])
