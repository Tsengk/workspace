^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package state_interfaces_broadcaster
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

6.10.1 (2026-11-04)
-------------------

6.10.0 (2026-10-05)
-------------------
* test: cleanup controller fixture member variables (`#2562 <https://github.com/ros-controls/ros2_controllers/issues/2562>`_)
* Contributors: Akshat Guduru

6.9.0 (2026-08-12)
------------------
* Use new Command/State Interfaces API for tests (`#2476 <https://github.com/ros-controls/ros2_controllers/issues/2476>`_)
* Contributors: Sai Kishor Kothakota

6.8.0 (2026-07-01)
------------------
* Test fix - call appropriate lifecycle transitions in controller tests: pid, motion_primitives, state_interfaces_broadcaster, ackermann_steering (`#2399 <https://github.com/ros-controls/ros2_controllers/issues/2399>`_)
* Contributors: Junius Santoso

6.7.0 (2026-05-12)
------------------
* Bump C++ version to C++20 (`#2331 <https://github.com/ros-controls/ros2_controllers/issues/2331>`_)
* Contributors: Christoph Fröhlich

6.6.0 (2026-04-22)
------------------

6.5.0 (2026-04-02)
------------------

6.4.0 (2026-03-12)
------------------

6.3.0 (2026-02-03)
------------------

6.2.0 (2025-12-31)
------------------
* Add state_interfaces_broadcaster (`#2006 <https://github.com/ros-controls/ros2_controllers/issues/2006>`_)
* Contributors: Sai Kishor Kothakota
