// Copyright 2017 Open Source Robotics Foundation, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef JOINT_TRAJECTORY_CONTROLLER__TRAJECTORY_HPP_
#define JOINT_TRAJECTORY_CONTROLLER__TRAJECTORY_HPP_

#include <memory>
#include <vector>

#include "joint_trajectory_controller/interpolation_methods.hpp"
#include "rclcpp/time.hpp"
#include "trajectory_msgs/msg/joint_trajectory.hpp"
#include "trajectory_msgs/msg/joint_trajectory_point.hpp"
namespace joint_trajectory_controller
{
using TrajectoryPointIter = std::vector<trajectory_msgs::msg::JointTrajectoryPoint>::iterator;
using TrajectoryPointConstIter =
  std::vector<trajectory_msgs::msg::JointTrajectoryPoint>::const_iterator;

class Trajectory
{
public:
  Trajectory();

  explicit Trajectory(std::shared_ptr<trajectory_msgs::msg::JointTrajectory> joint_trajectory);

  explicit Trajectory(
    const rclcpp::Time & current_time,
    const trajectory_msgs::msg::JointTrajectoryPoint & current_point,
    std::shared_ptr<trajectory_msgs::msg::JointTrajectory> joint_trajectory);

  /**
   *  Set the point before the trajectory message is replaced/appended
   * Example: if we receive a new trajectory message and it's first point is 0.5 seconds
   * from the current one, we call this function to log the current state, then
   * append/replace the current trajectory
   * \param joints_angle_wraparound Vector of boolean where true value corresponds to a joint that
   * wrap around (ie. is continuous).
   */
  void set_point_before_trajectory_msg(
    const rclcpp::Time & current_time,
    const trajectory_msgs::msg::JointTrajectoryPoint & current_point,
    const std::vector<bool> & joints_angle_wraparound = std::vector<bool>());

  void update(std::shared_ptr<trajectory_msgs::msg::JointTrajectory> joint_trajectory);

  /// Find the segment (made up of 2 points) and its expected state from the
  /// containing trajectory.
  /**
   * Sampling trajectory at given \p sample_time.
   * If position in the \p end_segment_itr is missing it will be deduced from provided velocity, or
   * acceleration respectively. Deduction assumes that the provided velocity or acceleration have to
   * be reached at the time defined in the segment.
   *
   * This function by default assumes that sampling is only done at monotonically increasing \p
   * sample_time for any trajectory. That means, it will only search for a point matching the sample
   * time after the point it has been called before. If this isn't desired, set \p
   * search_monotonically_increasing to false.
   *
   * Specific case returns for start_segment_itr and end_segment_itr:
   * - Sampling before the trajectory start:
   *   start_segment_itr = begin(), end_segment_itr = begin()
   * - Sampling exactly on a point of the trajectory:
   *    start_segment_itr = iterator where point is, end_segment_itr = iterator after
   * start_segment_itr
   * - Sampling between points:
   *    start_segment_itr = iterator before the sampled point, end_segment_itr = iterator after
   * start_segment_itr
   * - Sampling after entire trajectory:
   *    start_segment_itr = --end(), end_segment_itr = end()
   * - Sampling empty msg or before the time given in set_point_before_trajectory_msg()
   *    return false
   *
   * \param[in] sample_time Time at which trajectory will be sampled.
   * \param[in] interpolation_method Specify whether splines, another method, or no interpolation at
   *      all.
   * \param[out] output_state Calculated new at \p sample_time.
   * \param[out] start_segment_itr Iterator to the start segment for given \p sample_time. See
   *      description above.
   * \param[out] end_segment_itr Iterator to the end segment for given \p sample_time. See
   *      description above.
   * \param[in] search_monotonically_increasing If set to true, the next sample call will start
   *      searching in the trajectory at the index of this call's result.
   */
  bool sample(
    const rclcpp::Time & sample_time,
    const interpolation_methods::InterpolationMethod interpolation_method,
    trajectory_msgs::msg::JointTrajectoryPoint & output_state,
    TrajectoryPointConstIter & start_segment_itr, TrajectoryPointConstIter & end_segment_itr,
    const bool search_monotonically_increasing = true);

  /**
   * Do interpolation between 2 states given a time in between their respective timestamps
   *
   * The start and end states need not necessarily be specified all the way to the acceleration
   * level:
   * - If only \b positions are specified, linear interpolation will be used.
   * - If \b positions and \b velocities are specified, a cubic spline will be used.
   * - If \b positions, \b velocities and \b accelerations are specified, a quintic spline will be
   * used.
   *
   * If start and end states have different specifications
   * (eg. start is position-only, end is position-velocity), the lowest common specification will be
   * used (position-only in the example).
   *
   * \param[in] time_a Time at which the segment state equals \p state_a.
   * \param[in] state_a State at \p time_a.
   * \param[in] time_b Time at which the segment state equals \p state_b.
   * \param[in] state_b State at time \p time_b.
   * \param[in] sample_time The time to sample, between time_a and time_b.
   * \param[out] output The state at \p sample_time.
   */
  void interpolate_between_points(
    const rclcpp::Time & time_a, const trajectory_msgs::msg::JointTrajectoryPoint & state_a,
    const rclcpp::Time & time_b, const trajectory_msgs::msg::JointTrajectoryPoint & state_b,
    const rclcpp::Time & sample_time, trajectory_msgs::msg::JointTrajectoryPoint & output);

  TrajectoryPointConstIter begin() const;

  TrajectoryPointConstIter end() const;

  rclcpp::Time time_from_start() const;

  bool has_trajectory_msg() const;

  bool has_nontrivial_msg() const;

  std::shared_ptr<trajectory_msgs::msg::JointTrajectory> get_trajectory_msg() const
  {
    return trajectory_msg_;
  }

  bool is_sampled_already() const { return sampled_already_; }

  /// Get the index of the segment start returned by the last \p sample() operation.
  /**
   * As the trajectory is only accessed at monotonically increasing sampling times, this index is
   * used to speed up the selection of relevant trajectory points.
   */
  size_t last_sample_index() const { return last_sample_idx_; }

private:
  void deduce_from_derivatives(
    trajectory_msgs::msg::JointTrajectoryPoint & first_state,
    trajectory_msgs::msg::JointTrajectoryPoint & second_state, const size_t dim,
    const double delta_t);

  std::shared_ptr<trajectory_msgs::msg::JointTrajectory> trajectory_msg_;
  rclcpp::Time trajectory_start_time_;

  rclcpp::Time time_before_traj_msg_;
  trajectory_msgs::msg::JointTrajectoryPoint state_before_traj_msg_;

  bool sampled_already_ = false;
  size_t last_sample_idx_ = 0;
};

/**
 * \return The map between \p t1 indices (implicitly encoded in return vector indices) to \p t2
 * indices. If \p t1 is <tt>"{C, B}"</tt> and \p t2 is <tt>"{A, B, C, D}"</tt>, the associated
 * mapping vector is <tt>"{2, 1}"</tt>. return empty vector if \p t1 is not a subset of \p t2.
 */
template <class T>
inline std::vector<size_t> mapping(const T & t1, const T & t2)
{
  // t1 must be a subset of t2
  if (t1.size() > t2.size())
  {
    return std::vector<size_t>();
  }

  std::vector<size_t> mapping_vector(t1.size());  // Return value
  for (auto t1_it = t1.begin(); t1_it != t1.end(); ++t1_it)
  {
    auto t2_it = std::find(t2.begin(), t2.end(), *t1_it);
    if (t2.end() == t2_it)
    {
      return std::vector<size_t>();
    }
    else
    {
      const size_t t1_dist = static_cast<size_t>(std::distance(t1.begin(), t1_it));
      const size_t t2_dist = static_cast<size_t>(std::distance(t2.begin(), t2_it));
      mapping_vector[t1_dist] = t2_dist;
    }
  }
  return mapping_vector;
}

/**
 * \param current_position The current position given from the controller, which will be adapted.
 * \param next_position Next position from which to compute the wraparound offset, i.e.,
 *      the first trajectory point
 * \param joints_angle_wraparound Vector of boolean where true value corresponds to a joint that
 * wrap around (ie. is continuous).
 */
void wraparound_joint(
  std::vector<double> & current_position, const std::vector<double> next_position,
  const std::vector<bool> & joints_angle_wraparound);

/**
 * \brief Fill the knot velocities of a global cubic spline (C2) in place.
 *
 * For each joint independently, solves the knot velocities that make the
 * acceleration continuous across every interior knot -- an O(n) tridiagonal
 * (Thomas) solve over the waypoint positions and their ``time_from_start`` --
 * and writes the result into ``points[i].velocities``. The end is always at
 * rest (``v[n-1] = 0``); the start is at rest too unless \p start_velocity is
 * given, which clamps it instead. Once velocities are present, the per-segment
 * cubic-Hermite sampling in \ref Trajectory::sample reproduces the global cubic
 * spline, so a positions-only trajectory is upgraded from linear (C0) to C2.
 *
 * \param[in,out] traj Trajectory whose points carry positions; velocities are filled.
 * \param[in] start_velocity Velocity at the first knot, one entry per joint. Empty (the default)
 *   keeps the rest condition ``v[0] = 0``; passing the current velocity clamps the start instead,
 *   so a streamed chunk continues the ongoing motion with acceleration still continuous.
 * \return true if velocities were written; false (trajectory left untouched) if it has
 *   fewer than two points, inconsistent widths, non-strictly-increasing timing, or a
 *   start_velocity whose size does not match the joint count.
 *
 * \code
 *   trajectory_msgs::msg::JointTrajectory msg;  // positions-only waypoints, with time_from_start
 *   fill_cubic_spline_velocities(msg);          // msg now has C2 knot velocities
 *   Trajectory traj(time_now, current_point, std::make_shared<...>(msg));
 *   traj.sample(t, interpolation_methods::DEFAULT_INTERPOLATION, out, start, end);
 * \endcode
 */
bool fill_cubic_spline_velocities(
  trajectory_msgs::msg::JointTrajectory & traj, const std::vector<double> & start_velocity = {});

}  // namespace joint_trajectory_controller

#endif  // JOINT_TRAJECTORY_CONTROLLER__TRAJECTORY_HPP_
