^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package omni_wheel_drive_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

6.10.1 (2026-11-04)
-------------------

6.10.0 (2026-10-05)
-------------------

6.9.0 (2026-08-12)
------------------
* Use new Command/State Interfaces API for tests (`#2476 <https://github.com/ros-controls/ros2_controllers/issues/2476>`_)
* Omni wheel drive odometry update (`#2286 <https://github.com/ros-controls/ros2_controllers/issues/2286>`_)
* Fix safety concerns with halt logic across controllers (`#2326 <https://github.com/ros-controls/ros2_controllers/issues/2326>`_)
* Use new chainable controller exports API (`#2350 <https://github.com/ros-controls/ros2_controllers/issues/2350>`_)
* Contributors: Devdoot Chatterjee, Sai Kishor Kothakota, lali-perelman

6.8.0 (2026-07-01)
------------------
* Test fix - call appropriate lifecycle transitions in controller tests: joint_state_broadcaster, joint_trajectory, omni_wheel_drive, bicycle_steering (`#2410 <https://github.com/ros-controls/ros2_controllers/issues/2410>`_)
* Contributors: Junius Santoso

6.7.0 (2026-05-12)
------------------
* Remove deprecated odometry reset methods (`#2252 <https://github.com/ros-controls/ros2_controllers/issues/2252>`_)
* Bump C++ version to C++20 (`#2331 <https://github.com/ros-controls/ros2_controllers/issues/2331>`_)
* Contributors: Christoph Fröhlich, Ege Kural

6.6.0 (2026-04-22)
------------------

6.5.0 (2026-04-02)
------------------
* Remove ament linters (`#2267 <https://github.com/ros-controls/ros2_controllers/issues/2267>`_)
* Contributors: Ivane Kotanov

6.4.0 (2026-03-12)
------------------
* Fix the teardown of the controller tests (`#2183 <https://github.com/ros-controls/ros2_controllers/issues/2183>`_)
* Add set_odometry service - omni wheel drive controller (`#2148 <https://github.com/ros-controls/ros2_controllers/issues/2148>`_)
* Contributors: Ege Kural, Sai Kishor Kothakota

6.3.0 (2026-02-03)
------------------

6.2.0 (2025-12-31)
------------------
* Tf prefix helper for omniwheel drive (`#2073 <https://github.com/ros-controls/ros2_controllers/issues/2073>`_)
* Contributors: Ege Kural

6.1.0 (2025-12-01)
------------------

6.0.0 (2025-11-10)
------------------
* Controller interface api update to ros2_controller packages (`#1973 <https://github.com/ros-controls/ros2_controllers/issues/1973>`_)
* Contributors: Anand Vardhan

5.8.0 (2025-10-02)
------------------
* Remove deprecated methods from ros2_control (`#1936 <https://github.com/ros-controls/ros2_controllers/issues/1936>`_)
* Fix: Remove deprecated `rclcpp::spin_some(node)` (`#1928 <https://github.com/ros-controls/ros2_controllers/issues/1928>`_)
* Contributors: Christoph Fröhlich, Kostubh Khandelwal

5.7.0 (2025-09-12)
------------------
* Fix use of M_PI in omni_wheel_driver_controller on MSVC (`#1886 <https://github.com/ros-controls/ros2_controllers/issues/1886>`_)
* [omni_wheel_drive_controller] Fix the broken links (`#1882 <https://github.com/ros-controls/ros2_controllers/issues/1882>`_)
* Contributors: Sai Kishor Kothakota, Silvio Traversaro

5.6.1 (2025-08-30)
------------------

5.6.0 (2025-08-29)
------------------

5.5.0 (2025-07-31)
------------------
* Add omni_wheel_drive_controller (`#1535 <https://github.com/ros-controls/ros2_controllers/issues/1535>`_)
* Contributors: Aarav Gupta

5.4.0 (2025-07-23)
------------------

5.3.0 (2025-07-14)
------------------

5.2.0 (2025-06-23)
------------------

5.1.0 (2025-06-11)
------------------

5.0.2 (2025-05-26)
------------------

5.0.1 (2025-05-24)
------------------

5.0.0 (2025-05-17)
------------------

4.24.0 (2025-04-27)
-------------------

4.23.0 (2025-04-10)
-------------------

4.22.0 (2025-03-17)
-------------------

4.21.0 (2025-03-01)
-------------------

4.20.0 (2025-01-29)
-------------------

4.19.0 (2025-01-13)
-------------------

4.18.0 (2024-12-19)
-------------------

4.17.0 (2024-12-07)
-------------------

4.16.0 (2024-11-08)
-------------------

4.15.0 (2024-10-07)
-------------------

4.14.0 (2024-09-11)
-------------------

4.13.0 (2024-08-22)
-------------------

4.12.1 (2024-08-14)
-------------------

4.12.0 (2024-07-23)
-------------------

4.11.0 (2024-07-09)
-------------------

4.10.0 (2024-07-01)
-------------------

4.9.0 (2024-06-05)
------------------

4.8.0 (2024-05-14)
------------------

4.7.0 (2024-03-22)
------------------

4.6.0 (2024-02-12)
------------------

4.5.0 (2024-01-31)
------------------

4.4.0 (2024-01-11)
------------------

4.3.0 (2024-01-08)
------------------

4.2.0 (2023-12-12)
------------------

4.1.0 (2023-12-01)
------------------

4.0.0 (2023-11-21)
------------------

3.17.0 (2023-10-31)
-------------------

3.16.0 (2023-09-20)
-------------------

3.15.0 (2023-09-11)
-------------------

3.14.0 (2023-08-16)
-------------------

3.13.0 (2023-08-04)
-------------------

3.12.0 (2023-07-18)
-------------------

3.11.0 (2023-06-24)
-------------------

3.10.1 (2023-06-06)
-------------------

3.10.0 (2023-06-04)
-------------------

3.9.0 (2023-05-28)
------------------

3.8.0 (2023-05-14)
------------------

3.7.0 (2023-05-02)
------------------

3.6.0 (2023-04-29)
------------------

3.5.0 (2023-04-14)
------------------

3.4.0 (2023-04-02)
------------------

3.3.0 (2023-03-07)
------------------

3.2.0 (2023-02-10)
------------------

3.1.0 (2023-01-26)
------------------

3.0.0 (2023-01-19)
------------------

2.15.0 (2022-12-06)
-------------------

2.14.0 (2022-11-18)
-------------------

2.13.0 (2022-10-05)
-------------------

2.12.0 (2022-09-01)
-------------------

2.11.0 (2022-08-04)
-------------------

2.10.0 (2022-08-01)
-------------------

2.9.0 (2022-07-14)
------------------

2.8.0 (2022-07-09)
------------------

2.7.0 (2022-07-03)
------------------

2.6.0 (2022-06-18)
------------------

2.5.0 (2022-05-13)
------------------

2.4.0 (2022-04-29)
------------------

2.3.0 (2022-04-21)
------------------

2.2.0 (2022-03-25)
------------------

2.1.0 (2022-02-23)
------------------

2.0.1 (2022-02-01)
------------------

2.0.0 (2022-01-28)
------------------

1.3.0 (2022-01-11)
------------------

1.2.0 (2021-12-29)
------------------

1.1.0 (2021-10-25)
------------------

1.0.0 (2021-09-29)
------------------

0.5.0 (2021-08-30)
------------------

0.4.1 (2021-07-08)
------------------

0.4.0 (2021-06-28)
------------------

0.3.1 (2021-05-23)
------------------

0.3.0 (2021-05-21)
------------------

0.2.1 (2021-05-03)
------------------

0.2.0 (2021-02-06)
------------------

0.1.2 (2021-01-07)
------------------

0.1.1 (2021-01-06)
------------------

0.1.0 (2020-12-23)
------------------
