// Copyright (c) 2021 ros2_control Development Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "joint_trajectory_controller/joint_trajectory_controller.hpp"

#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <memory>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

#include "angles/angles.h"
#include "controller_interface/helpers.hpp"
#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "joint_trajectory_controller/trajectory.hpp"
#include "lifecycle_msgs/msg/state.hpp"
#include "rclcpp/logging.hpp"
#include "rclcpp/qos.hpp"
#include "rclcpp/time.hpp"
#include "rclcpp_action/create_server.hpp"
#include "rclcpp_action/server_goal_handle.hpp"
#include "rclcpp_lifecycle/state.hpp"

#include "rclcpp/version.h"
// cppcheck-suppress syntaxError
#if RCLCPP_VERSION_GTE(29, 0, 0)
#include "urdf/model.hpp"
#else
#include "urdf/model.h"
#endif

namespace joint_trajectory_controller
{

auto interface_has_values = [](const auto & joint_interface) -> bool
{
  return std::find_if(
           joint_interface.begin(), joint_interface.end(),
           [](const auto & interface)
           {
             auto interface_op = interface.get().get_optional();
             return !interface_op.has_value() || !std::isfinite(interface_op.value());
           }) == joint_interface.end();
};

JointTrajectoryController::JointTrajectoryController()
: controller_interface::ControllerInterface(), dof_(0), num_cmd_joints_(0)
{
}

controller_interface::CallbackReturn JointTrajectoryController::on_init()
{
  try
  {
    // Create the parameter listener and get the parameters
    param_listener_ = std::make_shared<ParamListener>(get_node());
    params_ = param_listener_->get_params();
  }
  catch (const std::exception & e)
  {
    fprintf(stderr, "Exception thrown during init stage with message: %s \n", e.what());
    return CallbackReturn::ERROR;
  }

  const std::string & urdf = get_robot_description();
  std::vector<double> max_joint_vel(params_.joints.size(), 0.0);
  if (!urdf.empty())
  {
    urdf::Model model;
    if (!model.initString(urdf))
    {
      RCLCPP_ERROR(get_node()->get_logger(), "Failed to parse robot description!");
      return CallbackReturn::ERROR;
    }
    else
    {
      /// initialize the URDF model and update the joint angles wraparound vector
      // Configure joint position error normalization (angle_wraparound)
      joints_angle_wraparound_.resize(params_.joints.size(), false);
      for (size_t i = 0; i < params_.joints.size(); ++i)
      {
        auto urdf_joint = model.getJoint(params_.joints[i]);
        // Continuous joints are not required to declare <limit> in URDF; limits may be null.
        if (urdf_joint && urdf_joint->limits)
        {
          max_joint_vel[i] = urdf_joint->limits->velocity;
        }
        else if (urdf_joint)
        {
          // Continuous joints may omit <limit>; velocity is only needed for
          // decelerate_on_cancel (warned later if that feature cannot run).
          RCLCPP_DEBUG(
            get_node()->get_logger(),
            "Joint '%s' has no <limit> in the URDF; velocity limit unavailable (using 0.0).",
            params_.joints[i].c_str());
        }
        if (urdf_joint && urdf_joint->type == urdf::Joint::CONTINUOUS)
        {
          RCLCPP_DEBUG(
            get_node()->get_logger(), "joint '%s' is of type continuous, use angle_wraparound.",
            params_.joints[i].c_str());
          joints_angle_wraparound_[i] = true;
        }
        // do nothing if joint is not found in the URDF
      }
      RCLCPP_DEBUG(get_node()->get_logger(), "Successfully parsed URDF file");
    }
  }
  else
  {
    // empty URDF is used for some tests
    RCLCPP_DEBUG(get_node()->get_logger(), "No URDF file given");
  }

  // read the update_period_ for this controller
  if (get_update_rate() == 0)
  {
    throw std::runtime_error("Controller's update rate is set to 0. This should not happen!");
  }
  update_period_ =
    rclcpp::Duration(0.0, static_cast<uint32_t>(1.0e9 / static_cast<double>(get_update_rate())));

  // validate and configure decelerate_on_cancel
  if (params_.constraints.decelerate_on_cancel)
  {
    max_decel_.resize(params_.joints.size(), 0.0);
    stop_time_.resize(params_.joints.size(), 0.0);
    hold_position_.resize(params_.joints.size(), 0.0);
    stop_direction_.resize(params_.joints.size(), 0.0);

    should_decelerate_on_cancel_ = true;
    // check for valid max_deceleration values for each joint
    for (size_t i = 0; i < params_.joints.size() && should_decelerate_on_cancel_; ++i)
    {
      max_decel_[i] =
        params_.constraints.joints_map.at(params_.joints[i]).max_deceleration_on_cancel;

      if (max_decel_[i] <= 0.0)
      {
        RCLCPP_ERROR(
          get_node()->get_logger(),
          "Joint [%s] invalid max_deceleration_on_cancel [%.1f]. "
          "Falling back to hold position on cancel.",
          params_.joints[i].c_str(), max_decel_[i]);
        should_decelerate_on_cancel_ = false;
      }
      if (max_joint_vel[i] <= 0.0)
      {
        RCLCPP_ERROR(
          get_node()->get_logger(),
          "Joint [%s] has invalid joint velocity defined in URDF [%.1f]. "
          "Falling back to hold position on cancel.",
          params_.joints[i].c_str(), max_joint_vel[i]);
        should_decelerate_on_cancel_ = false;
      }
    }
    // if everything is valid reserve space for the stop trajectory on cancel
    if (should_decelerate_on_cancel_)
    {
      double max_t_stop = 0.0;
      // find the joint with the largest max time to stop
      for (size_t i = 0; i < params_.joints.size(); ++i)
      {
        stop_time_[i] = max_joint_vel[i] / max_decel_[i];
        max_t_stop = std::max(max_t_stop, stop_time_[i]);
      }
      // Number of points at multiples of sample_period (include initial point at t=0)
      const size_t num_points =
        static_cast<size_t>(std::ceil(max_t_stop / update_period_.seconds())) + 1;
      // create stop trajectory reserved storage for the worst case
      // (slowest to stop joint at max speed)
      stop_trajectory_ = std::make_shared<trajectory_msgs::msg::JointTrajectory>();
      stop_trajectory_->joint_names = params_.joints;
      stop_trajectory_->points.clear();
      trajectory_msgs::msg::JointTrajectoryPoint pt;
      pt.positions.resize(params_.joints.size(), 0.0);
      pt.velocities.resize(params_.joints.size(), 0.0);
      pt.accelerations.resize(params_.joints.size(), 0.0);
      stop_trajectory_->points.resize(num_points, pt);
    }
  }

  return CallbackReturn::SUCCESS;
}

controller_interface::InterfaceConfiguration
JointTrajectoryController::command_interface_configuration() const
{
  controller_interface::InterfaceConfiguration conf;
  conf.type = controller_interface::interface_configuration_type::INDIVIDUAL;
  conf.names.reserve(num_cmd_joints_ * params_.command_interfaces.size());
  for (const auto & joint_name : command_joint_names_)
  {
    for (const auto & interface_type : params_.command_interfaces)
    {
      conf.names.push_back(joint_name + "/" + interface_type);
    }
  }
  if (!params_.speed_scaling.command_interface.empty())
  {
    conf.names.push_back(params_.speed_scaling.command_interface);
  }
  return conf;
}

controller_interface::InterfaceConfiguration
JointTrajectoryController::state_interface_configuration() const
{
  controller_interface::InterfaceConfiguration conf;
  conf.type = controller_interface::interface_configuration_type::INDIVIDUAL;
  conf.names.reserve(dof_ * params_.state_interfaces.size());
  for (const auto & joint_name : params_.joints)
  {
    for (const auto & interface_type : params_.state_interfaces)
    {
      conf.names.push_back(joint_name + "/" + interface_type);
    }
  }
  if (!params_.speed_scaling.state_interface.empty())
  {
    conf.names.push_back(params_.speed_scaling.state_interface);
  }
  return conf;
}

controller_interface::return_type JointTrajectoryController::update(
  const rclcpp::Time & time, const rclcpp::Duration & period)
{
  auto logger = this->get_node()->get_logger();
  if (scaling_state_interface_.has_value())
  {
    auto scaling_state_interface_op = scaling_state_interface_->get().get_optional();
    if (!scaling_state_interface_op.has_value())
    {
      RCLCPP_DEBUG(logger, "Unable to retrieve scaling state interface value");
      return controller_interface::return_type::OK;
    }
    scaling_factor_ = scaling_state_interface_op.value();
  }

  if (scaling_command_interface_.has_value())
  {
    if (!scaling_command_interface_->get().set_value(scaling_factor_cmd_.load()))
    {
      RCLCPP_ERROR(logger, "Could not set speed scaling factor through command interfaces.");
    }
  }

  // update dynamic parameters
  if (param_listener_->try_update_params(params_))
  {
    default_tolerances_ = get_segment_tolerances(logger, params_);
    // update the PID gains
    // variable use_closed_loop_pid_adapter_ is updated in on_configure only
    if (use_closed_loop_pid_adapter_)
    {
      update_pids();
    }
  }

  // don't update goal after we sampled the trajectory to avoid any race condition
  rt_active_goal_local_.reset();
  rt_active_goal_.try_get([&](const auto & goal) { rt_active_goal_local_ = goal; });

  // Check if a new trajectory message has been received from Non-RT threads
  const auto current_trajectory_msg = current_trajectory_->get_trajectory_msg();
  std::shared_ptr<trajectory_msgs::msg::JointTrajectory> new_external_msg = current_trajectory_msg;
  rt_new_trajectory_msg_.try_get([&](auto & msg) { new_external_msg = msg; });
  // Discard, if a goal is pending but still not active (somewhere stuck in goal_handle_timer_)
  if (
    new_external_msg && current_trajectory_msg != new_external_msg &&
    (rt_has_pending_goal_ && !rt_active_goal_local_) == false)
  {
    bool blended = false;
    if (
      params_.allow_trajectory_replacement && has_active_trajectory() &&
      current_trajectory_->has_nontrivial_msg() && !rt_is_holding_)
    {
      blended = blend_with_active_trajectory(new_external_msg, time);
    }
    if (!blended)
    {
      // legacy behavior: joints omitted from the new message hold at the current position
      fill_partial_goal(new_external_msg);
      sort_to_local_joint_order(new_external_msg);
      blend_prefix_size_ = 0;
    }
    // TODO(denis): Add here integration of position and velocity
    current_trajectory_->update(new_external_msg);
  }

  // current state update
  state_current_.time_from_start.sec = 0;
  state_current_.time_from_start.nanosec = 0;
  read_state_from_state_interfaces(state_current_);

  // currently carrying out a trajectory
  if (has_active_trajectory())
  {
    bool first_sample = false;
    TrajectoryPointConstIter start_segment_itr, end_segment_itr;
    // if sampling the first time, set the point before you sample
    if (!current_trajectory_->is_sampled_already())
    {
      first_sample = true;
      if (params_.interpolate_from_desired_state)
      {
        if (std::abs(last_commanded_time_.seconds()) < std::numeric_limits<float>::epsilon())
        {
          last_commanded_time_ = time;
        }
        current_trajectory_->set_point_before_trajectory_msg(
          last_commanded_time_, last_commanded_state_, joints_angle_wraparound_);
      }
      else
      {
        current_trajectory_->set_point_before_trajectory_msg(
          time, state_current_, joints_angle_wraparound_);
      }
      traj_time_ = time;
    }
    else
    {
      traj_time_ += period * scaling_factor_.load();
    }

    // Sample expected state from the trajectory
    current_trajectory_->sample(
      traj_time_, interpolation_method_, state_desired_, start_segment_itr, end_segment_itr);
    state_desired_.time_from_start = traj_time_ - current_trajectory_->time_from_start();

    const auto next_point_index = std::distance(current_trajectory_->begin(), end_segment_itr);

    // Sample setpoint for next control cycle
    const bool valid_point = current_trajectory_->sample(
      traj_time_ + update_period_, interpolation_method_, command_next_, start_segment_itr,
      end_segment_itr, false);

    state_current_.time_from_start = time - current_trajectory_->time_from_start();

    if (valid_point)
    {
      const rclcpp::Time traj_start = current_trajectory_->time_from_start();
      // this is the time instance
      // - started with the first segment: when the first point will be reached (in the future)
      // - later: when the point of the current segment was reached
      const rclcpp::Time segment_time_from_start = traj_start + start_segment_itr->time_from_start;
      // time_difference is
      // - negative until first point is reached
      // - counting from zero to time_from_start of next point
      double time_difference = traj_time_.seconds() - segment_time_from_start.seconds();
      bool tolerance_violated_while_moving = false;
      bool outside_goal_tolerance = false;
      bool within_goal_time = true;
      const bool before_last_point = end_segment_itr != current_trajectory_->end();
      rt_goal_tolerances_.try_get([&](const SegmentTolerances & tol) { active_tol_ = tol; });

      // have we reached the end, are not holding position, and is a timeout configured?
      // Check independently of other tolerances
      if (
        !before_last_point && !rt_is_holding_ && cmd_timeout_ > 0.0 &&
        time_difference > cmd_timeout_)
      {
        RCLCPP_WARN(logger, "Aborted due to command timeout");

        if (should_decelerate_on_cancel_)
        {
          // calculate stopping position based on max deceleration
          rt_is_holding_ = true;
          rt_new_trajectory_msg_.try_set([msg = decelerate_to_hold_position()](auto & m)
                                         { m = msg; });
        }
        else
        {
          // hold current position
          rt_new_trajectory_msg_.try_set([msg = set_hold_position()](auto & m) { m = msg; });
        }
      }

      // Check state/goal tolerance
      for (size_t index = 0; index < dof_; ++index)
      {
        compute_error_for_joint(state_error_, index, state_current_, state_desired_);

        // Always check the state tolerance on the first sample in case the first sample
        // is the last point
        // print output per default, goal will be aborted afterwards
        if (
          (before_last_point || first_sample) && !rt_is_holding_ &&
          !check_state_tolerance_per_joint(
            state_error_, index, active_tol_.state_tolerance[index], true /* show_errors */))
        {
          tolerance_violated_while_moving = true;
        }
        // past the final point, check that we end up inside goal tolerance
        if (
          !before_last_point && !rt_is_holding_ &&
          !check_state_tolerance_per_joint(
            state_error_, index, active_tol_.goal_state_tolerance[index], false /* show_errors */))
        {
          outside_goal_tolerance = true;

          if (std::isfinite(active_tol_.goal_time_tolerance))
          {
            // if we exceed goal_time_tolerance set it to aborted
            if (time_difference > active_tol_.goal_time_tolerance)
            {
              within_goal_time = false;
              // print once, goal will be aborted afterwards
              check_state_tolerance_per_joint(
                state_error_, index, active_tol_.goal_state_tolerance[index],
                true /* show_errors */);
            }
          }
        }
      }

      // set values for next hardware write() if tolerance is met
      if (!tolerance_violated_while_moving && within_goal_time)
      {
        if (use_closed_loop_pid_adapter_)
        {
          // Update PIDs
          for (auto i = 0ul; i < num_cmd_joints_; ++i)
          {
            // If effort interface only, add desired effort as feed forward
            // If velocity interface, ignore desired effort
            size_t index_cmd_joint = map_cmd_to_joints_[i];
            closed_loop_pid_command_[index_cmd_joint] =
              (command_next_.velocities[index_cmd_joint] * ff_velocity_scale_[i]) +
              (has_effort_command_interface_ ? command_next_.effort[index_cmd_joint] : 0.0) +
              pids_[i]->compute_command(
                state_error_.positions[index_cmd_joint], state_error_.velocities[index_cmd_joint],
                period);
          }
        }

        // set values for next hardware write()
        if (has_position_command_interface_)
        {
          assign_interface_from_point(joint_command_interface_[0], command_next_.positions);
        }
        if (has_velocity_command_interface_)
        {
          assign_interface_from_point(
            joint_command_interface_[1],
            use_closed_loop_pid_adapter_ ? closed_loop_pid_command_ : command_next_.velocities);
        }
        if (has_acceleration_command_interface_)
        {
          assign_interface_from_point(joint_command_interface_[2], command_next_.accelerations);
        }
        if (has_effort_command_interface_)
        {
          assign_interface_from_point(
            joint_command_interface_[3],
            use_closed_loop_pid_adapter_ ? closed_loop_pid_command_ : state_desired_.effort);
        }

        // store the previous command and time used in open-loop control mode
        last_commanded_state_ = command_next_;
        rt_last_commanded_state_.try_set([this](trajectory_msgs::msg::JointTrajectoryPoint & state)
                                         { state = last_commanded_state_; });
        last_commanded_time_ = time;
      }

      if (rt_active_goal_local_)
      {
        // send feedback
        rt_active_goal_local_->trySetFeedback(
          [&](FollowJTrajAction::Feedback & feedback)
          {
            feedback.header.stamp = time;
            feedback.actual = state_current_;
            feedback.desired = state_desired_;
            feedback.error = state_error_;
            // report the index relative to the trajectory the client sent (a blend prepends points)
            feedback.index = std::max(
              0, static_cast<int32_t>(next_point_index) - static_cast<int32_t>(blend_prefix_size_));
          });

        // check abort
        if (tolerance_violated_while_moving)
        {
          auto result = std::make_shared<FollowJTrajAction::Result>();
          result->set__error_code(FollowJTrajAction::Result::PATH_TOLERANCE_VIOLATED);
          result->set__error_string("Aborted due to path tolerance violation");
          rt_active_goal_local_->setAborted(result);
          rt_active_goal_.try_set([](auto & goal) { goal = RealtimeGoalHandlePtr(); });
          rt_has_pending_goal_ = false;

          RCLCPP_WARN(logger, "Aborted due to state tolerance violation");

          if (should_decelerate_on_cancel_)
          {
            rt_is_holding_ = true;
            rt_new_trajectory_msg_.try_set([msg = decelerate_to_hold_position()](auto & m)
                                           { m = msg; });
          }
          else
          {
            rt_new_trajectory_msg_.try_set([msg = set_hold_position()](auto & m) { m = msg; });
          }
        }
        // check goal tolerance
        else if (!before_last_point)
        {
          if (!outside_goal_tolerance)
          {
            auto result = std::make_shared<FollowJTrajAction::Result>();
            result->set__error_code(FollowJTrajAction::Result::SUCCESSFUL);
            result->set__error_string("Goal successfully reached!");
            rt_active_goal_local_->setSucceeded(result);
            rt_active_goal_.try_set([](auto & goal) { goal = RealtimeGoalHandlePtr(); });
            rt_has_pending_goal_ = false;

            RCLCPP_INFO(logger, "Goal reached, success!");

            rt_new_trajectory_msg_.try_set([msg = set_success_trajectory_point()](auto & m)
                                           { m = msg; });
          }
          else if (!within_goal_time)
          {
            const std::string error_string = "Aborted due to goal_time_tolerance exceeding by " +
                                             std::to_string(time_difference) + " seconds";

            auto result = std::make_shared<FollowJTrajAction::Result>();
            result->set__error_code(FollowJTrajAction::Result::GOAL_TOLERANCE_VIOLATED);
            result->set__error_string(error_string);
            rt_active_goal_local_->setAborted(result);
            rt_active_goal_.try_set([](auto & goal) { goal = RealtimeGoalHandlePtr(); });
            rt_has_pending_goal_ = false;

            RCLCPP_WARN(logger, "%s", error_string.c_str());

            if (should_decelerate_on_cancel_)
            {
              rt_is_holding_ = true;
              rt_new_trajectory_msg_.try_set([msg = decelerate_to_hold_position()](auto & m)
                                             { m = msg; });
            }
            else
            {
              rt_new_trajectory_msg_.try_set([msg = set_hold_position()](auto & m) { m = msg; });
            }
          }
        }
      }
      else if (tolerance_violated_while_moving && !rt_has_pending_goal_)
      {
        // we need to ensure that there is no pending goal -> we get a race condition otherwise
        RCLCPP_ERROR(logger, "Holding position due to state tolerance violation");

        if (should_decelerate_on_cancel_)
        {
          // calculate stopping position based on max deceleration
          rt_is_holding_ = true;
          rt_new_trajectory_msg_.try_set([msg = decelerate_to_hold_position()](auto & m)
                                         { m = msg; });
        }
        else
        {
          // hold current position
          rt_new_trajectory_msg_.try_set([msg = set_hold_position()](auto & m) { m = msg; });
        }
      }
      else if (!before_last_point && !within_goal_time && !rt_has_pending_goal_)
      {
        RCLCPP_ERROR(logger, "Exceeded goal_time_tolerance: holding position...");

        if (should_decelerate_on_cancel_)
        {
          // calculate stopping position based on max deceleration
          rt_is_holding_ = true;
          rt_new_trajectory_msg_.try_set([msg = decelerate_to_hold_position()](auto & m)
                                         { m = msg; });
        }
        else
        {
          // hold current position
          rt_new_trajectory_msg_.try_set([msg = set_hold_position()](auto & m) { m = msg; });
        }
      }
      // else, run another cycle while waiting for outside_goal_tolerance
      // to be satisfied (will stay in this state until new message arrives)
      // or outside_goal_tolerance violated within the goal_time_tolerance
    }
  }

  publish_state(time, state_desired_, state_current_, state_error_);
  return controller_interface::return_type::OK;
}

void JointTrajectoryController::read_state_from_state_interfaces(JointTrajectoryPoint & state)
{
  auto logger = get_node()->get_logger();
  auto assign_point_from_state_interface =
    [&](std::vector<double> & trajectory_point_interface, const auto & joint_interface)
  {
    for (size_t index = 0; index < dof_; ++index)
    {
      const auto joint_state_interface_value_op = joint_interface[index].get().get_optional();
      if (!joint_state_interface_value_op.has_value())
      {
        RCLCPP_DEBUG(
          logger, "Unable to retrieve joint state interface value for joint at index %zu", index);
      }
      else
      {
        trajectory_point_interface[index] = joint_state_interface_value_op.value();
      }
    }
  };

  // Assign values from the hardware
  // Position states always exist
  assign_point_from_state_interface(state.positions, joint_state_interface_[0]);
  // velocity and acceleration states are optional
  if (has_velocity_state_interface_)
  {
    assign_point_from_state_interface(state.velocities, joint_state_interface_[1]);
    // Acceleration is used only in combination with velocity
    if (has_acceleration_state_interface_)
    {
      assign_point_from_state_interface(state.accelerations, joint_state_interface_[2]);
    }
    else
    {
      // Make empty so the property is ignored during interpolation
      state.accelerations.clear();
    }
  }
  else
  {
    // Make empty so the property is ignored during interpolation
    state.velocities.clear();
    state.accelerations.clear();
  }
  // No state interface for now, use command interface
  if (has_effort_command_interface_)
  {
    assign_point_from_command_interface(state.effort, joint_command_interface_[3]);
  }
}

void JointTrajectoryController::update_state_from_command_interfaces(JointTrajectoryPoint & state)
{
  // Assign values from the command interfaces as state
  // Position state interface has to exist always, so no need to check for it
  if (has_position_command_interface_ && interface_has_values(joint_command_interface_[0]))
  {
    assign_point_from_command_interface(state.positions, joint_command_interface_[0]);
  }

  // velocity and acceleration states are optional
  if (has_velocity_command_interface_ && interface_has_values(joint_command_interface_[1]))
  {
    // If no state interface exists, then our velocities vector will be empty, and we must resize
    // before assigning.
    if (!has_velocity_state_interface_)
    {
      state.velocities.resize(dof_, std::numeric_limits<double>::quiet_NaN());
    }
    assign_point_from_command_interface(state.velocities, joint_command_interface_[1]);
  }

  if (has_acceleration_command_interface_ && interface_has_values(joint_command_interface_[2]))
  {
    if (!has_acceleration_state_interface_)
    {
      state.accelerations.resize(dof_, std::numeric_limits<double>::quiet_NaN());
    }
    assign_point_from_command_interface(state.accelerations, joint_command_interface_[2]);
  }

  if (has_effort_command_interface_ && interface_has_values(joint_command_interface_[3]))
  {
    state.effort.resize(dof_, std::numeric_limits<double>::quiet_NaN());
    assign_point_from_command_interface(state.effort, joint_command_interface_[3]);
  }
}

bool JointTrajectoryController::read_commands_from_command_interfaces(
  JointTrajectoryPoint & commands)
{
  bool has_values = true;

  auto assign_point_from_interface =
    [&](std::vector<double> & trajectory_point_interface, const auto & joint_interface)
  {
    for (size_t index = 0; index < num_cmd_joints_; ++index)
    {
      auto joint_interface_op = joint_interface[index].get().get_optional();
      if (!joint_interface_op.has_value())
      {
        RCLCPP_DEBUG(
          get_node()->get_logger(), "Unable to retrieve value of joint interface at index %zu",
          index);
        continue;
      }
      trajectory_point_interface[map_cmd_to_joints_[index]] = joint_interface_op.value();
    }
  };

  // Assign values from the command interfaces as command.
  if (has_position_command_interface_)
  {
    if (interface_has_values(joint_command_interface_[0]))
    {
      assign_point_from_interface(commands.positions, joint_command_interface_[0]);
    }
    else
    {
      commands.positions.clear();
      has_values = false;
    }
  }
  if (has_velocity_command_interface_)
  {
    if (interface_has_values(joint_command_interface_[1]))
    {
      assign_point_from_interface(commands.velocities, joint_command_interface_[1]);
    }
    else
    {
      commands.velocities.clear();
      has_values = false;
    }
  }
  if (has_acceleration_command_interface_)
  {
    if (interface_has_values(joint_command_interface_[2]))
    {
      assign_point_from_interface(commands.accelerations, joint_command_interface_[2]);
    }
    else
    {
      commands.accelerations.clear();
      has_values = false;
    }
  }
  if (has_effort_command_interface_)
  {
    if (interface_has_values(joint_command_interface_[3]))
    {
      assign_point_from_interface(commands.effort, joint_command_interface_[3]);
    }
    else
    {
      commands.effort.clear();
      has_values = false;
    }
  }

  return has_values;
}

void JointTrajectoryController::query_state_service(
  const std::shared_ptr<control_msgs::srv::QueryTrajectoryState::Request> request,
  std::shared_ptr<control_msgs::srv::QueryTrajectoryState::Response> response)
{
  const auto logger = get_node()->get_logger();
  // Preconditions
  if (get_lifecycle_id() != lifecycle_msgs::msg::State::PRIMARY_STATE_ACTIVE)
  {
    RCLCPP_ERROR(logger, "Can't sample trajectory. Controller is not active.");
    response->success = false;
    return;
  }

  response->name = params_.joints;
  trajectory_msgs::msg::JointTrajectoryPoint state_requested = state_current_;
  if (has_active_trajectory())
  {
    TrajectoryPointConstIter start_segment_itr, end_segment_itr;
    response->success = current_trajectory_->sample(
      static_cast<rclcpp::Time>(request->time), interpolation_method_, state_requested,
      start_segment_itr, end_segment_itr);
    // If the requested sample time precedes the trajectory finish time respond as failure
    if (response->success)
    {
      if (end_segment_itr == current_trajectory_->end())
      {
        RCLCPP_ERROR(logger, "Requested sample time precedes the current trajectory end time.");
        response->success = false;
      }
    }
    else
    {
      RCLCPP_ERROR(
        logger, "Requested sample time is earlier than the current trajectory start time.");
    }
  }
  else
  {
    RCLCPP_ERROR(logger, "Currently there is no valid trajectory instance.");
    response->success = false;
  }
  response->position = state_requested.positions;
  response->velocity = state_requested.velocities;
  response->acceleration = state_requested.accelerations;
}

controller_interface::CallbackReturn JointTrajectoryController::on_configure(
  const rclcpp_lifecycle::State &)
{
  auto logger = get_node()->get_logger();

  // update the dynamic map parameters
  param_listener_->refresh_dynamic_parameters();

  // get parameters from the listener in case they were updated
  params_ = param_listener_->get_params();

  // get degrees of freedom
  dof_ = params_.joints.size();
  blend_commanded_.assign(dof_, false);

  // TODO(destogl): why is this here? Add comment or move
  if (!reset())
  {
    return CallbackReturn::FAILURE;
  }

  command_joint_names_ = params_.command_joints;

  if (command_joint_names_.empty())
  {
    command_joint_names_ = params_.joints;
    RCLCPP_INFO(
      logger, "No specific joint names are used for command interfaces. Using 'joints' parameter.");
  }
  num_cmd_joints_ = command_joint_names_.size();

  if (num_cmd_joints_ > dof_)
  {
    RCLCPP_ERROR(
      logger, "The 'command_joints' parameter must not exceed the size of the 'joints' parameter.");
    return CallbackReturn::FAILURE;
  }
  else if (num_cmd_joints_ < dof_)
  {
    // create a map for the command joints
    map_cmd_to_joints_ = mapping(command_joint_names_, params_.joints);
    if (map_cmd_to_joints_.size() != num_cmd_joints_)
    {
      RCLCPP_ERROR(
        logger,
        "'command_joints' parameter must be a subset of 'joints' parameter, if their size is not "
        "equal.");
      return CallbackReturn::FAILURE;
    }
    for (size_t i = 0; i < command_joint_names_.size(); i++)
    {
      RCLCPP_DEBUG(
        logger, "Command joint %zu: '%s' maps to joint %zu: '%s'.", i,
        command_joint_names_[i].c_str(), map_cmd_to_joints_[i],
        params_.joints.at(map_cmd_to_joints_[i]).c_str());
    }
  }
  else
  {
    // create a map for the command joints, trivial if the size is the same
    map_cmd_to_joints_.resize(num_cmd_joints_);
    std::iota(map_cmd_to_joints_.begin(), map_cmd_to_joints_.end(), 0);
  }

  if (params_.command_interfaces.empty())
  {
    RCLCPP_ERROR(logger, "'command_interfaces' parameter is empty.");
    return CallbackReturn::FAILURE;
  }

  // Check if only allowed interface types are used and initialize storage to avoid memory
  // allocation during activation
  joint_command_interface_.resize(allowed_interface_types_.size());
  for (auto & itf : joint_command_interface_)
  {
    itf.reserve(params_.joints.size());
  }

  has_position_command_interface_ =
    contains_interface_type(params_.command_interfaces, hardware_interface::HW_IF_POSITION);
  has_velocity_command_interface_ =
    contains_interface_type(params_.command_interfaces, hardware_interface::HW_IF_VELOCITY);
  has_acceleration_command_interface_ =
    contains_interface_type(params_.command_interfaces, hardware_interface::HW_IF_ACCELERATION);
  has_effort_command_interface_ =
    contains_interface_type(params_.command_interfaces, hardware_interface::HW_IF_EFFORT);

  // if there is only velocity or if there is effort command interface
  // then use also PID adapter
  use_closed_loop_pid_adapter_ =
    (has_velocity_command_interface_ && params_.command_interfaces.size() == 1) ||
    (has_effort_command_interface_ && params_.command_interfaces.size() == 1);

  closed_loop_pid_command_.resize(dof_, 0.0);

  if (use_closed_loop_pid_adapter_)
  {
    pids_.resize(num_cmd_joints_);
    ff_velocity_scale_.resize(num_cmd_joints_);

    update_pids();
  }

  if (params_.state_interfaces.empty())
  {
    RCLCPP_ERROR(logger, "'state_interfaces' parameter is empty.");
    return CallbackReturn::FAILURE;
  }

  // Check if only allowed interface types are used and initialize storage to avoid memory
  // allocation during activation
  // Note: 'effort' storage is also here, but never used. Still, for this is OK.
  joint_state_interface_.resize(allowed_interface_types_.size());
  for (auto & itf : joint_state_interface_)
  {
    itf.reserve(params_.joints.size());
  }

  has_position_state_interface_ =
    contains_interface_type(params_.state_interfaces, hardware_interface::HW_IF_POSITION);
  has_velocity_state_interface_ =
    contains_interface_type(params_.state_interfaces, hardware_interface::HW_IF_VELOCITY);
  has_acceleration_state_interface_ =
    contains_interface_type(params_.state_interfaces, hardware_interface::HW_IF_ACCELERATION);

  // Validation of combinations of state and velocity together have to be done
  // here because the parameter validators only deal with each parameter
  // separately.
  if (
    has_velocity_command_interface_ && params_.command_interfaces.size() == 1 &&
    (!has_velocity_state_interface_ || !has_position_state_interface_))
  {
    RCLCPP_ERROR(
      logger,
      "'velocity' command interface can only be used alone if 'velocity' and "
      "'position' state interfaces are present");
    return CallbackReturn::FAILURE;
  }

  // effort only or effort and position command interfaces require position and velocity state
  if (
    has_effort_command_interface_ &&
    (params_.command_interfaces.size() == 1 ||
     (params_.command_interfaces.size() == 2 && has_position_command_interface_)) &&
    (!has_velocity_state_interface_ || !has_position_state_interface_))
  {
    RCLCPP_ERROR(
      logger,
      "'effort' command interface can only be used alone or with 'position' command interface "
      "if 'velocity' and 'position' state interfaces are present");
    return CallbackReturn::FAILURE;
  }

  // velocity state interface is required to calculate ramped stop trajectories
  if (should_decelerate_on_cancel_ && !has_velocity_state_interface_)
  {
    RCLCPP_WARN(
      get_node()->get_logger(),
      "Decelerate on cancel is enabled but hardware does not support velocity state interface. "
      "Falling back to hold position on cancel.");
    should_decelerate_on_cancel_ = false;
  }

  auto get_interface_list = [](const std::vector<std::string> & interface_types)
  {
    std::stringstream ss_interfaces;
    for (size_t index = 0; index < interface_types.size(); ++index)
    {
      if (index != 0)
      {
        ss_interfaces << " ";
      }
      ss_interfaces << interface_types[index];
    }
    return ss_interfaces.str();
  };

  // Print output so users can be sure the interface setup is correct
  RCLCPP_INFO(
    logger, "Command interfaces are [%s] and state interfaces are [%s].",
    get_interface_list(params_.command_interfaces).c_str(),
    get_interface_list(params_.state_interfaces).c_str());

  // parse remaining parameters
  default_tolerances_ = get_segment_tolerances(logger, params_);
  rt_goal_tolerances_.set(default_tolerances_);
  active_tol_ = default_tolerances_;
  const std::string interpolation_string =
    get_node()->get_parameter("interpolation_method").as_string();
  interpolation_method_ = interpolation_methods::from_string(interpolation_string);
  RCLCPP_INFO(logger, "Using '%s' interpolation method.", interpolation_string.c_str());

  if (params_.positions_upsampling.enable)
  {
    RCLCPP_INFO(
      logger, "Positions upsampling enabled (policy_frequency=%.2f Hz).",
      params_.positions_upsampling.policy_frequency);
    RCLCPP_WARN_EXPRESSION(
      logger, interpolation_method_ == interpolation_methods::InterpolationMethod::NONE,
      "positions_upsampling has no effect when interpolation_method is 'none'.");
    RCLCPP_WARN_EXPRESSION(
      logger, params_.positions_upsampling.policy_frequency == 0.0,
      "positions_upsampling.policy_frequency is 0: chunks without their own timing will be "
      "rejected.");
  }

  // prepare hold_position_msg
  init_hold_position_msg();

  // create subscriber and publishers
  joint_command_subscriber_ =
    get_node()->create_subscription<trajectory_msgs::msg::JointTrajectory>(
      "~/joint_trajectory", rclcpp::SystemDefaultsQoS(),
      std::bind(&JointTrajectoryController::topic_callback, this, std::placeholders::_1));

  state_publisher_ =
    std::make_unique<StatePublisher>(get_node(), "~/controller_state", rclcpp::SystemDefaultsQoS());

  state_msg_.joint_names = params_.joints;
  state_msg_.reference.positions.resize(dof_);
  state_msg_.reference.velocities.resize(dof_);
  state_msg_.reference.accelerations.resize(dof_);
  state_msg_.feedback.positions.resize(dof_);
  state_msg_.error.positions.resize(dof_);
  if (has_velocity_state_interface_)
  {
    state_msg_.feedback.velocities.resize(dof_);
    state_msg_.error.velocities.resize(dof_);
  }
  if (has_acceleration_state_interface_)
  {
    state_msg_.feedback.accelerations.resize(dof_);
    state_msg_.error.accelerations.resize(dof_);
  }
  if (has_position_command_interface_)
  {
    state_msg_.output.positions.resize(dof_);
  }
  if (has_velocity_command_interface_)
  {
    state_msg_.output.velocities.resize(dof_);
  }
  if (has_acceleration_command_interface_)
  {
    state_msg_.output.accelerations.resize(dof_);
  }
  if (has_effort_command_interface_)
  {
    state_msg_.output.effort.resize(dof_);
  }

  // action server configuration
  if (params_.allow_partial_joints_goal)
  {
    RCLCPP_INFO(logger, "Goals with partial set of joints are allowed");
  }

  RCLCPP_INFO(
    logger, "Action status changes will be monitored at %.2f Hz.", params_.action_monitor_rate);
  goal_handle_timer_period_ = rclcpp::Duration::from_seconds(1.0 / params_.action_monitor_rate);

  using namespace std::placeholders;
  action_server_ = rclcpp_action::create_server<FollowJTrajAction>(
    get_node()->get_node_base_interface(), get_node()->get_node_clock_interface(),
    get_node()->get_node_logging_interface(), get_node()->get_node_waitables_interface(),
    std::string(get_node()->get_name()) + "/follow_joint_trajectory",
    std::bind(&JointTrajectoryController::goal_received_callback, this, _1, _2),
    std::bind(&JointTrajectoryController::goal_cancelled_callback, this, _1),
    std::bind(&JointTrajectoryController::goal_accepted_callback, this, _1));

  resize_joint_trajectory_point(state_current_, dof_);
  resize_joint_trajectory_point_command(
    command_current_, dof_, std::numeric_limits<double>::quiet_NaN());
  resize_joint_trajectory_point(state_desired_, dof_);
  resize_joint_trajectory_point(state_error_, dof_);
  resize_joint_trajectory_point(
    last_commanded_state_, dof_, std::numeric_limits<double>::quiet_NaN());

  // create services
  query_state_srv_ = get_node()->create_service<control_msgs::srv::QueryTrajectoryState>(
    std::string(get_node()->get_name()) + "/query_state",
    std::bind(&JointTrajectoryController::query_state_service, this, _1, _2));

  if (
    !has_velocity_command_interface_ && !has_acceleration_command_interface_ &&
    !has_effort_command_interface_)
  {
    auto qos = rclcpp::SystemDefaultsQoS();
    qos.transient_local();
    scaling_factor_sub_ = get_node()->create_subscription<SpeedScalingMsg>(
      "~/speed_scaling_input", qos,
      [&](const SpeedScalingMsg & msg) { set_scaling_factor(msg.factor); });
    RCLCPP_INFO(
      logger, "Setting initial scaling factor to %2f",
      params_.speed_scaling.initial_scaling_factor);
    scaling_factor_ = params_.speed_scaling.initial_scaling_factor;
  }
  else
  {
    RCLCPP_WARN_EXPRESSION(
      logger, params_.speed_scaling.initial_scaling_factor != 1.0,
      "Speed scaling is currently only supported for position interfaces. If you want to make use "
      "of speed scaling, please only use a position interface when configuring this controller.");
    scaling_factor_ = 1.0;
  }
  if (!params_.speed_scaling.state_interface.empty())
  {
    RCLCPP_INFO(
      logger, "Using scaling state from the hardware from interface %s.",
      params_.speed_scaling.state_interface.c_str());
  }
  else
  {
    RCLCPP_INFO(
      get_node()->get_logger(),
      "No scaling interface set. This controller will not read speed scaling from the hardware.");
  }
  scaling_factor_cmd_.store(scaling_factor_.load());

  if (get_update_rate() == 0)
  {
    throw std::runtime_error("Controller's update rate is set to 0. This should not happen!");
  }
  update_period_ =
    rclcpp::Duration(0.0, static_cast<uint32_t>(1.0e9 / static_cast<double>(get_update_rate())));

  return CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn JointTrajectoryController::on_activate(
  const rclcpp_lifecycle::State &)
{
  auto logger = get_node()->get_logger();

  // update the dynamic map parameters
  param_listener_->refresh_dynamic_parameters();

  // get parameters from the listener in case they were updated
  params_ = param_listener_->get_params();

  // parse remaining parameters
  default_tolerances_ = get_segment_tolerances(logger, params_);

  // Set scaling interfaces
  if (!params_.speed_scaling.state_interface.empty())
  {
    auto it = std::find_if(
      state_interfaces_.begin(), state_interfaces_.end(), [&](auto & interface)
      { return (interface.get_name() == params_.speed_scaling.state_interface); });
    if (it != state_interfaces_.end())
    {
      scaling_state_interface_ = *it;
    }
    else
    {
      RCLCPP_ERROR(
        logger, "Did not find speed scaling interface '%s' in state interfaces.",
        params_.speed_scaling.state_interface.c_str());
      return CallbackReturn::ERROR;
    }
  }
  if (!params_.speed_scaling.command_interface.empty())
  {
    auto it = std::find_if(
      command_interfaces_.begin(), command_interfaces_.end(), [&](auto & interface)
      { return (interface.get_name() == params_.speed_scaling.command_interface); });
    if (it != command_interfaces_.end())
    {
      scaling_command_interface_ = *it;
    }
    else
    {
      RCLCPP_ERROR(
        logger, "Did not find speed scaling interface '%s' in command interfaces.",
        params_.speed_scaling.command_interface.c_str());
      return CallbackReturn::ERROR;
    }
  }

  // Clear the ordered interfaces: they may hold references to loans already released, e.g.
  // when on_deactivate returned early or a previous activation failed. Capacity is kept.
  for (size_t index = 0; index < allowed_interface_types_.size(); ++index)
  {
    joint_command_interface_[index].clear();
    joint_state_interface_[index].clear();
  }

  // order all joints in the storage
  for (const auto & interface : params_.command_interfaces)
  {
    auto it =
      std::find(allowed_interface_types_.begin(), allowed_interface_types_.end(), interface);
    auto index = static_cast<size_t>(std::distance(allowed_interface_types_.begin(), it));
    if (!controller_interface::get_ordered_interfaces(
          command_interfaces_, command_joint_names_, interface, joint_command_interface_[index]))
    {
      RCLCPP_ERROR(
        logger, "Expected %zu '%s' command interfaces, got %zu.", num_cmd_joints_,
        interface.c_str(), joint_command_interface_[index].size());
      return CallbackReturn::ERROR;
    }
  }
  for (const auto & interface : params_.state_interfaces)
  {
    auto it =
      std::find(allowed_interface_types_.begin(), allowed_interface_types_.end(), interface);
    auto index = static_cast<size_t>(std::distance(allowed_interface_types_.begin(), it));
    if (!controller_interface::get_ordered_interfaces(
          state_interfaces_, params_.joints, interface, joint_state_interface_[index]))
    {
      RCLCPP_ERROR(
        logger, "Expected %zu '%s' state interfaces, got %zu.", dof_, interface.c_str(),
        joint_state_interface_[index].size());
      return CallbackReturn::ERROR;
    }
  }

  current_trajectory_ = std::make_unique<Trajectory>();
  rt_new_trajectory_msg_.set([](auto & msg) { msg.reset(); });

  subscriber_is_active_ = true;

  // Initialize current state storage from hardware state interfaces
  read_state_from_state_interfaces(state_current_);
  read_state_from_state_interfaces(last_commanded_state_);

  if (params_.set_last_command_interface_value_as_state_on_activation && dof_ == num_cmd_joints_)
  {
    // Handle restart of controller by reading from commands if those are not NaN (a controller was
    // running already)
    // The function checks if all joints have values on the command interfaces.
    // otherwise it will not update them, leaving them based on the state interfaces.
    update_state_from_command_interfaces(state_current_);
    update_state_from_command_interfaces(last_commanded_state_);
  }
  rt_last_commanded_state_.set(last_commanded_state_);

  // reset/zero out all of the PID's (The integral term is not retained and reset to zero)
  for (auto & pid : pids_)
  {
    pid->reset();
  }
  last_commanded_time_ = rclcpp::Time();

  // The controller should start by holding position at the beginning of active state
  add_new_trajectory_msg(set_hold_position());
  rt_is_holding_ = true;

  // parse timeout parameter
  if (params_.cmd_timeout > 0.0)
  {
    if (params_.cmd_timeout > default_tolerances_.goal_time_tolerance)
    {
      cmd_timeout_ = params_.cmd_timeout;
    }
    else
    {
      // deactivate timeout
      RCLCPP_WARN(
        logger, "Command timeout must be higher than goal_time tolerance (%f vs. %f)",
        params_.cmd_timeout, default_tolerances_.goal_time_tolerance);
      cmd_timeout_ = 0.0;
    }
  }
  else
  {
    cmd_timeout_ = 0.0;
  }

  return CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn JointTrajectoryController::on_deactivate(
  const rclcpp_lifecycle::State &)
{
  auto logger = get_node()->get_logger();
  RealtimeGoalHandlePtr active_goal;
  rt_active_goal_.get([&](const auto goal) { active_goal = goal; });
  if (active_goal)
  {
    rt_has_pending_goal_ = false;
    auto action_res = std::make_shared<FollowJTrajAction::Result>();
    action_res->set__error_code(FollowJTrajAction::Result::INVALID_GOAL);
    action_res->set__error_string("Current goal cancelled during deactivate transition.");
    active_goal->setAborted(action_res);
    rt_active_goal_.try_set([](auto & goal) { goal = RealtimeGoalHandlePtr(); });
  }

  for (size_t index = 0; index < num_cmd_joints_; ++index)
  {
    if (has_position_command_interface_)
    {
      const auto joint_position_value_op = joint_command_interface_[0][index].get().get_optional();
      if (!joint_position_value_op.has_value())
      {
        RCLCPP_WARN(logger, "Unable to retrieve joint position value");
        return controller_interface::CallbackReturn::SUCCESS;
      }
      if (!joint_command_interface_[0][index].get().set_value(joint_position_value_op.value()))
      {
        RCLCPP_WARN(
          logger, "Unable to set the joint position to value: %f", joint_position_value_op.value());
        return controller_interface::CallbackReturn::SUCCESS;
      }
    }

    if (has_velocity_command_interface_ && !joint_command_interface_[1][index].get().set_value(0.0))
    {
      RCLCPP_WARN(logger, "Error while setting joint velocity to value 0.0");
      return controller_interface::CallbackReturn::SUCCESS;
    }

    if (
      has_acceleration_command_interface_ &&
      !joint_command_interface_[2][index].get().set_value(0.0))
    {
      RCLCPP_WARN(logger, "Error while setting joint acceleration to value 0.0");
      return controller_interface::CallbackReturn::SUCCESS;
    }

    // TODO(anyone): How to halt when using effort commands?
    if (has_effort_command_interface_ && !joint_command_interface_[3][index].get().set_value(0.0))
    {
      RCLCPP_WARN(logger, "Error while setting joint effort to value 0.0");
      return controller_interface::CallbackReturn::SUCCESS;
    }
  }

  for (size_t index = 0; index < allowed_interface_types_.size(); ++index)
  {
    joint_command_interface_[index].clear();
    joint_state_interface_[index].clear();
  }

  subscriber_is_active_ = false;

  current_trajectory_.reset();

  return CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn JointTrajectoryController::on_error(
  const rclcpp_lifecycle::State &)
{
  if (!reset())
  {
    return CallbackReturn::ERROR;
  }
  return CallbackReturn::SUCCESS;
}

bool JointTrajectoryController::reset()
{
  subscriber_is_active_ = false;
  joint_command_subscriber_.reset();

  for (const auto & pid : pids_)
  {
    if (pid)
    {
      pid->reset();
    }
  }

  current_trajectory_.reset();

  return true;
}

void JointTrajectoryController::publish_state(
  const rclcpp::Time & time, const JointTrajectoryPoint & desired_state,
  const JointTrajectoryPoint & current_state, const JointTrajectoryPoint & state_error)
{
  if (state_publisher_)
  {
    state_msg_.header.stamp = time;
    state_msg_.reference.time_from_start = desired_state.time_from_start;
    state_msg_.reference.positions = desired_state.positions;
    state_msg_.reference.velocities = desired_state.velocities;
    state_msg_.reference.accelerations = desired_state.accelerations;
    state_msg_.feedback.time_from_start = current_state.time_from_start;
    state_msg_.feedback.positions = current_state.positions;
    state_msg_.error.positions = state_error.positions;
    if (has_velocity_state_interface_)
    {
      state_msg_.feedback.velocities = current_state.velocities;
      state_msg_.error.velocities = state_error.velocities;
    }
    if (has_acceleration_state_interface_)
    {
      state_msg_.feedback.accelerations = current_state.accelerations;
      state_msg_.error.accelerations = state_error.accelerations;
    }
    if (read_commands_from_command_interfaces(command_current_))
    {
      state_msg_.output = command_current_;
    }
    state_msg_.speed_scaling_factor = scaling_factor_;

    state_publisher_->try_publish(state_msg_);
  }
}

void JointTrajectoryController::preprocess_incoming_trajectory(
  trajectory_msgs::msg::JointTrajectory & msg) const
{
  if (!params_.positions_upsampling.enable)
  {
    return;
  }
  // 'none' sampling forwards raw waypoints, so synthesized velocities would be ignored
  if (interpolation_method_ == interpolation_methods::InterpolationMethod::NONE)
  {
    return;
  }
  if (!is_positions_only(msg))
  {
    return;
  }
  synthesize_timing(msg);
  // with nothing to anchor on start_velocity stays empty, which is the rest boundary
  std::vector<double> start_velocity;
  prepend_commanded_state(msg, start_velocity);
  fill_cubic_spline_velocities(msg, start_velocity);
}

bool JointTrajectoryController::prepend_commanded_state(
  trajectory_msgs::msg::JointTrajectory & traj, std::vector<double> & start_velocity) const
{
  start_velocity.clear();
  // only a zero stamp puts the trajectory's t=0 at "now", where the commanded state belongs
  if (traj.header.stamp.sec != 0 || traj.header.stamp.nanosec != 0u)
  {
    return false;
  }
  // the anchor needs room ahead of the first waypoint
  if (
    traj.points.empty() ||
    rclcpp::Duration(traj.points.front().time_from_start) <= rclcpp::Duration(0, 0))
  {
    return false;
  }
  const auto commanded = rt_last_commanded_state_.get();
  if (commanded.positions.size() != dof_ || commanded.velocities.size() != dof_)
  {
    return false;
  }
  // not sorted into the controller's joint order until install, so index by the sender's order
  const auto joint_map = mapping(traj.joint_names, params_.joints);
  if (joint_map.size() != traj.joint_names.size())
  {
    return false;
  }
  trajectory_msgs::msg::JointTrajectoryPoint anchor;
  anchor.positions.resize(joint_map.size());
  std::vector<double> anchor_velocities(joint_map.size());
  for (size_t i = 0; i < joint_map.size(); ++i)
  {
    // NaN before the first update(), and while the hardware exposes no velocity state
    if (
      !std::isfinite(commanded.positions[joint_map[i]]) ||
      !std::isfinite(commanded.velocities[joint_map[i]]))
    {
      return false;
    }
    anchor.positions[i] = commanded.positions[joint_map[i]];
    anchor_velocities[i] = commanded.velocities[joint_map[i]];
  }
  anchor.time_from_start = rclcpp::Duration(0, 0);
  traj.points.insert(traj.points.begin(), std::move(anchor));
  start_velocity = std::move(anchor_velocities);
  return true;
}

bool JointTrajectoryController::is_positions_only(
  const trajectory_msgs::msg::JointTrajectory & traj) const
{
  if (traj.points.empty())
  {
    return false;
  }
  for (const auto & point : traj.points)
  {
    if (point.positions.empty())
    {
      return false;
    }
    if (!point.velocities.empty() || !point.accelerations.empty())
    {
      return false;
    }
  }
  return true;
}

void JointTrajectoryController::synthesize_timing(
  trajectory_msgs::msg::JointTrajectory & traj) const
{
  const double policy_frequency = params_.positions_upsampling.policy_frequency;
  if (policy_frequency <= 0.0)
  {
    return;  // no rate configured: chunks must carry their own timing
  }
  // leave already-timed chunks untouched
  for (const auto & point : traj.points)
  {
    const auto & t = point.time_from_start;
    if (t.sec != 0 || t.nanosec != 0u)
    {
      return;
    }
  }

  // first target lands at dt, not 0, leaving [start, dt) for the lead-in instead of a step
  const double dt = 1.0 / policy_frequency;
  for (size_t i = 0; i < traj.points.size(); ++i)
  {
    traj.points[i].time_from_start =
      rclcpp::Duration::from_seconds(static_cast<double>(i + 1) * dt);
  }
}

void JointTrajectoryController::topic_callback(
  const std::shared_ptr<trajectory_msgs::msg::JointTrajectory> msg)
{
  preprocess_incoming_trajectory(*msg);

  if (!validate_trajectory_msg(*msg))
  {
    return;
  }
  // http://wiki.ros.org/joint_trajectory_controller/UnderstandingTrajectoryReplacement
  // always replace old msg with new one for now
  if (subscriber_is_active_)
  {
    add_new_trajectory_msg(msg);
    rt_is_holding_ = false;
  }
}

rclcpp_action::GoalResponse JointTrajectoryController::goal_received_callback(
  const rclcpp_action::GoalUUID &, std::shared_ptr<const FollowJTrajAction::Goal> goal)
{
  RCLCPP_INFO(get_node()->get_logger(), "Received new action goal");

  // Precondition: Running controller
  if (get_lifecycle_id() == lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE)
  {
    RCLCPP_ERROR(
      get_node()->get_logger(), "Can't accept new action goals. Controller is not running.");
    return rclcpp_action::GoalResponse::REJECT;
  }

  if (!validate_trajectory_msg(goal->trajectory))
  {
    return rclcpp_action::GoalResponse::REJECT;
  }

  if (params_.positions_upsampling.enable && is_positions_only(goal->trajectory))
  {
    RCLCPP_WARN_ONCE(
      get_node()->get_logger(),
      "positions_upsampling upsamples the ~/joint_trajectory topic only, not action goals.");
  }

  RCLCPP_INFO(get_node()->get_logger(), "Accepted new action goal");
  return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
}

rclcpp_action::CancelResponse JointTrajectoryController::goal_cancelled_callback(
  const std::shared_ptr<rclcpp_action::ServerGoalHandle<FollowJTrajAction>> goal_handle)
{
  RCLCPP_INFO(get_node()->get_logger(), "Got request to cancel goal");

  // Check that cancel request refers to currently active goal (if any)
  RealtimeGoalHandlePtr active_goal;
  rt_active_goal_.get([&](const auto goal) { active_goal = goal; });
  if (active_goal && active_goal->gh_ == goal_handle)
  {
    RCLCPP_INFO(
      get_node()->get_logger(), "Canceling active action goal because cancel callback received.");

    // Mark the current goal as canceled
    rt_has_pending_goal_ = false;
    auto action_res = std::make_shared<FollowJTrajAction::Result>();
    active_goal->setCanceled(action_res);
    rt_active_goal_.set([](auto & goal) { goal = RealtimeGoalHandlePtr(); });

    if (should_decelerate_on_cancel_)
    {
      // calculate stopping position based on max deceleration
      add_new_trajectory_msg(decelerate_to_hold_position());
    }
    else
    {
      // hold current position
      add_new_trajectory_msg(set_hold_position());
    }
  }
  return rclcpp_action::CancelResponse::ACCEPT;
}

void JointTrajectoryController::goal_accepted_callback(
  std::shared_ptr<rclcpp_action::ServerGoalHandle<FollowJTrajAction>> goal_handle)
{
  // mark a pending goal
  rt_has_pending_goal_ = true;

  // Update new trajectory
  {
    preempt_active_goal();
    auto traj_msg =
      std::make_shared<trajectory_msgs::msg::JointTrajectory>(goal_handle->get_goal()->trajectory);

    add_new_trajectory_msg(traj_msg);
    rt_is_holding_ = false;
  }

  // Update the active goal
  auto feedback = std::make_shared<FollowJTrajAction::Feedback>();
  feedback->joint_names = params_.joints;
  resize_joint_trajectory_point(feedback->actual, dof_);
  resize_joint_trajectory_point(feedback->desired, dof_);
  resize_joint_trajectory_point(feedback->error, dof_);
  RealtimeGoalHandlePtr rt_goal =
    std::make_shared<RealtimeGoalHandle>(goal_handle, nullptr, feedback);
  rt_goal->execute();
  rt_active_goal_.set([&](auto & goal) { goal = rt_goal; });

  // Update tolerances if specified in the goal
  auto logger = this->get_node()->get_logger();
  rt_goal_tolerances_.set(get_segment_tolerances(
    logger, default_tolerances_, *(goal_handle->get_goal()), params_.joints));

  // Set smartpointer to expire for create_wall_timer to delete previous entry from timer list
  goal_handle_timer_.reset();

  // Setup goal status checking timer
  goal_handle_timer_ = get_node()->create_wall_timer(
    goal_handle_timer_period_.to_chrono<std::chrono::nanoseconds>(),
    std::bind(&RealtimeGoalHandle::runNonRealtime, rt_goal));
}

void JointTrajectoryController::compute_error_for_joint(
  JointTrajectoryPoint & error, const size_t index, const JointTrajectoryPoint & current,
  const JointTrajectoryPoint & desired) const
{
  // error defined as the difference between current and desired
  if (joints_angle_wraparound_[index])
  {
    // if desired, the shortest_angular_distance is calculated, i.e., the error is
    //  normalized between -pi<error<pi
    error.positions[index] =
      angles::shortest_angular_distance(current.positions[index], desired.positions[index]);
  }
  else
  {
    error.positions[index] = desired.positions[index] - current.positions[index];
  }
  if (
    has_velocity_state_interface_ &&
    (has_velocity_command_interface_ || has_effort_command_interface_))
  {
    error.velocities[index] = desired.velocities[index] - current.velocities[index];
  }
  if (has_acceleration_state_interface_ && has_acceleration_command_interface_)
  {
    error.accelerations[index] = desired.accelerations[index] - current.accelerations[index];
  }
}

void JointTrajectoryController::fill_partial_goal(
  std::shared_ptr<trajectory_msgs::msg::JointTrajectory> trajectory_msg) const
{
  // joint names in the goal are a subset of existing joints, as checked in goal_callback
  // so if the size matches, the goal contains all controller joints
  if (dof_ == trajectory_msg->joint_names.size())
  {
    return;
  }

  trajectory_msg->joint_names.reserve(dof_);

  for (size_t index = 0; index < dof_; ++index)
  {
    {
      if (
        std::find(
          trajectory_msg->joint_names.begin(), trajectory_msg->joint_names.end(),
          params_.joints[index]) != trajectory_msg->joint_names.end())
      {
        // joint found on msg
        continue;
      }
      trajectory_msg->joint_names.push_back(params_.joints[index]);

      for (auto & it : trajectory_msg->points)
      {
        // Assume hold position with 0 velocity and acceleration for missing joints
        if (!it.positions.empty())
        {
          if (has_position_command_interface_)
          {
            const auto position_command_value_op =
              joint_command_interface_[0][index].get().get_optional();

            if (!position_command_value_op.has_value())
            {
              RCLCPP_DEBUG(
                get_node()->get_logger(),
                "Unable to retrieve position command value of joint at index %zu", index);
            }
            else if (!std::isnan(position_command_value_op.value()))
            {
              it.positions.push_back(position_command_value_op.value());
            }
          }

          else if (has_position_state_interface_)
          {
            // copy current state if state interface exists
            const auto position_state_value_op =
              joint_state_interface_[0][index].get().get_optional();
            if (!position_state_value_op.has_value())
            {
              RCLCPP_DEBUG(
                get_node()->get_logger(),
                "Unable to retrieve position state value of joint at index %zu", index);
            }
            else if (!std::isnan(position_state_value_op.value()))
            {
              it.positions.push_back(position_state_value_op.value());
            }
          }
        }
        if (!it.velocities.empty())
        {
          it.velocities.push_back(0.0);
        }
        if (!it.accelerations.empty())
        {
          it.accelerations.push_back(0.0);
        }
        if (!it.effort.empty())
        {
          it.effort.push_back(0.0);
        }
      }
    }
  }
}

void JointTrajectoryController::fill_omitted_joints_from_old(
  const std::shared_ptr<trajectory_msgs::msg::JointTrajectory> & trajectory_msg,
  const rclcpp::Time & new_start)
{
  if (dof_ == trajectory_msg->joint_names.size() || !has_active_trajectory())
  {
    return;
  }

  trajectory_msg->joint_names.reserve(dof_);
  for (size_t index = 0; index < dof_; ++index)
  {
    if (!blend_commanded_[index])
    {
      trajectory_msg->joint_names.push_back(params_.joints[index]);
    }
  }

  TrajectoryPointConstIter start_segment_itr, end_segment_itr;
  for (auto & point : trajectory_msg->points)
  {
    // points are time-ordered, so let the search advance incrementally instead of rescanning
    const bool sampled = current_trajectory_->sample(
      new_start + rclcpp::Duration(point.time_from_start), interpolation_method_, blend_sample_,
      start_segment_itr, end_segment_itr, true);

    for (size_t index = 0; index < dof_; ++index)
    {
      if (blend_commanded_[index])
      {
        continue;
      }
      if (!point.positions.empty())
      {
        // every joint must contribute exactly one value, the suffix below indexes these by joint
        double position = state_current_.positions[index];
        if (sampled && index < blend_sample_.positions.size())
        {
          position = blend_sample_.positions[index];
        }
        // the old trajectory could not be sampled, so hold the joint
        else if (has_position_command_interface_)
        {
          const auto position_command_value_op =
            joint_command_interface_[0][index].get().get_optional();
          if (
            position_command_value_op.has_value() && !std::isnan(position_command_value_op.value()))
          {
            position = position_command_value_op.value();
          }
        }
        else if (has_position_state_interface_)
        {
          const auto position_state_value_op =
            joint_state_interface_[0][index].get().get_optional();
          if (position_state_value_op.has_value() && !std::isnan(position_state_value_op.value()))
          {
            position = position_state_value_op.value();
          }
        }
        point.positions.push_back(position);
      }
      if (!point.velocities.empty())
      {
        point.velocities.push_back(
          (sampled && index < blend_sample_.velocities.size()) ? blend_sample_.velocities[index]
                                                               : 0.0);
      }
      if (!point.accelerations.empty())
      {
        point.accelerations.push_back(
          (sampled && index < blend_sample_.accelerations.size())
            ? blend_sample_.accelerations[index]
            : 0.0);
      }
      if (!point.effort.empty())
      {
        point.effort.push_back(0.0);
      }
    }
  }
}

bool JointTrajectoryController::blend_with_active_trajectory(
  const std::shared_ptr<trajectory_msgs::msg::JointTrajectory> & trajectory_msg,
  const rclcpp::Time & time)
{
  const auto old_msg = current_trajectory_->get_trajectory_msg();
  const rclcpp::Time old_start = current_trajectory_->time_from_start();
  // playback position in the old trajectory's time base. It precedes old_start while a
  // future-stamped trajectory is still ramping in, so it must not be clamped to it.
  const rclcpp::Time cursor = traj_time_;

  const rclcpp::Time stamp(trajectory_msg->header.stamp, time.get_clock_type());

  bool has_omitted = false;
  for (size_t j = 0; j < dof_; ++j)
  {
    blend_commanded_[j] = std::find(
                            trajectory_msg->joint_names.begin(), trajectory_msg->joint_names.end(),
                            params_.joints[j]) != trajectory_msg->joint_names.end();
    has_omitted = has_omitted || !blend_commanded_[j];
  }

  // the suffix must hold commanded joints at a position, which a velocity-only goal lacks
  if (has_omitted && trajectory_msg->points.back().positions.empty())
  {
    return false;
  }

  const rclcpp::Time new_start =
    (stamp > time) ? cursor + (stamp - time) * scaling_factor_.load() : cursor;

  // sample the bridge anchor before the sweep below advances the trajectory's search cursor
  TrajectoryPointConstIter start_segment_itr, end_segment_itr;
  const bool have_bridge = current_trajectory_->sample(
    new_start, interpolation_method_, blend_bridge_, start_segment_itr, end_segment_itr, false);

  fill_omitted_joints_from_old(trajectory_msg, new_start);
  sort_to_local_joint_order(trajectory_msg);
  const auto new_last = trajectory_msg->points.back();
  const rclcpp::Time new_end =
    new_start + rclcpp::Duration(trajectory_msg->points.back().time_from_start);
  for (auto & point : trajectory_msg->points)
  {
    point.time_from_start = new_start + rclcpp::Duration(point.time_from_start) - old_start;
  }

  // prefix: old waypoints in (cursor, new_start)
  std::vector<JointTrajectoryPoint> prefix;
  for (const auto & op : old_msg->points)
  {
    const rclcpp::Time t = old_start + rclcpp::Duration(op.time_from_start);
    if (t > cursor && t < new_start)
    {
      prefix.push_back(op);
    }
  }
  // bridge anchor: velocity-continuous entry into the new trajectory
  if (have_bridge)
  {
    blend_bridge_.time_from_start = new_start - old_start;
    // drop if not strictly before first new point (would break monotonic time)
    if (
      trajectory_msg->points.empty() ||
      rclcpp::Duration(blend_bridge_.time_from_start) <
        rclcpp::Duration(trajectory_msg->points.front().time_from_start))
    {
      prefix.push_back(blend_bridge_);
    }
  }

  // suffix: old waypoints after new_end; commanded joints held at new_last
  std::vector<JointTrajectoryPoint> suffix;
  if (has_omitted)
  {
    for (const auto & op : old_msg->points)
    {
      const rclcpp::Time t = old_start + rclcpp::Duration(op.time_from_start);
      if (t > new_end)
      {
        auto p = op;
        for (size_t j = 0; j < dof_; ++j)
        {
          if (blend_commanded_[j])
          {
            if (!p.positions.empty()) p.positions[j] = new_last.positions[j];
            if (!p.velocities.empty()) p.velocities[j] = 0.0;
            if (!p.accelerations.empty()) p.accelerations[j] = 0.0;
          }
        }
        suffix.push_back(p);
      }
    }
  }

  trajectory_msg->points.insert(trajectory_msg->points.begin(), prefix.begin(), prefix.end());
  trajectory_msg->points.insert(trajectory_msg->points.end(), suffix.begin(), suffix.end());
  trajectory_msg->joint_names = params_.joints;
  blend_prefix_size_ = prefix.size();  // action feedback index offset

  // Re-anchor at the cursor so the first sample lands at the current state.
  // Anchoring at old_start would jump forward under speed scaling on install.
  const rclcpp::Duration cursor_offset = cursor - old_start;
  for (auto & point : trajectory_msg->points)
  {
    point.time_from_start = rclcpp::Duration(point.time_from_start) - cursor_offset;
  }
  trajectory_msg->header.stamp = rclcpp::Time(0, 0, time.get_clock_type());
  return true;
}

void JointTrajectoryController::sort_to_local_joint_order(
  std::shared_ptr<trajectory_msgs::msg::JointTrajectory> trajectory_msg) const
{
  // rearrange all points in the trajectory message based on mapping
  std::vector<size_t> mapping_vector = mapping(trajectory_msg->joint_names, params_.joints);
  auto remap = [this, &mapping_vector](std::vector<double> & to_remap)
  {
    if (to_remap.empty())
    {
      return;
    }
    if (to_remap.size() != mapping_vector.size())
    {
      RCLCPP_WARN(
        get_node()->get_logger(), "Invalid input size (%zu) for sorting", to_remap.size());
      return;
    }
    // Don't make this static: it would be shared across all controller instances
    std::vector<double> output(to_remap.size());
    for (size_t index = 0; index < mapping_vector.size(); ++index)
    {
      output[mapping_vector[index]] = to_remap[index];
    }
    to_remap = std::move(output);
  };

  for (auto & point : trajectory_msg->points)
  {
    remap(point.positions);
    remap(point.velocities);
    remap(point.accelerations);
    remap(point.effort);
  }
}

bool JointTrajectoryController::validate_trajectory_point_field(
  size_t joint_names_size, const std::vector<double> & vector_field,
  const std::string & string_for_vector_field, size_t i, bool allow_empty) const
{
  if (allow_empty && vector_field.empty())
  {
    return true;
  }
  if (joint_names_size != vector_field.size())
  {
    RCLCPP_ERROR(
      get_node()->get_logger(),
      "Mismatch between joint_names size (%zu) and %s (%zu) at point #%zu.", joint_names_size,
      string_for_vector_field.c_str(), vector_field.size(), i);
    return false;
  }
  return true;
}

bool JointTrajectoryController::validate_trajectory_msg(
  const trajectory_msgs::msg::JointTrajectory & trajectory) const
{
  // CHECK: Partial joint goals
  // If partial joints goals are not allowed, goal should specify all controller joints
  if (!params_.allow_partial_joints_goal)
  {
    if (trajectory.joint_names.size() != dof_)
    {
      RCLCPP_ERROR(
        get_node()->get_logger(),
        "Joints on incoming trajectory don't match the controller joints.");
      return false;
    }
  }

  // CHECK: if joint names are provided
  if (trajectory.joint_names.empty())
  {
    RCLCPP_ERROR(get_node()->get_logger(), "Empty joint names on incoming trajectory.");
    return false;
  }

  // CHECK: if provided trajectory has points
  if (trajectory.points.empty())
  {
    RCLCPP_ERROR(get_node()->get_logger(), "Empty trajectory received.");
    return false;
  }

  // CHECK: If joint names are matching the joints defined for the controller
  for (size_t i = 0; i < trajectory.joint_names.size(); ++i)
  {
    const std::string & incoming_joint_name = trajectory.joint_names[i];

    auto it = std::find(params_.joints.begin(), params_.joints.end(), incoming_joint_name);
    if (it == params_.joints.end())
    {
      RCLCPP_ERROR(
        get_node()->get_logger(), "Incoming joint %s doesn't match the controller's joints.",
        incoming_joint_name.c_str());
      return false;
    }
  }

  // CHECK: if trajectory ends with non-zero velocity (when option is disabled)
  if (!params_.allow_nonzero_velocity_at_trajectory_end)
  {
    for (size_t i = 0; i < trajectory.points.back().velocities.size(); ++i)
    {
      if (fabs(trajectory.points.back().velocities.at(i)) > std::numeric_limits<float>::epsilon())
      {
        RCLCPP_ERROR(
          get_node()->get_logger(),
          "Velocity of last trajectory point of joint %s is not zero: %.15f",
          trajectory.joint_names.at(i).c_str(), trajectory.points.back().velocities.at(i));
        return false;
      }
    }
  }

  // CHECK: if trajectory end time is in the past (if start time defined)
  const rclcpp::Time trajectory_start_time = trajectory.header.stamp;
  // If the starting time it set to 0.0, it means the controller should start it now.
  // Otherwise we check if the trajectory ends before the current time,
  // in which case it can be ignored.
  if (trajectory_start_time.seconds() != 0.0)
  {
    auto const trajectory_end_time =
      trajectory_start_time + trajectory.points.back().time_from_start;
    if (trajectory_end_time < get_node()->now())
    {
      RCLCPP_ERROR(
        get_node()->get_logger(),
        "Received trajectory with non-zero start time (%f) that ends in the past (%f)",
        trajectory_start_time.seconds(), trajectory_end_time.seconds());
      return false;
    }
  }

  rclcpp::Duration previous_traj_time(0ms);
  for (size_t i = 0; i < trajectory.points.size(); ++i)
  {
    // CHECK: if time of points in the trajectory is monotonous
    if ((i > 0) && (rclcpp::Duration(trajectory.points[i].time_from_start) <= previous_traj_time))
    {
      RCLCPP_ERROR(
        get_node()->get_logger(),
        "Time between points %zu and %zu is not strictly increasing, it is %f and %f respectively",
        i - 1, i, previous_traj_time.seconds(),
        rclcpp::Duration(trajectory.points[i].time_from_start).seconds());
      return false;
    }
    previous_traj_time = trajectory.points[i].time_from_start;

    const size_t joint_count = trajectory.joint_names.size();
    const auto & points = trajectory.points;

    // CHECK: if all required data are provided in the trajectory
    // This currently supports only position, velocity and acceleration inputs
    if (params_.allow_integration_in_goal_trajectories)
    {
      if (
        points[i].positions.empty() && points[i].velocities.empty() &&
        points[i].accelerations.empty())
      {
        RCLCPP_ERROR(
          get_node()->get_logger(),
          "The given trajectory has no position, velocity, or acceleration points.");
        return false;
      }
      const bool position_error =
        !points[i].positions.empty() &&
        !validate_trajectory_point_field(joint_count, points[i].positions, "positions", i, false);
      const bool velocity_error =
        !points[i].velocities.empty() &&
        !validate_trajectory_point_field(joint_count, points[i].velocities, "velocities", i, false);
      const bool acceleration_error =
        !points[i].accelerations.empty() &&
        !validate_trajectory_point_field(
          joint_count, points[i].accelerations, "accelerations", i, false);
      if (position_error || velocity_error || acceleration_error)
      {
        return false;
      }
    }
    else if (
      !validate_trajectory_point_field(joint_count, points[i].positions, "positions", i, false) ||
      !validate_trajectory_point_field(joint_count, points[i].velocities, "velocities", i, true) ||
      !validate_trajectory_point_field(
        joint_count, points[i].accelerations, "accelerations", i, true))
    {
      return false;
    }
    // reject effort entries
    if (!has_effort_command_interface_ && !points[i].effort.empty())
    {
      RCLCPP_ERROR(
        get_node()->get_logger(),
        "Trajectories with effort fields are only supported for "
        "controllers using the 'effort' command interface.");
      return false;
    }
  }
  return true;
}

void JointTrajectoryController::add_new_trajectory_msg(
  const std::shared_ptr<trajectory_msgs::msg::JointTrajectory> & traj_msg)
{
  rt_new_trajectory_msg_.set([traj_msg](auto & msg) { msg = traj_msg; });
}

void JointTrajectoryController::preempt_active_goal()
{
  RealtimeGoalHandlePtr active_goal;
  rt_active_goal_.get([&](const auto goal) { active_goal = goal; });
  if (active_goal)
  {
    auto action_res = std::make_shared<FollowJTrajAction::Result>();
    action_res->set__error_code(FollowJTrajAction::Result::INVALID_GOAL);
    action_res->set__error_string("Current goal preempted by new incoming action.");
    active_goal->setAborted(action_res);
    // Deliver result now; the old goal_handle_timer_ is destroyed after this returns.
    active_goal->runNonRealtime();
    rt_active_goal_.set([](auto & goal) { goal = RealtimeGoalHandlePtr(); });
  }
}

std::shared_ptr<trajectory_msgs::msg::JointTrajectory>
JointTrajectoryController::set_hold_position()
{
  // Command to stay at current position
  hold_position_msg_ptr_->points[0].positions = state_current_.positions;

  // set flag, otherwise tolerances will be checked with holding position too
  rt_is_holding_ = true;

  return hold_position_msg_ptr_;
}

std::shared_ptr<trajectory_msgs::msg::JointTrajectory>
JointTrajectoryController::decelerate_to_hold_position()
{
  double max_t_stop = 0.0;
  const auto & p0 = state_current_.positions;
  const auto & v0 = state_current_.velocities;
  for (size_t i = 0; i < num_cmd_joints_; ++i)
  {
    stop_direction_[i] = (v0[i] >= 0.0) ? 1.0 : -1.0;

    // Time to stop (constant decel)
    stop_time_[i] = std::abs(v0[i]) / max_decel_[i];
    max_t_stop = std::max(max_t_stop, stop_time_[i]);

    // Analytical stop distance and hold position
    const double stop_distance = (v0[i] * v0[i]) / (2.0 * max_decel_[i]);
    hold_position_[i] = p0[i] + stop_direction_[i] * stop_distance;

    RCLCPP_DEBUG(
      get_node()->get_logger(),
      "Joint [%s] decel [%.3f], stop dist [%.4f], initial vel [%.4f], initial pos [%.4f], hold pos "
      "[%.4f], time to stop [%.4f]",
      params_.joints[i].c_str(), max_decel_[i], stop_distance, v0[i], p0[i], hold_position_[i],
      stop_time_[i]);
  }

  // Verify the stop_trajectory_ has enough space to stop the robot from it's current state
  const size_t num_points =
    static_cast<size_t>(std::ceil(max_t_stop / update_period_.seconds())) + 1;
  // check the reserved stop trajectory has enough space to stop the joints
  if (stop_trajectory_->points.size() < num_points)
  {
    RCLCPP_WARN(
      get_node()->get_logger(),
      "Trajectory to stop on cancel exceeds max reserved trajectory size of [%ld], requires "
      "[%ld]. Resizing trajectory to stop joints. Please check URDF velocity limits are "
      "greater than requested trajectories to execute!",
      stop_trajectory_->points.size(), num_points);
    trajectory_msgs::msg::JointTrajectoryPoint pt;
    pt.positions.resize(params_.joints.size(), 0.0);
    pt.velocities.resize(params_.joints.size(), 0.0);
    pt.accelerations.resize(params_.joints.size(), 0.0);
    stop_trajectory_->points.resize(num_points, pt);
  }

  // Build traj points that ramp to zero velocity
  for (size_t k = 0; k < stop_trajectory_->points.size(); ++k)
  {
    const double t = static_cast<double>(k) * update_period_.seconds();
    auto & pt = stop_trajectory_->points[k];
    for (size_t i = 0; i < num_cmd_joints_; ++i)
    {
      // if the joint still needs more time to stop and had an initial non-zero velocity
      if (t < stop_time_[i] && std::abs(v0[i]) > std::numeric_limits<float>::epsilon())
      {
        // Constant deceleration
        // v(t) = v0 - stop_direction_ * a * t
        double v = v0[i] - stop_direction_[i] * max_decel_[i] * t;
        // Guard against numerical crossing
        if ((v * stop_direction_[i]) < 0.0) v = 0.0;
        // p(t) = p0 + v0 * t - 0.5 * stop_direction_ * a * t^2
        const double p = p0[i] + v0[i] * t - 0.5 * stop_direction_[i] * max_decel_[i] * t * t;
        pt.positions[i] = p;
        pt.velocities[i] = v;
        pt.accelerations[i] = -stop_direction_[i] * max_decel_[i];
      }
      else
      {
        // Joint is stopped, hold position and zero velocity/accel
        pt.positions[i] = hold_position_[i];
        pt.velocities[i] = 0.0;
        pt.accelerations[i] = 0.0;
      }
    }

    pt.time_from_start = rclcpp::Duration::from_seconds(t);
  }

  RCLCPP_DEBUG(
    get_node()->get_logger(), "Created ramped stop trajectory with max time to stop [%.3f] sec",
    max_t_stop);

  // set flag, otherwise tolerances will be checked with holding position too
  rt_is_holding_ = true;

  return stop_trajectory_;
}

std::shared_ptr<trajectory_msgs::msg::JointTrajectory>
JointTrajectoryController::set_success_trajectory_point()
{
  // set last command to be repeated at success, no matter if it has nonzero velocity or
  // acceleration
  hold_position_msg_ptr_->points[0] = current_trajectory_->get_trajectory_msg()->points.back();
  hold_position_msg_ptr_->points[0].time_from_start = rclcpp::Duration(0, 0);

  // set flag, otherwise tolerances will be checked with success_trajectory_point too
  rt_is_holding_ = true;

  return hold_position_msg_ptr_;
}

bool JointTrajectoryController::contains_interface_type(
  const std::vector<std::string> & interface_type_list, const std::string & interface_type)
{
  return std::find(interface_type_list.begin(), interface_type_list.end(), interface_type) !=
         interface_type_list.end();
}

void JointTrajectoryController::resize_joint_trajectory_point(
  trajectory_msgs::msg::JointTrajectoryPoint & point, size_t size, double value)
{
  point.positions.resize(size, value);
  if (has_velocity_state_interface_)
  {
    point.velocities.resize(size, value);
  }
  if (has_acceleration_state_interface_)
  {
    point.accelerations.resize(size, value);
  }
  point.effort.resize(size, 0.0);
}

void JointTrajectoryController::resize_joint_trajectory_point_command(
  trajectory_msgs::msg::JointTrajectoryPoint & point, size_t size, double value)
{
  if (has_position_command_interface_)
  {
    point.positions.resize(size, value);
  }
  if (has_velocity_command_interface_)
  {
    point.velocities.resize(size, value);
  }
  if (has_acceleration_command_interface_)
  {
    point.accelerations.resize(size, value);
  }
  if (has_effort_command_interface_)
  {
    point.effort.resize(size, value);
  }
}

bool JointTrajectoryController::set_scaling_factor(double scaling_factor)
{
  if (scaling_factor < 0)
  {
    RCLCPP_WARN(
      get_node()->get_logger(),
      "Scaling factor has to be greater or equal to 0.0 - Ignoring input!");
    return false;
  }

  if (scaling_factor != scaling_factor_.load())
  {
    RCLCPP_INFO(
      get_node()->get_logger().get_child("speed_scaling"), "New scaling factor will be %f",
      scaling_factor);
  }
  scaling_factor_.store(scaling_factor);
  if (
    params_.speed_scaling.command_interface.empty() &&
    !params_.speed_scaling.state_interface.empty())
  {
    RCLCPP_WARN_ONCE(
      get_node()->get_logger(),
      "Setting the scaling factor while only one-way communication with the hardware is setup. "
      "This will likely get overwritten by the hardware again. If available, please also setup "
      "the speed_scaling_command_interface_name");
  }
  else
  {
    scaling_factor_cmd_.store(scaling_factor);
  }
  return true;
}

bool JointTrajectoryController::has_active_trajectory() const
{
  return current_trajectory_ != nullptr && current_trajectory_->has_trajectory_msg();
}

void JointTrajectoryController::update_pids()
{
  for (size_t i = 0; i < num_cmd_joints_; ++i)
  {
    const auto & gains = params_.gains.joints_map.at(params_.joints.at(map_cmd_to_joints_[i]));
    control_toolbox::AntiWindupStrategy antiwindup_strat;
    antiwindup_strat.set_type(gains.antiwindup_strategy);
    antiwindup_strat.i_max = gains.i_clamp_max;
    antiwindup_strat.i_min = gains.i_clamp_min;
    antiwindup_strat.error_deadband = gains.error_deadband;
    antiwindup_strat.tracking_time_constant = gains.tracking_time_constant;
    if (pids_[i])
    {
      // update PIDs with gains from ROS parameters
      pids_[i]->set_gains(
        gains.p, gains.i, gains.d, gains.u_clamp_max, gains.u_clamp_min, antiwindup_strat);
    }
    else
    {
      // Init PIDs with gains from ROS parameters
      pids_[i] = std::make_shared<control_toolbox::Pid>(
        gains.p, gains.i, gains.d, gains.u_clamp_max, gains.u_clamp_min, antiwindup_strat);
    }
    ff_velocity_scale_[i] = gains.ff_velocity_scale;
  }
}

void JointTrajectoryController::init_hold_position_msg()
{
  hold_position_msg_ptr_ = std::make_shared<trajectory_msgs::msg::JointTrajectory>();
  hold_position_msg_ptr_->header.stamp =
    rclcpp::Time(0.0, 0.0, get_node()->get_clock()->get_clock_type());  // start immediately
  hold_position_msg_ptr_->joint_names = params_.joints;
  hold_position_msg_ptr_->points.resize(1);  // a trivial msg only
  hold_position_msg_ptr_->points[0].velocities.clear();
  hold_position_msg_ptr_->points[0].accelerations.clear();
  hold_position_msg_ptr_->points[0].effort.clear();
  if (has_velocity_command_interface_ || has_acceleration_command_interface_)
  {
    // add velocity, so that trajectory sampling returns velocity points in any case
    hold_position_msg_ptr_->points[0].velocities.resize(dof_, 0.0);
  }
  if (has_acceleration_command_interface_)
  {
    // add velocity, so that trajectory sampling returns acceleration points in any case
    hold_position_msg_ptr_->points[0].accelerations.resize(dof_, 0.0);
  }
  if (has_effort_command_interface_)
  {
    hold_position_msg_ptr_->points[0].effort.resize(dof_, 0.0);
  }
}

void JointTrajectoryController::assign_point_from_command_interface(
  std::vector<double> & trajectory_point_interface,
  const std::vector<std::reference_wrapper<hardware_interface::LoanedCommandInterface>> &
    joint_interface)
{
  std::fill(
    trajectory_point_interface.begin(), trajectory_point_interface.end(),
    std::numeric_limits<double>::quiet_NaN());
  for (size_t index = 0; index < num_cmd_joints_; ++index)
  {
    const auto joint_command_interface_value_op = joint_interface[index].get().get_optional();
    if (!joint_command_interface_value_op.has_value())
    {
      RCLCPP_DEBUG(
        get_node()->get_logger(),
        "Unable to retrieve joint command interface value for joint at index %zu", index);
    }
    else
    {
      trajectory_point_interface.at(map_cmd_to_joints_[index]) =
        joint_command_interface_value_op.value();
    }
  }
}

}  // namespace joint_trajectory_controller

#include "pluginlib/class_list_macros.hpp"

PLUGINLIB_EXPORT_CLASS(
  joint_trajectory_controller::JointTrajectoryController, controller_interface::ControllerInterface)
