^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package chained_filter_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

6.10.1 (2026-11-04)
-------------------

6.10.0 (2026-10-05)
-------------------
* test: cleanup controller fixture member variables (`#2562 <https://github.com/ros-controls/ros2_controllers/issues/2562>`_)
* Contributors: Akshat Guduru

6.9.0 (2026-08-12)
------------------
* Use new Command/State Interfaces API for tests (`#2476 <https://github.com/ros-controls/ros2_controllers/issues/2476>`_)
* Use new chainable controller exports API (`#2350 <https://github.com/ros-controls/ros2_controllers/issues/2350>`_)
* Contributors: Sai Kishor Kothakota

6.8.0 (2026-07-01)
------------------
* Final test cleanup - call appropriate lifecycle transitions (`#2429 <https://github.com/ros-controls/ros2_controllers/issues/2429>`_)
* Call appropriate lifecycle transitions in controller tests: force_torque_sensor_broadcaster, chained_filter_controller, parallel_gripper_controller, steering_controllers_library (`#2382 <https://github.com/ros-controls/ros2_controllers/issues/2382>`_)
* Contributors: Junius Santoso

6.7.0 (2026-05-12)
------------------
* Bump C++ version to C++20 (`#2331 <https://github.com/ros-controls/ros2_controllers/issues/2331>`_)
* Contributors: Christoph Fröhlich

6.6.0 (2026-04-22)
------------------

6.5.0 (2026-04-02)
------------------

6.4.0 (2026-03-12)
------------------

6.3.0 (2026-02-03)
------------------

6.2.0 (2025-12-31)
------------------

6.1.0 (2025-12-01)
------------------

6.0.0 (2025-11-10)
------------------
* Controller interface api update to ros2_controller packages (`#1973 <https://github.com/ros-controls/ros2_controllers/issues/1973>`_)
* Contributors: Anand Vardhan

5.8.0 (2025-10-02)
------------------
* Remove deprecated methods from ros2_control (`#1936 <https://github.com/ros-controls/ros2_controllers/issues/1936>`_)
* Contributors: Christoph Fröhlich

5.7.0 (2025-09-12)
------------------

5.6.1 (2025-08-30)
------------------

5.6.0 (2025-08-29)
------------------
* Add a generic chained_filter_controller (`#1634 <https://github.com/ros-controls/ros2_controllers/issues/1634>`_)
* Contributors: Ankur Bodhe, Christoph Froehlich 
