^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package motion_primitives_controllers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

6.10.1 (2026-11-04)
-------------------

6.10.0 (2026-10-05)
-------------------
* test: cleanup controller fixture member variables (`#2562 <https://github.com/ros-controls/ros2_controllers/issues/2562>`_)
* Contributors: Akshat Guduru

6.9.0 (2026-08-12)
------------------
* Use new Command/State Interfaces API for tests (`#2476 <https://github.com/ros-controls/ros2_controllers/issues/2476>`_)
* Contributors: Sai Kishor Kothakota

6.8.0 (2026-07-01)
------------------
* fix: correct test_load_controller tests for motion_primitives and pid_controller (`#2445 <https://github.com/ros-controls/ros2_controllers/issues/2445>`_)
* fix: update dead documentation links (`#2398 <https://github.com/ros-controls/ros2_controllers/issues/2398>`_)
* Test fix - call appropriate lifecycle transitions in controller tests: pid, motion_primitives, state_interfaces_broadcaster, ackermann_steering (`#2399 <https://github.com/ros-controls/ros2_controllers/issues/2399>`_)
* Fix motion_primitive_controller TOC in docs (`#2221 <https://github.com/ros-controls/ros2_controllers/issues/2221>`_)
* Contributors: Ishan Pathak, Junius Santoso, Souri Rishik

6.7.0 (2026-05-12)
------------------

6.6.0 (2026-04-22)
------------------

6.5.0 (2026-04-02)
------------------

6.4.0 (2026-03-12)
------------------

6.3.0 (2026-02-03)
------------------

6.2.0 (2025-12-31)
------------------
* Use get_lifecycle_id instead of get_lifecycle_state (`#2053 <https://github.com/ros-controls/ros2_controllers/issues/2053>`_)
* Contributors: Sai Kishor Kothakota

6.1.0 (2025-12-01)
------------------

6.0.0 (2025-11-10)
------------------
* Controller interface api update to ros2_controller packages (`#1973 <https://github.com/ros-controls/ros2_controllers/issues/1973>`_)
* Fix integer literal for size_t (`#1986 <https://github.com/ros-controls/ros2_controllers/issues/1986>`_)
* Contributors: Anand Vardhan, Christoph Fröhlich

5.8.0 (2025-10-02)
------------------
* Remove deprecated methods from ros2_control (`#1936 <https://github.com/ros-controls/ros2_controllers/issues/1936>`_)
* Update broken links on motion_primitives_controllers readme (`#1919 <https://github.com/ros-controls/ros2_controllers/issues/1919>`_)
* Contributors: Christoph Fröhlich, Junius Santoso

5.7.0 (2025-09-12)
------------------
* Fix docs for motion_primitive_controllers (`#1877 <https://github.com/ros-controls/ros2_controllers/issues/1877>`_)
* Contributors: Christoph Fröhlich

5.6.1 (2025-08-30)
------------------
* Add cmake package dependency to moprim controller (`#1876 <https://github.com/ros-controls/ros2_controllers/issues/1876>`_)
* Contributors: Christoph Fröhlich

5.6.0 (2025-08-29)
------------------
* Refactoring to motion_primitives_base_controller (`#1857 <https://github.com/ros-controls/ros2_controllers/issues/1857>`_)
* Contributors: Mathias Fuhrer
