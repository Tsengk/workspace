cmake_minimum_required(VERSION 3.10)
project(chained_filter_controller)

find_package(ros2_control_cmake REQUIRED)
set_compiler_options()
export_windows_symbols()

# Dependencies
set(THIS_PACKAGE_INCLUDE_DEPENDS
  controller_interface
  generate_parameter_library
  filters
  hardware_interface
  pluginlib
  rclcpp
  rclcpp_lifecycle
)
find_package(ament_cmake REQUIRED)
find_package(backward_ros REQUIRED)
foreach(Dependency IN ITEMS ${THIS_PACKAGE_INCLUDE_DEPENDS})
  find_package(${Dependency} REQUIRED)
endforeach()

# Generate parameters from YAML
generate_parameter_library(
  chained_filter_parameters
  src/chained_filter_parameters.yaml
)

# Library definition
add_library(${PROJECT_NAME} SHARED
  src/chained_filter.cpp
)
target_include_directories(${PROJECT_NAME} PUBLIC
  $<BUILD_INTERFACE:${PROJECT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include/${PROJECT_NAME}>
)

# Dependencies
target_link_libraries(${PROJECT_NAME}
  PUBLIC
    chained_filter_parameters
    controller_interface::controller_interface
    hardware_interface::hardware_interface
    filters::filter_chain
    pluginlib::pluginlib
    rclcpp::rclcpp
    rclcpp_lifecycle::rclcpp_lifecycle
)

# Export the plugin description
pluginlib_export_plugin_description_file(controller_interface plugin_description.xml)

if(BUILD_TESTING)
  find_package(ament_cmake_gmock REQUIRED)
  find_package(controller_manager REQUIRED)
  find_package(ros2_control_test_assets REQUIRED)

  add_rostest_with_parameters_gmock(test_chained_filter_controller
    test/test_chained_filter.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test/config/test_chained_filter.yaml
  )
  target_link_libraries(test_chained_filter_controller
    ${PROJECT_NAME}
  )

  add_rostest_with_parameters_gmock(test_multiple_chained_filter_controller
    test/test_multiple_chained_filter.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test/config/test_multiple_chained_filter.yaml
  )
  target_link_libraries(test_multiple_chained_filter_controller
    ${PROJECT_NAME}
  )

  add_definitions(-DTEST_FILES_DIRECTORY="${CMAKE_CURRENT_SOURCE_DIR}/test")
  ament_add_gmock(test_load_chained_filter_controller test/test_load_chained_filter_controller.cpp)
  target_link_libraries(test_load_chained_filter_controller
    controller_manager::controller_manager
    ros2_control_test_assets::ros2_control_test_assets
  )

endif()

install(
  DIRECTORY include/
  DESTINATION include/${PROJECT_NAME}
)

install(
  TARGETS ${PROJECT_NAME}
  chained_filter_parameters
  EXPORT export_${PROJECT_NAME}
  ARCHIVE DESTINATION lib
  LIBRARY DESTINATION lib
  RUNTIME DESTINATION bin
)

# Export targets and dependencies
ament_export_targets(export_${PROJECT_NAME} HAS_LIBRARY_TARGET)
ament_export_dependencies(${THIS_PACKAGE_INCLUDE_DEPENDS})
ament_package()
