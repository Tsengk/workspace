// Copyright 2022 ros2_control development team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <functional>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "gmock/gmock.h"

#include "test_parallel_gripper_controller.hpp"

#include "hardware_interface/loaned_command_interface.hpp"
#include "hardware_interface/types/hardware_interface_return_values.hpp"
#include "lifecycle_msgs/msg/state.hpp"
#include "rclcpp_lifecycle/node_interfaces/lifecycle_node_interface.hpp"

using hardware_interface::LoanedCommandInterface;
using hardware_interface::LoanedStateInterface;
using GripperCommandAction = control_msgs::action::ParallelGripperCommand;
using GoalHandle = rclcpp_action::ServerGoalHandle<GripperCommandAction>;
using testing::SizeIs;
using testing::UnorderedElementsAre;

void GripperControllerTest::SetUpTestCase() {}

void GripperControllerTest::TearDownTestCase() {}

void GripperControllerTest::SetUp()
{
  // initialize controller
  controller_ = std::make_unique<FriendGripperController>();
  joint_1_pos_state_ = std::make_shared<hardware_interface::StateInterface>(
    joint_name_, hardware_interface::HW_IF_POSITION);
  std::ignore = joint_1_pos_state_->set_value(joint_states_[0]);
  joint_1_vel_state_ = std::make_shared<hardware_interface::StateInterface>(
    joint_name_, hardware_interface::HW_IF_VELOCITY);
  std::ignore = joint_1_vel_state_->set_value(joint_states_[1]);
  joint_1_cmd_ = std::make_shared<hardware_interface::CommandInterface>(
    joint_name_, hardware_interface::HW_IF_POSITION);
  std::ignore = joint_1_cmd_->set_value(joint_commands_[0]);
  joint_1_effort_cmd_ = std::make_shared<hardware_interface::CommandInterface>(
    joint_name_, hardware_interface::HW_IF_EFFORT);
  std::ignore = joint_1_effort_cmd_->set_value(joint_effort_commands_[0]);
  joint_1_speed_cmd_ = std::make_shared<hardware_interface::CommandInterface>(
    joint_name_, hardware_interface::HW_IF_VELOCITY);
  std::ignore = joint_1_speed_cmd_->set_value(joint_speed_commands_[0]);
}

void GripperControllerTest::TearDown() { controller_.reset(nullptr); }

void GripperControllerTest::SetUpController(
  const std::string & controller_name = "test_gripper_action_position_controller",
  controller_interface::return_type expected_result = controller_interface::return_type::OK)
{
  controller_interface::ControllerInterfaceParams params;
  params.controller_name = controller_name;
  params.robot_description = "";
  params.update_rate = 0;
  params.node_namespace = "";
  params.node_options = controller_->define_custom_node_options();

  const auto result = controller_->init(params);
  ASSERT_EQ(result, expected_result);

  std::vector<LoanedCommandInterface> command_ifs;
  command_ifs.emplace_back(this->joint_1_cmd_, nullptr);
  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(this->joint_1_pos_state_, nullptr);
  state_ifs.emplace_back(this->joint_1_vel_state_, nullptr);
  controller_->assign_interfaces(std::move(command_ifs), std::move(state_ifs));
}

TEST_F(GripperControllerTest, ParametersNotSet)
{
  this->SetUpController(
    "test_gripper_action_position_controller_no_parameters",
    controller_interface::return_type::ERROR);
}

TEST_F(GripperControllerTest, JointParameterIsEmpty)
{
  this->SetUpController(
    "test_gripper_action_position_controller_empty_joint",
    controller_interface::return_type::ERROR);
}

TEST_F(GripperControllerTest, ConfigureParamsSuccess)
{
  this->SetUpController();

  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(controller_->get_node()->get_node_base_interface());

  this->controller_->get_node()->set_parameter({"joint", "joint1"});
  executor.spin_some();

  ASSERT_TRUE(configure_succeeds(controller_));

  auto cmd_if_conf = this->controller_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, SizeIs(1lu));
  ASSERT_THAT(
    cmd_if_conf.names,
    UnorderedElementsAre(std::string("joint1/") + hardware_interface::HW_IF_POSITION));
  EXPECT_EQ(cmd_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);
  auto state_if_conf = this->controller_->state_interface_configuration();
  ASSERT_THAT(state_if_conf.names, SizeIs(2lu));
  ASSERT_THAT(state_if_conf.names, UnorderedElementsAre("joint1/position", "joint1/velocity"));
  EXPECT_EQ(state_if_conf.type, controller_interface::interface_configuration_type::INDIVIDUAL);
}

TEST_F(GripperControllerTest, ActivateSuccess)
{
  this->SetUpController();

  this->controller_->get_node()->set_parameter({"joint", "joint1"});

  ASSERT_TRUE(configure_succeeds(controller_));
  ASSERT_TRUE(activate_succeeds(controller_));
}

TEST_F(GripperControllerTest, ActivateDeactivateActivateSuccess)
{
  this->SetUpController();

  this->controller_->get_node()->set_parameter({"joint", "joint1"});

  ASSERT_TRUE(configure_succeeds(controller_));
  ASSERT_TRUE(activate_succeeds(controller_));
  ASSERT_TRUE(deactivate_succeeds(controller_));
  this->controller_->release_interfaces();

  std::vector<LoanedCommandInterface> command_ifs;
  command_ifs.emplace_back(this->joint_1_cmd_, nullptr);
  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(this->joint_1_pos_state_, nullptr);
  state_ifs.emplace_back(this->joint_1_vel_state_, nullptr);
  this->controller_->assign_interfaces(std::move(command_ifs), std::move(state_ifs));

  ASSERT_TRUE(configure_succeeds(controller_));
  ASSERT_TRUE(activate_succeeds(controller_));
}

TEST_F(GripperControllerTest, ActivateWithEffortInterfaceSuccess)
{
  this->SetUpController("test_gripper_controller_with_effort");

  this->controller_->release_interfaces();
  std::vector<LoanedCommandInterface> command_ifs;
  command_ifs.emplace_back(this->joint_1_cmd_, nullptr);
  command_ifs.emplace_back(this->joint_1_effort_cmd_, nullptr);
  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(this->joint_1_pos_state_, nullptr);
  state_ifs.emplace_back(this->joint_1_vel_state_, nullptr);
  this->controller_->assign_interfaces(std::move(command_ifs), std::move(state_ifs));

  ASSERT_TRUE(configure_succeeds(controller_));

  auto cmd_if_conf = this->controller_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, testing::Contains("joint1/effort"));

  ASSERT_TRUE(activate_succeeds(controller_));
}

TEST_F(GripperControllerTest, ActivateWithVelocityInterfaceSuccess)
{
  this->SetUpController("test_gripper_controller_with_velocity");

  this->controller_->release_interfaces();
  std::vector<LoanedCommandInterface> command_ifs;
  command_ifs.emplace_back(this->joint_1_cmd_, nullptr);
  command_ifs.emplace_back(this->joint_1_speed_cmd_, nullptr);
  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(this->joint_1_pos_state_, nullptr);
  state_ifs.emplace_back(this->joint_1_vel_state_, nullptr);
  this->controller_->assign_interfaces(std::move(command_ifs), std::move(state_ifs));

  ASSERT_TRUE(configure_succeeds(controller_));

  auto cmd_if_conf = this->controller_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, testing::Contains("joint1/velocity"));

  ASSERT_TRUE(activate_succeeds(controller_));
}

TEST_F(GripperControllerTest, ActivateWithEffortAndVelocityInterfaceSuccess)
{
  this->SetUpController("test_gripper_controller_with_effort_and_velocity");

  this->controller_->release_interfaces();
  std::vector<LoanedCommandInterface> command_ifs;
  command_ifs.emplace_back(this->joint_1_cmd_, nullptr);
  command_ifs.emplace_back(this->joint_1_effort_cmd_, nullptr);
  command_ifs.emplace_back(this->joint_1_speed_cmd_, nullptr);
  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(this->joint_1_pos_state_, nullptr);
  state_ifs.emplace_back(this->joint_1_vel_state_, nullptr);
  this->controller_->assign_interfaces(std::move(command_ifs), std::move(state_ifs));

  ASSERT_TRUE(configure_succeeds(controller_));

  auto cmd_if_conf = this->controller_->command_interface_configuration();
  ASSERT_THAT(cmd_if_conf.names, testing::Contains("joint1/effort"));
  ASSERT_THAT(cmd_if_conf.names, testing::Contains("joint1/velocity"));

  ASSERT_TRUE(activate_succeeds(controller_));
}

TEST_F(GripperControllerTest, DeactivateWithEffortAndVelocitySuccess)
{
  this->SetUpController("test_gripper_controller_with_effort_and_velocity");

  this->controller_->release_interfaces();
  std::vector<LoanedCommandInterface> command_ifs;
  command_ifs.emplace_back(this->joint_1_cmd_, nullptr);
  command_ifs.emplace_back(this->joint_1_effort_cmd_, nullptr);
  command_ifs.emplace_back(this->joint_1_speed_cmd_, nullptr);
  std::vector<LoanedStateInterface> state_ifs;
  state_ifs.emplace_back(this->joint_1_pos_state_, nullptr);
  state_ifs.emplace_back(this->joint_1_vel_state_, nullptr);
  this->controller_->assign_interfaces(std::move(command_ifs), std::move(state_ifs));

  ASSERT_TRUE(configure_succeeds(controller_));
  ASSERT_TRUE(activate_succeeds(controller_));
  ASSERT_TRUE(deactivate_succeeds(controller_));
}

TEST_F(GripperControllerTest, ActivateFailsWhenEffortInterfaceMissing)
{
  // effort interface configured in params but NOT provided as a hardware interface
  this->SetUpController("test_gripper_controller_with_effort");

  ASSERT_TRUE(configure_succeeds(controller_));

  // on_activate should FAIL because effort configured but not found
  ASSERT_EQ(
    this->controller_->on_activate(rclcpp_lifecycle::State()),
    controller_interface::CallbackReturn::FAILURE);
}

int main(int argc, char ** argv)
{
  ::testing::InitGoogleMock(&argc, argv);
  rclcpp::init(argc, argv);
  int result = RUN_ALL_TESTS();
  rclcpp::shutdown();
  return result;
}
